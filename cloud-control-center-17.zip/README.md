# Cloud Control Center

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
[![AWS Powered](https://img.shields.io/badge/AWS-Powered-orange?logo=amazon-aws)](docs/AWS_SETUP.md)
[![Clean Architecture](https://img.shields.io/badge/Architecture-Clean-blue)](docs/Architecture.md)

An enterprise-ready **Cloud Control Center** dashboard designed for AWS infrastructure administration, monitoring, cost control, and virtual machine lifecycle management. 

This repository establishes a highly optimized, clean-architecture foundation suited for cloud engineers and full-stack AWS architects aiming to build and present professional portfolios.

---

## 1. Project Overview

The Cloud Control Center is a centralized web console that allows DevOps engineers and cloud administrators to securely view, monitor, and configure AWS cloud infrastructure. By separating complex resource controls into simple, actionable visual elements, it makes AWS account monitoring highly reliable and reduces human errors in cloud operations.

Designed from the ground up utilizing **Clean Architecture** patterns, this project ensures the core business rules are completely independent of web frameworks, third-party databases, and visual frontend dependencies.

---

## 2. Core Features

### 🖥️ Elastic Compute Control
- Real-time aggregation of AWS EC2 instances across specified AWS regions.
- Safe start, stop, and reboot commands directly with state feedback to avoid running idle VMs.

### 💰 Billing and Cost Guard
- Visual breakdown of accumulated AWS monthly charges aggregated via AWS Cost Explorer API.
- Intelligent tagging filtering to identify cost outliers and resource waste instantly.

### 🔒 IAM Least Privilege Security
- Direct integration with AWS IAM policies using strict least-privilege permissions.
- Zero credential exposure: configuration is designed to leverage ECS Task Roles in production and secure env loading locally.

### 📊 Service Telemetry
- Unified system health indicators verifying API reachability, active database connections, and secure AWS connectivity checks.

---

## 3. Tech Stack

- **Core Core Logic**: Python 3.11+, TypeScript
- **Backend Service Framework**: FastAPI (ASGI), Uvicorn
- **Frontend Dashboard App**: React (Vite, Tailwind CSS, Lucide Icons, Recharts)
- **Containerization**: Docker, Docker Compose
- **Infrastructure Management**: Terraform (IaC target blueprint)
- **Database Engine**: PostgreSQL (SQLAlchemy ORM + migration systems)
- **AWS Integrations**: Boto3 (AWS SDK for Python)

---

## 4. System Architecture

```
                  ┌─────────────────────────────────────┐
                  │            Presentation             │
                  │    (React SPA / Tailwind CSS)       │
                  └──────────────────┬──────────────────┘
                                     │ (HTTPS / REST)
                  ┌──────────────────▼──────────────────┐
                  │            API Gateway              │
                  │        (FastAPI / ASGI)             │
                  └──────────────────┬──────────────────┘
                                     │
         ┌───────────────────────────┼───────────────────────────┐
         │ Core Backend Application  │                           │
         │                           │                           │
         │  ┌─────────────────────┐  │  ┌─────────────────────┐  │
         │  │   Handlers/Routes   │  │  │   AWS SDK (Boto3)   │  │
         │  └──────────┬──────────┘  │  └──────────▲──────────┘  │
         │             │             │             │             │
         │  ┌──────────▼──────────┐  │  ┌──────────┴──────────┐  │
         │  │   Use Cases / Core  │◄─┼─►│     Repositories    │  │
         │  │    Business Logic   │  │  │ (DB/AWS Integrations│  │
         │  └──────────┬──────────┘  │  └──────────▲──────────┘  │
         │             │             │             │             │
         │  ┌──────────▼──────────┐  │             │             │
         │  │   Entities/Models   ├──┘             │             │
         │  └─────────────────────┘                │             │
         └─────────────────────────────────────────┼─────────────┘
                                                   │ (SQLAlchemy / Boto3)
                                      ┌────────────▼────────────┐
                                      │   PostgreSQL / Cloud    │
                                      │   Infrastructure APIs   │
                                      └─────────────────────────┘
```

For a comprehensive explanation of our Clean Architecture design and AWS production deployment layout, consult [docs/Architecture.md](docs/Architecture.md).

---

## 5. Folder Structure

```
cloud-control-center/
├── backend/            # Python FastAPI core application layers (Domain, Use Cases, Inf)
├── frontend/           # React dashboard web application components
├── docker/             # Container configuration files (Dockerfiles, compose specifications)
├── docs/               # Technical references, API specifications, and AWS setups
│   ├── Architecture.md
│   ├── API.md
│   ├── AWS_SETUP.md
│   ├── Local_Development.md
│   ├── Interview_Questions.md
│   └── Troubleshooting.md
├── screenshots/        # Architectural diagrams and user interface showcase assets
├── .gitignore          # Environment & temporary asset exclusions matching guidelines
├── LICENSE             # MIT Open Source License
└── README.md           # Master project overview
```

---

## 6. Future Roadmap

- [ ] **Phase 1: Local Foundation Setup** *(Current)*
  - Establish production folder standards and architecture specifications.
- [ ] **Phase 2: Core Core & API Development**
  - Implement DDD Domain, Application Use Cases, and Repository boundaries in FastAPI.
- [ ] **Phase 3: Frontend Interface Launch**
  - Build React components, state engines, and billing charts.
- [ ] **Phase 4: AWS Integration Verification**
  - Wire authentic Boto3 drivers with mock-local AWS setups (LocalStack) and RDS.
- [ ] **Phase 5: Terraform Automation & Deployment**
  - Automate private subnets VPC and ECS Fargate deployments using automated IaC scripts.
