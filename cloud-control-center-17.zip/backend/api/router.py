from fastapi import APIRouter
from api.routes import account, ec2, s3, iam, cloudwatch, cloudtrail, cost_explorer, security, search, regions, vpc, load_balancers, lambda_monitoring, rds, ebs, tags

api_router = APIRouter(prefix="/api/aws")

# Register individual sub-routers
api_router.include_router(account.router, tags=["AWS Account"])
api_router.include_router(ec2.router, tags=["AWS EC2"])
api_router.include_router(s3.router, tags=["AWS S3"])
api_router.include_router(iam.router, tags=["AWS IAM"])
api_router.include_router(cloudwatch.router, tags=["AWS CloudWatch"])
api_router.include_router(cloudtrail.router, tags=["AWS CloudTrail"])
api_router.include_router(vpc.router, tags=["AWS VPC"])
api_router.include_router(cost_explorer.router, tags=["AWS Cost Explorer"])
api_router.include_router(security.router, tags=["AWS Security Monitoring"])
api_router.include_router(search.router, tags=["AWS Global Search"])
api_router.include_router(regions.router, tags=["AWS Regions"])
api_router.include_router(load_balancers.router, tags=["AWS Load Balancer Monitoring"])
api_router.include_router(lambda_monitoring.router, tags=["AWS Lambda Monitoring"])
api_router.include_router(rds.router, tags=["AWS RDS Monitoring"])
api_router.include_router(ebs.router, tags=["AWS EBS Monitoring"])
api_router.include_router(tags.router, tags=["AWS Tag Explorer"])
