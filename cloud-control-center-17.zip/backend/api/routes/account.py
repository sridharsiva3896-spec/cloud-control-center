from fastapi import APIRouter
from services.aws.account_service import AWSAccountService
from schemas.account import AccountSummaryResponse

router = APIRouter()

@router.get("/account", response_model=AccountSummaryResponse)
def get_aws_account():
    """
    Retrieves comprehensive AWS Account overview information, including regions and aliases.
    """
    return AWSAccountService.get_account_overview()

