from fastapi import APIRouter, Query
from services.aws.cloudtrail_service import CloudTrailService
from schemas.cloudtrail import CloudTrailSummaryResponse

router = APIRouter()

@router.get("/cloudtrail", response_model=CloudTrailSummaryResponse)
def get_aws_cloudtrail_events(region: str = Query(None)):
    """
    Retrieves the latest CloudTrail audit events and statistics.
    """
    return CloudTrailService.get_recent_events(region=region)

