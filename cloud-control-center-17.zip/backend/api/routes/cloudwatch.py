from fastapi import APIRouter, Query
from services.aws.cloudwatch_service import CloudWatchService
from schemas.cloudwatch import CloudWatchSummaryResponse

router = APIRouter()

@router.get("/cloudwatch", response_model=CloudWatchSummaryResponse)
def get_aws_cloudwatch_metrics(region: str = Query(None)):
    """
    Retrieves CloudWatch performance metrics for EC2 instances.
    """
    return CloudWatchService.get_cloudwatch_metrics(region=region)

