from fastapi import APIRouter
from services.aws.cost_explorer_service import AWSCostExplorerService
from schemas.cost_explorer import CostExplorerResponse

router = APIRouter()

@router.get("/cost", response_model=CostExplorerResponse)
def get_aws_cost_overview():
    """
    Retrieves Cost Explorer overview, service-wise cost breakdown, and daily cost trends.
    """
    return AWSCostExplorerService.get_cost_and_usage_data()

