from fastapi import APIRouter, Query
from services.aws.ebs_service import EBSService
from schemas.ebs import EBSSummaryResponse

router = APIRouter()

@router.get("/ebs", response_model=EBSSummaryResponse)
def get_aws_ebs_assets(region: str = Query(None)):
    """
    Retrieves current Amazon EBS volumes, snapshots, and aggregate summary metrics.
    """
    return EBSService.get_ebs_monitoring(region=region)

