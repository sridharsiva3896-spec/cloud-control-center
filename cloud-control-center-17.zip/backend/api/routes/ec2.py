from fastapi import APIRouter, Query
from services.aws.ec2_service import EC2Service
from schemas.ec2 import EC2SummaryResponse

router = APIRouter()

@router.get("/ec2", response_model=EC2SummaryResponse)
def get_aws_ec2_instances(region: str = Query(None)):
    """
    Retrieves current active EC2 virtual machine instances and summary counters.
    """
    return EC2Service.get_ec2_instances(region=region)

