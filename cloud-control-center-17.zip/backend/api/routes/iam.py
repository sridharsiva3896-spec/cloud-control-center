from fastapi import APIRouter
from services.aws.iam_service import IAMService
from schemas.iam import IAMSummaryResponse

router = APIRouter()

@router.get("/iam", response_model=IAMSummaryResponse)
def get_aws_iam_overview():
    """
    Retrieves current active IAM resources (users, groups, roles, policies) and summary counters.
    """
    return IAMService.get_iam_overview()

