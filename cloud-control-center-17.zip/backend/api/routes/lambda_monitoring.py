from fastapi import APIRouter, Query
from services.aws.lambda_service import LambdaService
from schemas.lambda_schema import LambdaSummaryResponse

router = APIRouter()

@router.get("/lambda", response_model=LambdaSummaryResponse)
def get_aws_lambda_functions(region: str = Query(None)):
    """
    Retrieves current AWS Lambda functions and summary metrics.
    """
    return LambdaService.get_lambda_monitoring(region=region)

