from fastapi import APIRouter, Query
from services.aws.load_balancer_service import LoadBalancerService
from schemas.load_balancer import LoadBalancerSummaryResponse

router = APIRouter()

@router.get("/load-balancers", response_model=LoadBalancerSummaryResponse)
def get_aws_load_balancers_monitoring(region: str = Query(None)):
    """
    Retrieves full AWS Elastic Load Balancing (ELB v2) telemetry, target groups,
    listeners, and target health statuses.
    """
    return LoadBalancerService.get_load_balancers_monitoring(region=region)

