from fastapi import APIRouter, Query
from services.aws.rds_service import RDSService
from schemas.rds import RDSSummaryResponse

router = APIRouter()

@router.get("/rds", response_model=RDSSummaryResponse)
def get_aws_rds_databases(region: str = Query(None)):
    """
    Retrieves current Amazon RDS instances, clusters, and aggregate summary metrics.
    """
    return RDSService.get_rds_monitoring(region=region)

