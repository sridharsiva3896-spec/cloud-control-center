import boto3
from botocore.exceptions import ClientError
from botocore.config import Config
from fastapi import APIRouter
from typing import List

router = APIRouter()

@router.get("/regions/default", response_model=str)
def get_default_aws_region():
    """
    Returns the backend-configured default AWS region.
    """
    from config.settings import settings
    return settings.AWS_DEFAULT_REGION

@router.get("/regions", response_model=List[str])
def get_aws_regions():
    """
    Returns all available AWS regions for the switcher dropdown.
    Uses boto3 describe_regions() to dynamically retrieve enabled commercial AWS regions.
    Falls back to botocore's get_available_regions() if credentials/permissions are missing.
    """
    try:
        session = boto3.Session()
        config = Config(
            connect_timeout=3,
            read_timeout=3,
            retries={"max_attempts": 1, "mode": "standard"}
        )
        # Try to dynamically fetch enabled regions using describe_regions
        ec2_client = session.client("ec2", region_name="us-east-1", config=config)
        regions_response = ec2_client.describe_regions(AllRegions=False)
        regions = [r.get("RegionName") for r in regions_response.get("Regions", []) if r.get("RegionName")]
        if regions:
            # Filter out GovCloud and China regions if returned
            regions = [r for r in regions if not r.startswith("us-gov-") and not r.startswith("cn-")]
            return sorted(list(set(regions)))
    except Exception:
        # Fallback dynamically without credentials using boto3's session metadata
        pass

    try:
        session = boto3.Session()
        regions = session.get_available_regions("ec2")
        if regions:
            # Ensure we exclude GovCloud and China regions
            regions = [r for r in regions if not r.startswith("us-gov-") and not r.startswith("cn-")]
            return sorted(list(set(regions)))
    except Exception:
        pass

    # Absolutely last-resort fallback to standard commercial regions only if boto3 itself fails completely
    return [
        "af-south-1",
        "ap-east-1",
        "ap-south-1",
        "ap-south-2",
        "ap-southeast-1",
        "ap-southeast-2",
        "ap-southeast-3",
        "ap-southeast-4",
        "ap-northeast-1",
        "ap-northeast-2",
        "ap-northeast-3",
        "ca-central-1",
        "eu-central-1",
        "eu-central-2",
        "eu-west-1",
        "eu-west-2",
        "eu-west-3",
        "eu-north-1",
        "eu-south-1",
        "eu-south-2",
        "il-central-1",
        "me-central-1",
        "me-south-1",
        "sa-east-1",
        "us-east-1",
        "us-east-2",
        "us-west-1",
        "us-west-2"
    ]

