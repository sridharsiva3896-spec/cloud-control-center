from fastapi import APIRouter
from services.aws.s3_service import S3Service
from schemas.s3 import S3SummaryResponse

router = APIRouter()

@router.get("/s3", response_model=S3SummaryResponse)
def get_aws_s3_buckets():
    """
    Retrieves a list of S3 buckets and audits active parameters for each.
    """
    return S3Service.get_s3_buckets()

