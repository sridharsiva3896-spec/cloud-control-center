from fastapi import APIRouter, Query
from services.aws.search_service import AWSSearchService
from schemas.search import SearchResponse

router = APIRouter()

@router.get("/search", response_model=SearchResponse)
def search_aws_resources(q: str = Query("", description="Case-insensitive global AWS resource query string")):
    """
    Search across multiple AWS resources including EC2 Instances, S3 Buckets, 
    and IAM Identities (Users, Roles, Groups).
    """
    return AWSSearchService.search_resources(q)

