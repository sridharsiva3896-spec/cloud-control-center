from fastapi import APIRouter
from services.aws.security_service import AWSSecurityService
from schemas.security import SecurityResponse

router = APIRouter()

@router.get("/security", response_model=SecurityResponse)
def get_aws_security_report():
    """
    Retrieves read-only IAM policies, password complexity configurations, MFA coverage,
    and S3 isolation statuses, converting them to structured security audit compliance metrics.
    """
    return AWSSecurityService.get_security_overview()

