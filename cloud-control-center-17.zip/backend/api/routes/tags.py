from fastapi import APIRouter, Query
from services.aws.tag_service import TagService
from schemas.tag import TaggedResourcesResponse

router = APIRouter()

@router.get("/tags", response_model=TaggedResourcesResponse)
def get_aws_resources_tags(
    region: str = Query(None),
    service: str = Query(None),
    tag_key: str = Query(None),
    tag_value: str = Query(None)
):
    """
    Retrieves a list of AWS resources and their associated tags in the selected region.
    Filters can be optionally applied for service, tag_key, and tag_value.
    """
    return TagService.get_resources(
        region=region,
        service_filter=service,
        tag_key_filter=tag_key,
        tag_value_filter=tag_value
    )

