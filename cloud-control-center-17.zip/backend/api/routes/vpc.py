from fastapi import APIRouter, Query
from services.aws.vpc_service import VpcService
from schemas.vpc import VPCSummaryResponse

router = APIRouter()

@router.get("/vpc", response_model=VPCSummaryResponse)
def get_aws_vpc_monitoring(region: str = Query(None)):
    """
    Retrieves full AWS Virtual Private Cloud (VPC) telemetry, subnets, route tables,
    gateways, security groups, and ACL states.
    """
    return VpcService.get_vpc_monitoring(region=region)

