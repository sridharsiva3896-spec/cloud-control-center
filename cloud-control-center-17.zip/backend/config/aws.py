import boto3
from botocore.config import Config
from .settings import settings

class AWSConfig:
    """
    Centralized AWS Configuration class. Handles botocore Config generation,
    session argument formulation, and credential/region resolution.
    """
    @property
    def default_region(self) -> str:
        return settings.AWS_DEFAULT_REGION

    @property
    def botocore_config(self) -> Config:
        """
        Returns a standardized botocore Config object with timeouts and retries
        derived from the application settings.
        """
        return Config(
            connect_timeout=settings.CONNECT_TIMEOUT,
            read_timeout=settings.READ_TIMEOUT,
            retries={
                "max_attempts": settings.MAX_RETRIES,
                "mode": "standard"
            }
        )

    def get_session_args(self) -> dict:
        """
        Constructs and returns keyword arguments for constructing a boto3.Session.
        Ensures credentials from environment/settings are explicitly supported,
        while falling back to default resolution (shared files, IAM profiles) gracefully.
        """
        args = {}
        
        # Prioritize explicit credentials if configured
        if settings.AWS_ACCESS_KEY_ID:
            args["aws_access_key_id"] = settings.AWS_ACCESS_KEY_ID
        if settings.AWS_SECRET_ACCESS_KEY:
            args["aws_secret_access_key"] = settings.AWS_SECRET_ACCESS_KEY
            
        # Support profile configuration
        if settings.AWS_PROFILE:
            args["profile_name"] = settings.AWS_PROFILE
            
        # Support default region setting
        if settings.AWS_DEFAULT_REGION:
            args["region_name"] = settings.AWS_DEFAULT_REGION
            
        return args

    def create_session(self) -> boto3.Session:
        """
        Creates and returns a pre-configured boto3.Session.
        """
        return boto3.Session(**self.get_session_args())

# Global configuration helper
aws_config = AWSConfig()
