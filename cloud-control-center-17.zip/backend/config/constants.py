# Service Names
SERVICE_S3 = "s3"
SERVICE_VPC = "vpc"
SERVICE_IAM = "iam"
SERVICE_EC2 = "ec2"
SERVICE_LAMBDA = "lambda"
SERVICE_RDS = "rds"
SERVICE_EBS = "ebs"
SERVICE_ELB = "elb"
SERVICE_STS = "sts"

# Health and Status values
STATUS_HEALTHY = "healthy"
STATUS_UNHEALTHY = "unhealthy"
STATUS_UNKNOWN = "unknown"
STATUS_CONNECTED = "connected"
STATUS_DISCONNECTED = "disconnected"

# API & Cache Configuration
DEFAULT_PAGINATION_LIMIT = 50
DEFAULT_CACHE_TTL_SECONDS = 300

# Error Messages
ERROR_MISSING_CREDENTIALS = "AWS credentials not configured. Please verify your environment settings or credentials file."
ERROR_AUTHORIZATION_FAILED = "AWS authorization failed. The credentials provided do not have access to this resource."
ERROR_SYSTEM_EXCEPTION = "An unexpected system error occurred. Please contact an administrator or check server logs."
ERROR_FETCH_FAILED = "Failed to retrieve information from AWS service: {service_name}"
