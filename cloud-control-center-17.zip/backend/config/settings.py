import os
from dotenv import load_dotenv
from pydantic import BaseModel, Field

load_dotenv()

try:
    from pydantic_settings import BaseSettings, SettingsConfigDict
    
    class Settings(BaseSettings):
        model_config = SettingsConfigDict(
            env_file=".env",
            env_file_encoding="utf-8",
            extra="ignore"
        )
        
        APP_NAME: str = "Cloud Control Center"
        VERSION: str = "2.0.0"
        ENV: str = "development"
        DEBUG: bool = True
        API_PREFIX: str = "/api"
        FRONTEND_URL: str = "http://localhost:3000"
        
        # AWS Settings
        AWS_DEFAULT_REGION: str = "us-east-1"
        AWS_PROFILE: str = ""
        AWS_ACCESS_KEY_ID: str = ""
        AWS_SECRET_ACCESS_KEY: str = ""
        
        # API Keys
        GEMINI_API_KEY: str = ""
        OPENAI_API_KEY: str = ""
        
        # Logging & Timeouts
        LOG_LEVEL: str = "INFO"
        CONNECT_TIMEOUT: int = 10
        READ_TIMEOUT: int = 30
        MAX_RETRIES: int = 3

except ImportError:
    # Fallback to standard BaseModel loading from environment
    class Settings(BaseModel):
        APP_NAME: str = Field(default="Cloud Control Center")
        VERSION: str = Field(default="2.0.0")
        ENV: str = Field(default=os.getenv("ENV", "development"))
        DEBUG: bool = Field(default=os.getenv("DEBUG", "true").lower() in ("true", "1", "yes"))
        API_PREFIX: str = Field(default="/api")
        FRONTEND_URL: str = Field(default=os.getenv("FRONTEND_URL", "http://localhost:3000"))
        
        # AWS Settings
        AWS_DEFAULT_REGION: str = Field(default=os.getenv("AWS_DEFAULT_REGION", "us-east-1"))
        AWS_PROFILE: str = Field(default=os.getenv("AWS_PROFILE", ""))
        AWS_ACCESS_KEY_ID: str = Field(default=os.getenv("AWS_ACCESS_KEY_ID", ""))
        AWS_SECRET_ACCESS_KEY: str = Field(default=os.getenv("AWS_SECRET_ACCESS_KEY", ""))
        
        # API Keys
        GEMINI_API_KEY: str = Field(default=os.getenv("GEMINI_API_KEY", ""))
        OPENAI_API_KEY: str = Field(default=os.getenv("OPENAI_API_KEY", ""))
        
        # Logging & Timeouts
        LOG_LEVEL: str = Field(default=os.getenv("LOG_LEVEL", "INFO"))
        CONNECT_TIMEOUT: int = Field(default=int(os.getenv("CONNECT_TIMEOUT", "10")))
        READ_TIMEOUT: int = Field(default=int(os.getenv("READ_TIMEOUT", "30")))
        MAX_RETRIES: int = Field(default=int(os.getenv("MAX_RETRIES", "3")))

# Instantiate standard global settings instance
settings = Settings()
