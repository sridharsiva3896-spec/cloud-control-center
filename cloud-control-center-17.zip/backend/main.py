import os
from datetime import datetime
from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv
from services.aws.sts_service import STSService
from services.aws.session_service import AWSSessionService, current_session_id
from api.router import api_router
from utils.logger import log_api_request, log_unexpected_exception

from schemas.common import MessageResponse, AWSConnectResponse, AWSConnectRequest, RegionCatalogResponse, RegionItem
from schemas.health import HealthCheckResponse
from pydantic import BaseModel, Field
from api.routes.regions import get_aws_regions
from config.settings import settings

# Load local environment variables
load_dotenv()

# Initialize FastAPI application with metadata
app = FastAPI(
    title="Cloud Control Center API",
    description="Backend API services for EC2 virtual machines management, cost analysis, and system telemetries.",
    version="1.0.0"
)

# Enforce production security policies by explicitly defining permitted origins
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Permits all local sandbox ports in development
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.middleware("http")
async def log_requests_middleware(request: Request, call_next):
    # Log incoming HTTP request metadata
    log_api_request(request.method, request.url.path, dict(request.query_params))
    
    # Extract and bind X-AWS-Session-ID header context safely
    session_id = request.headers.get("X-AWS-Session-ID")
    token = current_session_id.set(session_id)
    try:
        # Enforce disconnected check for AWS-dependent resources
        path = request.url.path
        if path.startswith("/api/aws/") and path not in [
            "/api/aws/connect", 
            "/api/aws/logout", 
            "/api/aws/disconnect", 
            "/api/aws/session",
            "/api/aws/regions",
            "/api/aws/regions/default"
        ]:
            if not AWSSessionService.is_connected():
                from fastapi.responses import JSONResponse
                return JSONResponse(
                    status_code=401,
                    content={
                        "success": False,
                        "message": "AWS account is not connected."
                    }
                )
        response = await call_next(request)
        return response
    except Exception as e:
        log_unexpected_exception("http_middleware", f"Error serving {request.method} {request.url.path}", e)
        raise e
    finally:
        current_session_id.reset(token)

@app.get("/", response_model=MessageResponse)
def read_root():
    """
    Base health check endpoint to verify backend server online status.
    """
    return {
        "message": "Cloud Control Center Backend Running"
    }

@app.get("/api/health", response_model=HealthCheckResponse)
def get_health():
    """
    Detailed health check API endpoint returning structural health and service metadata.
    """
    aws_info = AWSSessionService.get_session_info()
    return {
        "status": "healthy",
        "aws_connection_status": {
            "connected": aws_info.get("connected", False),
            "region": aws_info.get("region", "unknown"),
            "message": aws_info.get("message", "N/A")
        },
        "version": "2.0.0",
        "timestamp": datetime.utcnow().isoformat() + "Z"
    }

@app.post("/api/aws/connect", response_model=AWSConnectResponse)
def connect_aws(payload: AWSConnectRequest):
    """
    Validates credentials and retrieves current account parameters from AWS STS.
    """
    return AWSSessionService.connect(
        aws_access_key_id=payload.aws_access_key_id,
        aws_secret_access_key=payload.aws_secret_access_key,
        aws_session_token=payload.aws_session_token,
        region_name=payload.region_name
    )

@app.post("/api/aws/logout", response_model=MessageResponse)
def logout_aws():
    """
    Destroys the server-side AWS session.
    """
    AWSSessionService.disconnect()
    return {"message": "AWS Session destroyed successfully"}

@app.post("/api/aws/disconnect", response_model=MessageResponse)
def disconnect_aws():
    """
    Destroys the server-side AWS session (alias).
    """
    AWSSessionService.disconnect()
    return {"message": "AWS Session destroyed successfully"}

@app.delete("/api/aws/session", response_model=MessageResponse)
def delete_aws_session():
    """
    Destroys the server-side AWS session (DELETE alias).
    """
    AWSSessionService.disconnect()
    return {"message": "AWS Session destroyed successfully"}

@app.get("/api/aws/session", response_model=AWSConnectResponse)
def get_aws_session():
    """
    Retrieves the active AWS Session state and Caller Identity metadata.
    """
    return AWSSessionService.get_session_info()

class SwitchRegionRequest(BaseModel):
    region_name: str = Field(..., description="The AWS region code to switch to")

@app.get("/api/regions", response_model=RegionCatalogResponse)
def get_regions_catalog():
    """
    Returns the complete list of commercial AWS regions and the default configured region.
    This public endpoint is accessible even when the AWS session is disconnected.
    """
    region_codes = get_aws_regions()
    
    REGION_NAMES = {
        'us-east-1': 'N. Virginia',
        'us-east-2': 'Ohio',
        'us-west-1': 'N. California',
        'us-west-2': 'Oregon',
        'ca-central-1': 'Canada Central',
        'ca-west-1': 'Calgary',
        'eu-central-1': 'Frankfurt',
        'eu-central-2': 'Zurich',
        'eu-west-1': 'Ireland',
        'eu-west-2': 'London',
        'eu-west-3': 'Paris',
        'eu-north-1': 'Stockholm',
        'eu-south-1': 'Milan',
        'eu-south-2': 'Spain',
        'ap-east-1': 'Hong Kong',
        'ap-south-1': 'Mumbai',
        'ap-south-2': 'Hyderabad',
        'ap-northeast-1': 'Tokyo',
        'ap-northeast-2': 'Seoul',
        'ap-northeast-3': 'Osaka',
        'ap-southeast-1': 'Singapore',
        'ap-southeast-2': 'Sydney',
        'ap-southeast-3': 'Jakarta',
        'ap-southeast-4': 'Melbourne',
        'ap-southeast-5': 'Thailand',
        'sa-east-1': 'São Paulo',
        'af-south-1': 'Cape Town',
        'me-south-1': 'Bahrain',
        'me-central-1': 'UAE',
        'il-central-1': 'Tel Aviv',
    }
    
    regions_list = []
    for code in region_codes:
        name = REGION_NAMES.get(code, code)
        regions_list.append(RegionItem(code=code, name=name))
        
    # Sort regions consistently by region code
    regions_list.sort(key=lambda r: r.code)
    
    # Determine defaultRegion: ap-south-1 if available, otherwise backend settings AWS_DEFAULT_REGION (or us-east-1)
    default_reg = "ap-south-1" if "ap-south-1" in region_codes else (settings.AWS_DEFAULT_REGION or "us-east-1")
    
    return RegionCatalogResponse(
        regions=regions_list,
        defaultRegion=default_reg
    )

@app.post("/api/aws/region", response_model=MessageResponse)
def switch_aws_region(payload: SwitchRegionRequest):
    """
    Safely switches the region context of the current session, recreating
    the active session clients for the new region.
    """
    result = AWSSessionService.switch_region(payload.region_name)
    if not result.get("success"):
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=result.get("message", "Failed to switch region"))
    return {"message": result.get("message")}

# Include central API router containing account, ec2, s3, iam, cloudwatch, and cloudtrail endpoints
app.include_router(api_router)

# Entry point logic for uvicorn runtime execution
if __name__ == "__main__":
    import uvicorn
    # Bind to standard production port and host
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("main:app", host="0.0.0.0", port=port, reload=True)
