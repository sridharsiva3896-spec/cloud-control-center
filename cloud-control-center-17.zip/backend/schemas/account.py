from pydantic import BaseModel, Field
from typing import List, Optional

class AccountSummaryResponse(BaseModel):
    connected: bool = Field(..., description="Whether the backend successfully initiated a connection with AWS")
    account_id: Optional[str] = Field(None, description="The parsed AWS Account ID")
    account_alias: Optional[str] = Field(None, description="The primary account alias if configured")
    arn: Optional[str] = Field(None, description="The complete IAM role or user ARN of the caller identity")
    user_name: Optional[str] = Field(None, description="The resolved IAM username or parsed role session identifier")
    region: Optional[str] = Field(None, description="The active region name")
    available_regions: Optional[List[str]] = Field(None, description="List of all commercial region codes enabled on this account")
    message: str = Field(..., description="Status summary or credential instructions")
