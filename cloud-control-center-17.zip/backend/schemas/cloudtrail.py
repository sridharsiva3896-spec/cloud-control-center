from pydantic import BaseModel, Field
from typing import List, Optional
from schemas.common import BaseAWSResponse

class CloudTrailSummary(BaseModel):
    total_events: int = Field(0, description="Count of retrieved auditing events")
    unique_users: int = Field(0, description="Number of distinct IAM users/roles initiating API calls")
    event_sources: int = Field(0, description="Number of unique AWS services involved in audited API actions")

class CloudTrailEventResponse(BaseModel):
    event_id: str = Field(..., description="AWS CloudTrail unique event identifier")
    event_name: str = Field(..., description="API action name (e.g., DescribeInstances, PutBucket)")
    event_source: str = Field(..., description="Source AWS service name (e.g., ec2.amazonaws.com)")
    username: str = Field(..., description="IAM identity username or session name initiating the call")
    event_time: str = Field(..., description="ISO 8601 string of when the event transpired")
    aws_region: str = Field(..., description="Target AWS region of the event")
    resource_name: str = Field(..., description="First targeted resource name or ID, if applicable")
    resource_type: str = Field(..., description="AWS service resource type specification")
    read_only: bool = Field(..., description="Flag specifying if the API action was read-only vs a write operation")
    event_category: str = Field(..., description="The category classification of the call (e.g. Management)")
    raw_event_json: str = Field(..., description="Complete raw JSON log string payload of the event details")

class CloudTrailSummaryResponse(BaseAWSResponse):
    summary: CloudTrailSummary = Field(..., description="Audit aggregates")
    events: List[CloudTrailEventResponse] = Field(..., description="Historical timeline of events")
    enabled: bool = Field(..., description="Flag indicating if CloudTrail event query executed successfully")
    message: str = Field(..., description="General overview of logging state")
