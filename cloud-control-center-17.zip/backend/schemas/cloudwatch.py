from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from schemas.common import BaseAWSResponse

class CloudWatchSummary(BaseModel):
    monitored_instances: int = Field(0, description="Number of EC2 virtual machine instances targeted for telemetry collections")
    metrics_collected: int = Field(0, description="Total count of active individual data points successfully gathered")

class CloudWatchInstanceMetrics(BaseModel):
    cpu_utilization: Optional[float] = Field(None, description="Average percentage CPU utilization over the last hour")
    network_in: Optional[float] = Field(None, description="Average incoming network traffic volume in bytes")
    network_out: Optional[float] = Field(None, description="Average outgoing network traffic volume in bytes")
    disk_read_bytes: Optional[float] = Field(None, description="Average bytes read from disk storage volumes")
    disk_write_bytes: Optional[float] = Field(None, description="Average bytes written to disk storage volumes")

class CloudWatchInstanceTelemetry(BaseModel):
    instance_id: str = Field(..., description="Target AWS Instance ID")
    metrics: CloudWatchInstanceMetrics = Field(..., description="Metrics metrics mapping")
    last_updated: str = Field(..., description="ISO 8601 string or N/A representing the timestamp of the latest datapoint")

class CloudWatchSummaryResponse(BaseAWSResponse):
    summary: CloudWatchSummary = Field(..., description="Performance collections counters")
    instances: List[CloudWatchInstanceTelemetry] = Field(..., description="Telemetry details aggregated per instance")
    errors: Optional[Dict[str, str]] = Field(default_factory=dict, description="Granular query warnings or timeout details per target metrics key")
