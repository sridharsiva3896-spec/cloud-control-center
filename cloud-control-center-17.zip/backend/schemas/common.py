from pydantic import BaseModel, Field
from typing import Dict, Any, List, Optional

class SuccessResponse(BaseModel):
    message: str = Field(..., description="Success message describing the outcome")

class ErrorResponse(BaseModel):
    error: str = Field(..., description="Descriptive error message")
    error_type: Optional[str] = Field(None, description="The type of error categorized by the system")
    code: Optional[str] = Field(None, description="API specific error code or AWS ClientError code")

class AWSConnectionStatus(BaseModel):
    connected: bool = Field(..., description="True if connected successfully to AWS")
    region: str = Field(..., description="Active AWS region name")
    message: str = Field(..., description="Verification details message")

class HealthResponse(BaseModel):
    status: str = Field(..., description="System status health indicator (e.g. healthy)")
    aws_connection_status: AWSConnectionStatus = Field(..., description="Status of the connection to AWS services")
    version: str = Field(..., description="Version identifier of the application")
    timestamp: str = Field(..., description="UTC ISO format string representation of the current timestamp")

class AWSConnectResponse(BaseModel):
    connected: bool = Field(..., description="True if connected successfully to AWS STS")
    account_id: Optional[str] = Field(None, description="AWS Account ID")
    arn: Optional[str] = Field(None, description="IAM User or Role ARN")
    user_id: Optional[str] = Field(None, description="Unique identity identifier")
    region: Optional[str] = Field(None, description="Active AWS region")
    message: str = Field(..., description="Success or error description message")
    error_type: Optional[str] = Field(None, description="If failure, the type of exception class or trigger")
    code: Optional[str] = Field(None, description="Standard AWS ClientError error code")

class AWSConnectRequest(BaseModel):
    aws_access_key_id: str = Field(..., description="AWS IAM Access Key ID")
    aws_secret_access_key: str = Field(..., description="AWS IAM Secret Access Key")
    aws_session_token: Optional[str] = Field(None, description="AWS IAM Session Token (optional)")
    region_name: Optional[str] = Field("us-east-1", description="Default region (defaults to us-east-1)")

class PaginationResponse(BaseModel):
    total: int = Field(..., description="Total count of available items")
    limit: int = Field(..., description="Count of items requested")
    offset: int = Field(..., description="Index offset of items requested")

class TimestampResponse(BaseModel):
    timestamp: str = Field(..., description="ISO 8601 formatted timestamp string")

class MessageResponse(BaseModel):
    message: str = Field(..., description="Generic message description")

class RegionItem(BaseModel):
    code: str = Field(..., description="AWS region code (e.g. ap-south-1)")
    name: str = Field(..., description="AWS region friendly name (e.g. Mumbai)")

class RegionCatalogResponse(BaseModel):
    regions: List[RegionItem] = Field(..., description="Supported AWS regions list")
    defaultRegion: str = Field(..., description="Default selected region code")

class BaseAWSResponse(BaseModel):
    error: Optional[str] = Field(None, description="Encountered AWS service error or warning message")
