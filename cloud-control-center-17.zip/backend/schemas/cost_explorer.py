from pydantic import BaseModel, Field
from typing import List, Optional

class CostExplorerSummary(BaseModel):
    current_month_cost: float = Field(0.0, description="Sum of unblended costs incurred during the current billing month to date")
    previous_month_cost: float = Field(0.0, description="Sum of unblended costs incurred during the entire previous billing month")
    currency: str = Field("USD", description="Billing currency classification code")

class CostExplorerServiceBreakdown(BaseModel):
    service: str = Field(..., description="AWS Service name identifying cost consumer")
    cost: float = Field(..., description="Cost incurred in current month-to-date")

class CostExplorerDailyTrend(BaseModel):
    date: str = Field(..., description="ISO 8601 representation of the calendar date")
    cost: float = Field(..., description="Total unblended cost incurred on this specific date")

class CostExplorerResponse(BaseModel):
    summary: CostExplorerSummary = Field(..., description="Month-to-month comparison data")
    services: List[CostExplorerServiceBreakdown] = Field(default_factory=list, description="Service-by-service cost allocation hierarchy")
    daily_trend: List[CostExplorerDailyTrend] = Field(default_factory=list, description="Timeline trend of daily billing accruals")
    enabled: bool = Field(True, description="Flag indicating if cost explorer metrics are accessible and configured")
    message: str = Field(..., description="Status commentary or authorization detail instructions")
