from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from schemas.common import BaseAWSResponse

class EBSSummary(BaseModel):
    volumes: int = Field(0, description="Total count of discovered EBS volumes in the region")
    available: int = Field(0, description="Count of volumes currently unattached and available")
    in_use: int = Field(0, description="Count of volumes currently attached to instances")
    snapshots: int = Field(0, description="Total count of user-owned EBS snapshots")
    encrypted: int = Field(0, description="Count of volumes with encryption active")

class EBSVolumeResponse(BaseModel):
    volume_id: str = Field(..., description="The unique AWS Volume ID")
    size: int = Field(0, description="The size of the volume in gigabytes")
    volume_type: str = Field(..., description="EBS volume hardware sub-type (e.g. gp2, gp3, io1)")
    state: str = Field(..., description="The volume's connection state (e.g., in-use, available, creating)")
    iops: int = Field(0, description="Provisioned Input/Output Operations per Second")
    throughput: int = Field(0, description="Provisioned storage throughput speed in MiB/s")
    encrypted: bool = Field(False, description="Flag indicating if volume storage encryption is active")
    az: str = Field(..., description="The hosting availability zone")
    attached_instance_id: str = Field(..., description="The hosting instance ID attachment, or N/A")
    device_name: str = Field(..., description="The volume attachment block device file path, or N/A")
    create_time: str = Field(..., description="ISO 8601 creation timestamp of the volume")

class EBSSnapshotResponse(BaseModel):
    snapshot_id: str = Field(..., description="The unique AWS Snapshot ID")
    volume_id: str = Field(..., description="The origin EBS Volume ID from which this snapshot was created")
    state: str = Field(..., description="Operational readiness state (e.g., completed, pending)")
    progress: str = Field(..., description="Transfer completion percentage progress")
    start_time: str = Field(..., description="ISO 8601 formatted start timestamp")
    storage_tier: str = Field(..., description="EBS snapshot tier classification (e.g., standard, archive)")

class EBSSummaryResponse(BaseAWSResponse):
    summary: EBSSummary = Field(..., description="Metrics summaries of Amazon EBS components")
    volumes: List[EBSVolumeResponse] = Field(..., description="Discovered storage volumes")
    snapshots: List[EBSSnapshotResponse] = Field(..., description="Discovered backup snapshots")
    errors: Optional[Dict[str, str]] = Field(default_factory=dict, description="Granular query failure or permissions warnings mapping")
