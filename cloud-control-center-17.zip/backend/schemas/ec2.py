from pydantic import BaseModel, Field
from typing import List, Optional
from schemas.common import BaseAWSResponse

class EC2Summary(BaseModel):
    total: int = Field(..., description="Total number of EC2 instances identified in this region")
    running: int = Field(..., description="Number of EC2 instances currently in a running state")
    stopped: int = Field(..., description="Number of EC2 instances currently in a stopped state")

class EC2InstanceResponse(BaseModel):
    instance_id: str = Field(..., description="The unique AWS Instance ID")
    name: str = Field(..., description="The value of the Name tag, or a default fallback if untagged")
    state: str = Field(..., description="The current state of the instance (e.g., running, stopped, terminated)")
    instance_type: str = Field(..., description="The instance size profile (e.g., t2.micro, m5.large)")
    public_ip: str = Field(..., description="The assigned public IPv4 address, or N/A if none exists")
    private_ip: str = Field(..., description="The private IPv4 address assigned within the VPC")
    availability_zone: str = Field(..., description="The AWS Availability Zone of the instance")
    launch_time: str = Field(..., description="The ISO-8601 formatted timestamp representing when the instance was last launched")
    platform: str = Field(..., description="The underlying operating system platform")
    vpc_id: str = Field(..., description="The hosting Virtual Private Cloud identifier")
    subnet_id: str = Field(..., description="The hosting Subnet identifier")

class EC2SummaryResponse(BaseAWSResponse):
    summary: EC2Summary = Field(..., description="State metrics aggregation for EC2 resources in this region")
    instances: List[EC2InstanceResponse] = Field(..., description="Complete audit details of each discovered instance")
