from pydantic import BaseModel, Field
from schemas.common import AWSConnectionStatus

class HealthCheckResponse(BaseModel):
    status: str = Field(..., description="The overall system status (e.g., healthy)")
    aws_connection_status: AWSConnectionStatus = Field(..., description="The connectivity state of the AWS integration client")
    version: str = Field(..., description="The currently deployed version of the server")
    timestamp: str = Field(..., description="ISO timestamp indicating when the health check was performed")
