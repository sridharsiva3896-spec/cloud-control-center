from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from schemas.common import BaseAWSResponse

class IAMSummary(BaseModel):
    users: int = Field(0, description="Total number of IAM users")
    groups: int = Field(0, description="Total number of IAM groups")
    roles: int = Field(0, description="Total number of IAM roles")
    policies: int = Field(0, description="Total number of customer managed policies")

class IAMUserDetails(BaseModel):
    user_name: Optional[str] = Field(None, description="The unique IAM username")
    user_id: str = Field(..., description="The unique global user identifier")
    arn: str = Field(..., description="The user's Amazon Resource Name")
    create_date: str = Field(..., description="The ISO 8601 formatted creation timestamp")
    password_enabled: str = Field(..., description="Login Profile status (e.g., Enabled, Disabled, Access Denied, Unknown)")
    mfa_enabled: bool = Field(..., description="Whether the user has active MFA devices configured")
    access_key_count: int = Field(0, description="The count of active/inactive API access keys")

class IAMGroupDetails(BaseModel):
    group_name: Optional[str] = Field(None, description="The unique IAM group name")
    arn: str = Field(..., description="The group's Amazon Resource Name")
    user_count: int = Field(0, description="Count of active user memberships within this group")

class IAMRoleDetails(BaseModel):
    role_name: Optional[str] = Field(None, description="The unique IAM role name")
    arn: str = Field(..., description="The role's Amazon Resource Name")
    create_date: str = Field(..., description="The ISO 8601 formatted creation timestamp")

class IAMPolicyDetails(BaseModel):
    policy_name: Optional[str] = Field(None, description="The unique customer managed policy name")
    arn: str = Field(..., description="The policy's Amazon Resource Name")
    create_date: str = Field(..., description="The ISO 8601 formatted creation timestamp")

class IAMSummaryResponse(BaseAWSResponse):
    summary: IAMSummary = Field(..., description="Metrics summaries of Identity and Access Management elements")
    users: List[IAMUserDetails] = Field(..., description="Active IAM user details")
    groups: List[IAMGroupDetails] = Field(..., description="Active IAM group details")
    roles: List[IAMRoleDetails] = Field(..., description="Active IAM role details")
    policies: List[IAMPolicyDetails] = Field(..., description="Active customer managed policy details")
    errors: Optional[Dict[str, str]] = Field(default_factory=dict, description="Granular service-specific error mappings")
