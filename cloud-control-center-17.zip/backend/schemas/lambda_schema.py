from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from schemas.common import BaseAWSResponse

class LambdaSummary(BaseModel):
    functions: int = Field(0, description="Total count of discovered functions in this region")
    active: int = Field(0, description="Number of functions classified as Active or operational")
    failed: int = Field(0, description="Number of functions in a Failed state")

class LambdaFunctionResponse(BaseModel):
    name: str = Field(..., description="The unique name of the Lambda function")
    runtime: str = Field(..., description="The executing language runtime environment (e.g., python3.9)")
    handler: str = Field(..., description="The file entry point function name")
    memory_size: int = Field(..., description="Configured maximum allocation size in megabytes")
    timeout: int = Field(..., description="Configured maximum execution limit duration in seconds")
    last_modified: str = Field(..., description="Timestamp indicating when the function configuration was last modified")
    state: str = Field(..., description="Current deployment operational state (e.g., Active, Failed, Pending)")
    package_type: str = Field(..., description="Deployment archive package mechanism (Zip or Image)")
    architecture: str = Field(..., description="Hardware instruction architecture (e.g., x86_64 or arm64)")
    concurrency: Optional[int] = Field(None, description="Reserved concurrency limit assigned specifically to this function")

class LambdaSummaryResponse(BaseAWSResponse):
    summary: LambdaSummary = Field(..., description="Calculated aggregate metrics of Lambda deployments in this region")
    functions: List[LambdaFunctionResponse] = Field(..., description="Audit detail list of all discovered functions")
    errors: Optional[Dict[str, str]] = Field(default_factory=dict, description="Granular query failure or permissions warnings mapping")
