from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from schemas.common import BaseAWSResponse

class ELBSummary(BaseModel):
    load_balancers: int = Field(0, description="Total count of discovered load balancers")
    application_load_balancers: int = Field(0, description="Count of Application Load Balancers (ALB)")
    network_load_balancers: int = Field(0, description="Count of Network Load Balancers (NLB)")
    gateway_load_balancers: int = Field(0, description="Count of Gateway Load Balancers (GLB)")
    target_groups: int = Field(0, description="Count of discovered backend Target Groups")
    healthy_targets: int = Field(0, description="Sum count of healthy target instances in target groups")
    unhealthy_targets: int = Field(0, description="Sum count of unhealthy target instances in target groups")

class LoadBalancerDetails(BaseModel):
    name: str = Field(..., description="The unique name of the load balancer")
    arn: str = Field(..., description="The AWS Load Balancer Amazon Resource Name")
    type: str = Field(..., description="Load balancer architecture type (application, network, or gateway)")
    scheme: str = Field(..., description="Addressing route scheme (internet-facing or internal)")
    state: str = Field(..., description="Operational status code (e.g., active, provisioning, failed)")
    dns_name: str = Field(..., description="Public DNS endpoint name of the load balancer")
    vpc_id: str = Field(..., description="Hosting VPC identifier")
    availability_zones: List[str] = Field(..., description="Assigned geographical availability zones")

class TargetGroupDetails(BaseModel):
    name: str = Field(..., description="The unique Target Group name")
    arn: str = Field(..., description="The target group Amazon Resource Name")
    protocol: str = Field(..., description="Inbound packet protocols (e.g., HTTP, HTTPS, TCP)")
    port: Any = Field(..., description="Listening port configured on target instances")
    target_type: str = Field(..., description="Routing target registration type (instance, ip, lambda, or alb)")
    health_check_path: str = Field(..., description="VPC endpoint ping path for health monitoring")
    vpc_id: str = Field(..., description="Hosting VPC identifier")

class ListenerDetails(BaseModel):
    arn: str = Field(..., description="The listener's unique ARN")
    load_balancer_arn: str = Field(..., description="The associated load balancer ARN")
    protocol: str = Field(..., description="Listener port protocols (e.g., HTTP, HTTPS, TCP)")
    port: Any = Field(..., description="Incoming listener traffic connection port")
    default_actions: List[str] = Field(..., description="Categorized types of routing actions (e.g., forward)")

class TargetHealthDetails(BaseModel):
    target_group_arn: str = Field(..., description="Associated target group ARN")
    target_id: str = Field(..., description="Registered instance identifier or IP address")
    port: Any = Field(..., description="Listening port of the individual target")
    health_state: str = Field(..., description="Traffic viability state (healthy, unhealthy, initial, draining, unused)")
    health_reason: str = Field(..., description="Abbreviation code describing current non-healthy state, if applicable")
    description: str = Field(..., description="Verbose commentary details regarding health status reasons")

class LoadBalancerSummaryResponse(BaseAWSResponse):
    summary: ELBSummary = Field(..., description="Metrics aggregates for Elastic Load Balancing (ELBv2)")
    load_balancers: List[LoadBalancerDetails] = Field(..., description="Discovered load balancer records")
    target_groups: List[TargetGroupDetails] = Field(..., description="Discovered target group records")
    listeners: List[ListenerDetails] = Field(..., description="Active listeners and routing configurations")
    target_health: List[TargetHealthDetails] = Field(..., description="Target machine health status updates")
    errors: Optional[Dict[str, str]] = Field(default_factory=dict, description="Granular query failure or permissions warnings mapping")
