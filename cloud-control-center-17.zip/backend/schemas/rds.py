from pydantic import BaseModel, Field
from typing import List, Dict, Optional
from schemas.common import BaseAWSResponse

class RDSSummary(BaseModel):
    instances: int = Field(0, description="Total count of discovered database instances")
    clusters: int = Field(0, description="Total count of discovered database clusters")
    available: int = Field(0, description="Count of database instances currently available for client connections")
    stopped: int = Field(0, description="Count of stopped or stopping database instances")

class RDSInstanceResponse(BaseModel):
    identifier: str = Field(..., description="The database instance identifier")
    engine: str = Field(..., description="The database engine name (e.g., mysql, postgres, aurora-postgresql)")
    version: str = Field(..., description="The database engine version string")
    class_: str = Field(..., alias="class", description="The hardware instance class profile (e.g., db.t3.micro)")
    status: str = Field(..., description="The database connection status (e.g., available, stopped, creating)")
    storage: int = Field(0, description="Allocated storage volume in gigabytes")
    multi_az: bool = Field(False, description="Flag indicating if multi-AZ deployment is active")
    endpoint: str = Field(..., description="Resolved host endpoint and port combination string, or N/A")
    az: str = Field(..., description="The AWS availability zone of the instance")

    class Config:
        populate_by_name = True

class RDSClusterResponse(BaseModel):
    identifier: str = Field(..., description="The database cluster identifier")
    engine: str = Field(..., description="The cluster database engine type")
    version: str = Field(..., description="The cluster engine version string")
    status: str = Field(..., description="The cluster operational status")
    multi_az: bool = Field(False, description="Flag indicating multi-AZ replication status")
    members: List[str] = Field(default_factory=list, description="Detail strings of active member nodes and roles")

class RDSSummaryResponse(BaseAWSResponse):
    summary: RDSSummary = Field(..., description="Metrics summaries of Amazon RDS components")
    instances: List[RDSInstanceResponse] = Field(..., description="Discovered database instances")
    clusters: List[RDSClusterResponse] = Field(..., description="Discovered database clusters")
    errors: Optional[Dict[str, str]] = Field(default_factory=dict, description="Granular query failure or permissions warnings mapping")
