from pydantic import BaseModel, Field
from typing import List, Optional
from schemas.common import BaseAWSResponse

class S3Summary(BaseModel):
    total_buckets: int = Field(..., description="The total number of S3 buckets identified in this account")

class S3BucketResponse(BaseModel):
    name: str = Field(..., description="The globally unique S3 bucket name")
    region: str = Field(..., description="The hosting AWS region code of the bucket")
    creation_date: str = Field(..., description="The ISO-8601 formatted creation timestamp")
    versioning: str = Field(..., description="The versioning status (e.g., Enabled, Suspended, Disabled)")
    encryption: str = Field(..., description="The server-side encryption status (e.g., Enabled, Disabled, Access Denied)")
    public_access: str = Field(..., description="The public access blockage level (e.g., Blocked, Partially Blocked, Public, Access Denied)")
    arn: str = Field(..., description="The bucket's Amazon Resource Name")

class S3SummaryResponse(BaseAWSResponse):
    summary: S3Summary = Field(..., description="Computed metric summaries of S3 storage")
    buckets: List[S3BucketResponse] = Field(..., description="The list of all S3 buckets and their audited security parameters")
