from pydantic import BaseModel, Field
from typing import List, Optional

class SearchResultItem(BaseModel):
    service: str = Field(..., description="The AWS Service category namespace (e.g., EC2, S3, IAM)")
    resource_type: str = Field(..., description="The specific sub-resource entity type (e.g., Instance, Bucket, User, Group, Role)")
    name: str = Field(..., description="The human-friendly name of the resource")
    resource_id: str = Field(..., description="The unique AWS resource identifier or bucket/entity name")
    region: str = Field(..., description="The AWS region location hosting this resource, or 'Global'")

class SearchResponse(BaseModel):
    query: str = Field(..., description="The search query filter string used during the search")
    total_results: int = Field(..., description="Total count of matches discovered across all active services")
    results: List[SearchResultItem] = Field(..., description="Discovered resource match details")
