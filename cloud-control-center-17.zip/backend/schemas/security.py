from pydantic import BaseModel, Field
from typing import List, Optional
from schemas.common import BaseAWSResponse

class SecuritySummary(BaseModel):
    security_score: int = Field(..., description="Overall computed AWS account security compliance score (0-100)")
    critical: int = Field(..., description="Count of failing critical level rules")
    warning: int = Field(..., description="Count of failing warning level rules")
    passed: int = Field(..., description="Count of passing rules")

class RootAccountCheck(BaseModel):
    status: str = Field(..., description="Result status of root account usage audit (e.g., PASSED, WARNING, CRITICAL)")
    root_account_used: bool = Field(..., description="True if any root account activity is active")
    details: str = Field(..., description="Auditing commentary about root security parameters")

class UserWithoutMfa(BaseModel):
    username: str = Field(..., description="IAM username lacking MFA")
    mfa_enabled: bool = Field(..., description="MFA enrollment status")

class UserMfaCheck(BaseModel):
    status: str = Field(..., description="Result status of MFA enrollment coverage audit")
    users_without_mfa: List[UserWithoutMfa] = Field(..., description="List of username details lacking MFA protection")
    total_users: int = Field(..., description="Total count of users checked")
    error: Optional[str] = Field(None, description="Optional error message")

class OldAccessKey(BaseModel):
    username: str = Field(..., description="IAM username possessing the stale access key")
    key_id: str = Field(..., description="Stale Access Key Identifier")
    key_age_days: int = Field(..., description="Staleness age measured in days")
    status: str = Field(..., description="Failing status categorization")

class AccessKeysCheck(BaseModel):
    status: str = Field(..., description="Result status of access key age and rotation audit")
    old_keys: List[OldAccessKey] = Field(..., description="Detail list of stale access keys")
    error: Optional[str] = Field(None, description="Optional error message")

class PublicBucket(BaseModel):
    bucket_name: str = Field(..., description="S3 bucket name")
    public_access: str = Field(..., description="Access level description")

class S3PublicBucketsCheck(BaseModel):
    status: str = Field(..., description="Result status of S3 public accessibility audit")
    public_buckets: List[PublicBucket] = Field(..., description="List of S3 bucket details identified as public")
    total_buckets: int = Field(..., description="Total count of audited buckets")
    error: Optional[str] = Field(None, description="Optional error message")

class PasswordPolicyCheck(BaseModel):
    status: str = Field(..., description="Result status of overall IAM account password policy audit")
    configured: bool = Field(..., description="True if a custom password complexity policy is active")
    minimum_length: Optional[int] = Field(8, description="Minimum characters required")
    require_symbols: Optional[bool] = Field(False, description="Symbols presence requirement")
    require_numbers: Optional[bool] = Field(False, description="Numbers presence requirement")
    require_uppercase: Optional[bool] = Field(False, description="Uppercase character requirement")
    require_lowercase: Optional[bool] = Field(False, description="Lowercase character requirement")
    max_password_age: Optional[int] = Field(0, description="Optional maximum expiration age limit in days")
    details: Optional[str] = Field(None, description="Auditing commentary")
    error: Optional[str] = Field(None, description="Optional error message")

class SecurityChecks(BaseModel):
    root_account: RootAccountCheck = Field(..., description="Audit details of root credentials")
    mfa: UserMfaCheck = Field(..., description="Audit details of multi-factor authentication enrollment")
    access_keys: AccessKeysCheck = Field(..., description="Audit details of access key age compliance")
    public_buckets: S3PublicBucketsCheck = Field(..., description="Audit details of S3 bucket public visibility")
    password_policy: PasswordPolicyCheck = Field(..., description="Audit details of account password strength policy")

class SecurityResponse(BaseAWSResponse):
    summary: SecuritySummary = Field(..., description="Aggregated compliance score metrics")
    checks: SecurityChecks = Field(..., description="Full audited checklist evaluations")
    enabled: bool = Field(..., description="Flag indicating if the scanner executed completely")
    message: str = Field(..., description="Overview outcome text description")
