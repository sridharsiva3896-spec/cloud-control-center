from pydantic import BaseModel, Field
from typing import List, Optional
from schemas.common import BaseAWSResponse

class TaggedResourceResponse(BaseModel):
    arn: str = Field(..., description="The complete AWS Resource Name (ARN) of the resource")
    service: str = Field(..., description="The AWS service namespace identifying this resource (e.g., ec2, s3, iam)")
    region: str = Field(..., description="The AWS region code containing this resource, or 'global'")
    resource_type: str = Field(..., description="The resource category classification (e.g., instance, bucket, role)")
    resource_name: str = Field(..., description="The identifier or friendly name of the resource")
    tag_key: str = Field(..., description="The metadata tag Key assigned to the resource")
    tag_value: str = Field(..., description="The metadata tag Value associated with the key")

class TaggedResourcesResponse(BaseAWSResponse):
    resources: List[TaggedResourceResponse] = Field(..., description="Active list of resources and their exploded tag structures matching query parameters")
