from pydantic import BaseModel, Field
from typing import List, Dict, Any, Optional
from schemas.common import BaseAWSResponse

class TagModel(BaseModel):
    Key: str
    Value: str

class VPCSummary(BaseModel):
    vpcs: int = Field(0, description="Count of VPCs in the region")
    subnets: int = Field(0, description="Count of subnets in the region")
    route_tables: int = Field(0, description="Count of routing tables in the region")
    internet_gateways: int = Field(0, description="Count of IGWs in the region")
    nat_gateways: int = Field(0, description="Count of NAT Gateways in the region")
    security_groups: int = Field(0, description="Count of Security Groups in the region")
    network_acls: int = Field(0, description="Count of Network ACLs in the region")

class VPCDetails(BaseModel):
    vpc_id: str = Field(..., description="AWS VPC identifier")
    cidr_block: str = Field(..., description="IPv4 CIDR allocation block")
    state: str = Field(..., description="Operational state of the VPC")
    is_default: bool = Field(..., description="Flag indicating default AWS account VPC status")
    owner_id: str = Field(..., description="AWS account owner ID")
    tags: Optional[List[Dict[str, Any]]] = Field(None, description="Metadata tags assigned to the VPC")

class SubnetDetails(BaseModel):
    subnet_id: str = Field(..., description="AWS subnet identifier")
    vpc_id: str = Field(..., description="VPC identifier containing the subnet")
    cidr_block: str = Field(..., description="Allocated CIDR block")
    availability_zone: str = Field(..., description="Hosting availability zone")
    available_ip_count: int = Field(..., description="Number of unassigned IPv4 addresses in the subnet")
    state: str = Field(..., description="Subnet operational status")

class RouteTableDetails(BaseModel):
    route_table_id: str = Field(..., description="AWS Route Table identifier")
    vpc_id: str = Field(..., description="VPC containing the route table")
    routes_count: int = Field(..., description="Number of routes in this route table")
    associations_count: int = Field(..., description="Number of associated subnets/gateways")

class InternetGatewayDetails(BaseModel):
    internet_gateway_id: str = Field(..., description="AWS Internet Gateway identifier")
    attached_vpc: str = Field(..., description="VPC ID currently attached to this IGW, or 'Unattached'")

class NatGatewayDetails(BaseModel):
    nat_gateway_id: str = Field(..., description="AWS NAT Gateway identifier")
    state: str = Field(..., description="Gateway operational state")
    public_ip: str = Field(..., description="External elastic IP assigned to the gateway")
    subnet_id: str = Field(..., description="Subnet containing the gateway")
    vpc_id: str = Field(..., description="VPC hosting the gateway")

class SecurityGroupDetails(BaseModel):
    group_id: str = Field(..., description="AWS security group identifier")
    group_name: str = Field(..., description="Human-readable security group name")
    description: str = Field(..., description="Brief description of permitted scopes")
    vpc_id: str = Field(..., description="VPC hosting the security group")
    ingress_rule_count: int = Field(..., description="Total inbound traffic configuration rules")
    egress_rule_count: int = Field(..., description="Total outbound traffic configuration rules")

class NetworkAclDetails(BaseModel):
    network_acl_id: str = Field(..., description="AWS Network ACL identifier")
    vpc_id: str = Field(..., description="VPC hosting the Network ACL")
    rule_count: int = Field(..., description="Total rule entries configured in the NACL")
    is_default: bool = Field(..., description="Flag indicating if this is the default VPC NACL")

class VPCSummaryResponse(BaseAWSResponse):
    summary: VPCSummary = Field(..., description="Metrics summaries of networking components")
    vpcs: List[VPCDetails] = Field(..., description="Active VPC detail objects")
    subnets: List[SubnetDetails] = Field(..., description="Active Subnet details")
    route_tables: List[RouteTableDetails] = Field(..., description="Active Route Table details")
    internet_gateways: List[InternetGatewayDetails] = Field(..., description="Active Internet Gateway details")
    nat_gateways: List[NatGatewayDetails] = Field(..., description="Active NAT Gateway details")
    security_groups: List[SecurityGroupDetails] = Field(..., description="Active Security Group details")
    network_acls: List[NetworkAclDetails] = Field(..., description="Active Network ACL details")
    errors: Optional[Dict[str, str]] = Field(default_factory=dict, description="Granular service-specific error mappings")
