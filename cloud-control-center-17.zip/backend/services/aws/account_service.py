import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List

class AWSAccountService:
    """
    Service layer responsible for retrieving AWS Account overview metrics,
    including Account ID, Account Aliases, IAM User info, active region context,
    and resolving available geographical regions.
    """

    @staticmethod
    def get_account_overview() -> Dict[str, Any]:
        """
        Retrieves standard AWS account overview metadata using STS, IAM, and EC2.
        Grants comprehensive, defensive error bounds so partial API failures (due to lack of IAM permissions)
        do not break the response structure.
        """
        try:
            # Instantiate secure boto3 session and standard timeouts config
            session = boto3.Session()
            region = session.region_name or "us-east-1"
            
            config = Config(
                connect_timeout=5,
                read_timeout=10,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # 1. Fetch AWS Caller Identity (STS)
            try:
                sts_client = session.client("sts", config=config)
                identity = sts_client.get_caller_identity()
                account_id = identity.get("Account", "N/A")
                arn = identity.get("Arn", "N/A")
                user_id = identity.get("UserId", "N/A")
            except (NoCredentialsError, PartialCredentialsError) as e:
                return {
                    "connected": False,
                    "message": "AWS credentials not configured. Please execute 'aws configure' to build a local profile."
                }
            except ClientError as e:
                return {
                    "connected": False,
                    "message": f"AWS connection rejected by gateway: {e.response.get('Error', {}).get('Message', str(e))}"
                }
            except Exception as e:
                return {
                    "connected": False,
                    "message": f"Connection handshake system failure: {str(e)}"
                }

            # 2. Extract / Parse IAM User Name (if available)
            user_name = "N/A"
            if arn and arn != "N/A":
                # Fallback parsed user/role name
                user_name = arn.split("/")[-1]
                
            try:
                # Try fetching real IAM username if possible
                iam_client = session.client("iam", config=config)
                user_response = iam_client.get_user()
                real_name = user_response.get("User", {}).get("UserName")
                if real_name:
                    user_name = real_name
            except ClientError:
                # Graceful fallback: keep the parsed user_name from ARN if get_user lacks privileges
                pass
            except Exception:
                pass

            # 3. Fetch Account Alias (IAM ListAccountAliases)
            account_alias = "Account Alias unavailable"
            try:
                iam_client = session.client("iam", config=config)
                aliases_response = iam_client.list_account_aliases()
                aliases = aliases_response.get("AccountAliases", [])
                if aliases:
                    account_alias = aliases[0]
                else:
                    account_alias = "None"
            except ClientError as e:
                # Standard IAM permission block - handle gracefully
                account_alias = "Account Alias unavailable"
            except Exception:
                account_alias = "Account Alias unavailable"

            # 4. Fetch Available AWS Regions (EC2 DescribeRegions)
            available_regions = []
            try:
                ec2_client = session.client("ec2", config=config)
                regions_response = ec2_client.describe_regions()
                available_regions = [r.get("RegionName") for r in regions_response.get("Regions", []) if r.get("RegionName")]
            except ClientError:
                # Opt-in or access privileges denied, fallback to a standard general list containing the current region
                available_regions = [
                    region,
                    "us-east-1",
                    "us-east-2",
                    "us-west-1",
                    "us-west-2",
                    "eu-west-1",
                    "eu-central-1",
                    "ap-southeast-1",
                    "ap-southeast-2",
                    "ap-northeast-1"
                ]
                # Ensure the current region is present
                if region not in available_regions:
                    available_regions.insert(0, region)
            except Exception:
                available_regions = [region]

            return {
                "connected": True,
                "account_id": account_id,
                "account_alias": account_alias,
                "arn": arn,
                "user_name": user_name,
                "region": region,
                "available_regions": available_regions,
                "message": "AWS Account metadata queried successfully"
            }

        except Exception as e:
            return {
                "connected": False,
                "message": f"Unexpected structural overview failure: {str(e)}"
            }
