import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List
from datetime import datetime

class CloudTrailService:
    """
    Service layer responsible for auditing recent AWS API events via AWS CloudTrail lookup APIs.
    """

    @staticmethod
    def get_recent_events(region: str = None) -> Dict[str, Any]:
        """
        Retrieves the latest 50 CloudTrail events using the boto3 client.
        Provides resilient lookup_events execution within fallback boundaries.
        """
        response_data = {
            "summary": {
                "total_events": 0,
                "unique_users": 0,
                "event_sources": 0
            },
            "events": [],
            "enabled": True,
            "message": "CloudTrail events loaded successfully."
        }

        try:
            session = boto3.Session()
            config = Config(
                connect_timeout=3,
                read_timeout=6,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )
            if region:
                ct_client = session.client("cloudtrail", region_name=region, config=config)
            else:
                ct_client = session.client("cloudtrail", config=config)
        except ClientError as e:
            err_code = e.response.get("Error", {}).get("Code", "")
            err_msg = e.response.get("Error", {}).get("Message", str(e))
            if err_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in err_msg.lower() or "region" in err_msg.lower():
                msg = "Resource unavailable in this region."
            else:
                msg = f"Failed to initialize AWS CloudTrail client: {err_msg}"
            return {
                "summary": {"total_events": 0, "unique_users": 0, "event_sources": 0},
                "events": [],
                "enabled": False,
                "message": msg
            }
        except Exception as e:
            msg = str(e)
            if "unavailable" in msg.lower() or "region" in msg.lower():
                msg = "Resource unavailable in this region."
            else:
                msg = f"Failed to initialize AWS CloudTrail client: {msg}"
            return {
                "summary": {"total_events": 0, "unique_users": 0, "event_sources": 0},
                "events": [],
                "enabled": False,
                "message": msg
            }

        try:
            # lookup_events is standard AWS API to view logs of events. MaxResults=50 keeps it fast and lightweight.
            response = ct_client.lookup_events(MaxResults=50)
            events_raw = response.get("Events", [])
            
            processed_events = []
            unique_users = set()
            event_sources = set()

            for event in events_raw:
                event_id = event.get("EventId", "N/A")
                event_name = event.get("EventName", "N/A")
                event_source = event.get("EventSource", "N/A")
                username = event.get("Username", "N/A")
                
                # Format EventTime
                event_time_raw = event.get("EventTime")
                event_time_str = "N/A"
                if isinstance(event_time_raw, datetime):
                    event_time_str = event_time_raw.isoformat()
                elif event_time_raw:
                    event_time_str = str(event_time_raw)

                # Determine Region and Event Category
                region = "N/A"
                event_category = "Management"
                cloud_trail_event_str = event.get("CloudTrailEvent", "{}")
                if cloud_trail_event_str:
                    import json
                    try:
                        ct_event_dict = json.loads(cloud_trail_event_str)
                        region = ct_event_dict.get("awsRegion", "N/A")
                        event_category = ct_event_dict.get("eventCategory", "Management")
                    except Exception:
                        pass

                # Parse Resources if available
                resources = event.get("Resources", [])
                resource_name = "N/A"
                resource_type = "N/A"
                if resources:
                    first_res = resources[0]
                    resource_name = first_res.get("ResourceName", "N/A")
                    resource_type = first_res.get("ResourceType", "N/A")

                read_only = event.get("ReadOnly", True)

                # Aggregations logic
                if username and username != "N/A":
                    unique_users.add(username)
                if event_source and event_source != "N/A":
                    event_sources.add(event_source)

                processed_events.append({
                    "event_id": event_id,
                    "event_name": event_name,
                    "event_source": event_source,
                    "username": username,
                    "event_time": event_time_str,
                    "aws_region": region,
                    "resource_name": resource_name,
                    "resource_type": resource_type,
                    "read_only": read_only,
                    "event_category": event_category,
                    "raw_event_json": cloud_trail_event_str
                })

            response_data["events"] = processed_events
            response_data["summary"]["total_events"] = len(processed_events)
            response_data["summary"]["unique_users"] = len(unique_users)
            response_data["summary"]["event_sources"] = len(event_sources)

        except ClientError as e:
            err_code = e.response.get("Error", {}).get("Code", "")
            err_msg = e.response.get("Error", {}).get("Message", str(e))
            
            # Catch cases where CloudTrail is not enabled, not configured, or Access Denied
            if err_code in ["SubscriptionRequiredException", "CloudTrailARNInvalidException", "OptInRequired"] or "unavailable" in err_msg.lower() or "region" in err_msg.lower():
                return {
                    "summary": {"total_events": 0, "unique_users": 0, "event_sources": 0},
                    "events": [],
                    "enabled": False,
                    "message": "Resource unavailable in this region."
                }
            else:
                return {
                    "summary": {"total_events": 0, "unique_users": 0, "event_sources": 0},
                    "events": [],
                    "enabled": False,
                    "message": f"AWS API Access Error ({err_code}): {err_msg}"
                }
        except Exception as e:
            msg = str(e)
            if "unavailable" in msg.lower() or "region" in msg.lower():
                msg = "Resource unavailable in this region."
            else:
                msg = f"Unexpected CloudTrail auditing error: {msg}"
            return {
                "summary": {"total_events": 0, "unique_users": 0, "event_sources": 0},
                "events": [],
                "enabled": False,
                "message": msg
            }

        return response_data
