import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List
from datetime import datetime, timedelta
from services.aws.ec2_service import EC2Service

class CloudWatchService:
    """
    Service layer responsible for fetching CloudWatch performance metrics for EC2 instances.
    Uses boto3 to retrieve statistics defensively.
    """

    @staticmethod
    def get_cloudwatch_metrics(region: str = None) -> Dict[str, Any]:
        """
        Retrieves CloudWatch performance metrics (CPU, Network, Disk) for all active EC2 instances.
        Utilizes the get_metric_statistics AWS API within localized try-except blocks to prevent partial failures.
        """
        response_data = {
            "summary": {
                "monitored_instances": 0,
                "metrics_collected": 0
            },
            "instances": [],
            "errors": {}
        }

        try:
            # Fetch active EC2 instances from the existing EC2Service to discover instance targets
            ec2_data = EC2Service.get_ec2_instances(region=region)
            if "error" in ec2_data:
                response_data["error"] = ec2_data["error"]
                return response_data
            
            instances = ec2_data.get("instances", [])
            if not instances:
                return response_data

            session = boto3.Session()
            config = Config(
                connect_timeout=3,
                read_timeout=6,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )
            if region:
                cw_client = session.client("cloudwatch", region_name=region, config=config)
            else:
                cw_client = session.client("cloudwatch", config=config)
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in error_msg.lower() or "region" in error_msg.lower():
                response_data["error"] = "Resource unavailable in this region."
            else:
                response_data["error"] = f"Failed to initialize AWS CloudWatch client: {error_msg}"
            return response_data
        except Exception as e:
            msg = str(e)
            if "unavailable" in msg.lower() or "region" in msg.lower():
                response_data["error"] = "Resource unavailable in this region."
            else:
                response_data["error"] = f"Failed to initialize AWS CloudWatch client: {msg}"
            return response_data

        # CloudWatch EC2 Performance Metric targets mapping
        metric_mapping = {
            "CPUUtilization": "cpu_utilization",
            "NetworkIn": "network_in",
            "NetworkOut": "network_out",
            "DiskReadBytes": "disk_read_bytes",
            "DiskWriteBytes": "disk_write_bytes"
        }

        # Query metrics for the last 1 hour with a 5-minute aggregation period
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=1)
        period = 300

        metrics_collected_count = 0
        processed_instances = []

        for inst in instances:
            instance_id = inst.get("instance_id")
            if not instance_id or instance_id == "N/A":
                continue

            instance_metrics = {
                "cpu_utilization": None,
                "network_in": None,
                "network_out": None,
                "disk_read_bytes": None,
                "disk_write_bytes": None
            }

            latest_timestamp = None

            # Fetch each performance metric independently for the instance
            for aws_metric_name, api_key in metric_mapping.items():
                try:
                    stats_resp = cw_client.get_metric_statistics(
                        Namespace="AWS/EC2",
                        MetricName=aws_metric_name,
                        Dimensions=[{"Name": "InstanceId", "Value": instance_id}],
                        StartTime=start_time,
                        EndTime=end_time,
                        Period=period,
                        Statistics=["Average"]
                    )

                    datapoints = stats_resp.get("Datapoints", [])
                    if datapoints:
                        # Sort descending by Timestamp to isolate the latest data value
                        datapoints.sort(key=lambda x: x["Timestamp"], reverse=True)
                        latest_point = datapoints[0]
                        avg_val = latest_point.get("Average")
                        
                        instance_metrics[api_key] = avg_val
                        metrics_collected_count += 1

                        # Keep track of the most recent data point timestamp for user table auditing
                        ts = latest_point.get("Timestamp")
                        if ts:
                            if latest_timestamp is None or ts > latest_timestamp:
                                latest_timestamp = ts

                except ClientError as e:
                    # Collect error state information instead of throwing complete thread failure
                    err_code = e.response.get("Error", {}).get("Code", "UnknownError")
                    err_msg = e.response.get("Error", {}).get("Message", str(e))
                    response_data["errors"][f"{instance_id}_{api_key}"] = f"CloudWatch API {err_code}: {err_msg}"
                except Exception as e:
                    response_data["errors"][f"{instance_id}_{api_key}"] = f"Unexpected query error: {str(e)}"

            # ISO string representation of latest audit update
            last_updated_str = "N/A"
            if isinstance(latest_timestamp, datetime):
                last_updated_str = latest_timestamp.isoformat()
            elif latest_timestamp:
                last_updated_str = str(latest_timestamp)

            processed_instances.append({
                "instance_id": instance_id,
                "metrics": instance_metrics,
                "last_updated": last_updated_str
            })

        response_data["instances"] = processed_instances
        response_data["summary"]["monitored_instances"] = len(processed_instances)
        response_data["summary"]["metrics_collected"] = metrics_collected_count

        return response_data
