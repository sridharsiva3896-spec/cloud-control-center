import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List
from datetime import datetime, date, timedelta

class AWSCostExplorerService:
    """
    Service layer responsible for auditing AWS Cost and Usage via Cost Explorer API.
    """

    @staticmethod
    def get_cost_and_usage_data() -> Dict[str, Any]:
        """
        Retrieves Cost Explorer analytics including current month cost, previous month cost,
        cost grouped by AWS Service, and daily cost trend for the current month.
        """
        response_data = {
            "summary": {
                "current_month_cost": 0.0,
                "previous_month_cost": 0.0,
                "currency": "USD"
            },
            "services": [],
            "daily_trend": [],
            "enabled": True,
            "message": "Cost Explorer metrics loaded successfully."
        }

        try:
            # AWS Cost Explorer is generally located in us-east-1
            session = boto3.Session()
            config = Config(
                connect_timeout=5,
                read_timeout=10,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )
            ce_client = session.client("ce", region_name="us-east-1", config=config)
        except Exception as e:
            return {
                "summary": {"current_month_cost": 0.0, "previous_month_cost": 0.0, "currency": "USD"},
                "services": [],
                "daily_trend": [],
                "enabled": False,
                "message": f"Failed to initialize AWS Cost Explorer client: {str(e)}"
            }

        # Calculate dates
        today = date.today()
        current_month_start = today.replace(day=1)
        
        # Current month range for API: Start inclusive, End exclusive
        current_month_start_str = current_month_start.strftime("%Y-%m-%d")
        current_month_end_str = (today + timedelta(days=1)).strftime("%Y-%m-%d")

        # Previous month range
        if current_month_start.month == 1:
            prev_month_start = current_month_start.replace(year=current_month_start.year - 1, month=12)
        else:
            prev_month_start = current_month_start.replace(month=current_month_start.month - 1)
        prev_month_end = current_month_start  # 1st of current month is exclusive end for previous month
        
        prev_month_start_str = prev_month_start.strftime("%Y-%m-%d")
        prev_month_end_str = prev_month_end.strftime("%Y-%m-%d")

        try:
            # 1. Get current month total cost
            try:
                current_total_res = ce_client.get_cost_and_usage(
                    TimePeriod={
                        "Start": current_month_start_str,
                        "End": current_month_end_str
                    },
                    Granularity="MONTHLY",
                    Metrics=["UnblendedCost"]
                )
                results = current_total_res.get("ResultsByTime", [])
                if results:
                    amount_str = results[0].get("Total", {}).get("UnblendedCost", {}).get("Amount", "0.0")
                    currency = results[0].get("Total", {}).get("UnblendedCost", {}).get("Unit", "USD")
                    response_data["summary"]["current_month_cost"] = round(float(amount_str), 2)
                    response_data["summary"]["currency"] = currency
            except Exception as e_curr:
                # Fallback logging or partial error handling
                pass

            # 2. Get previous month total cost
            try:
                prev_total_res = ce_client.get_cost_and_usage(
                    TimePeriod={
                        "Start": prev_month_start_str,
                        "End": prev_month_end_str
                    },
                    Granularity="MONTHLY",
                    Metrics=["UnblendedCost"]
                )
                results_prev = prev_total_res.get("ResultsByTime", [])
                if results_prev:
                    amount_str = results_prev[0].get("Total", {}).get("UnblendedCost", {}).get("Amount", "0.0")
                    response_data["summary"]["previous_month_cost"] = round(float(amount_str), 2)
            except Exception as e_prev:
                pass

            # 3. Get cost grouped by AWS Service for current month
            try:
                service_res = ce_client.get_cost_and_usage(
                    TimePeriod={
                        "Start": current_month_start_str,
                        "End": current_month_end_str
                    },
                    Granularity="MONTHLY",
                    Metrics=["UnblendedCost"],
                    GroupBy=[
                        {
                            "Type": "DIMENSION",
                            "Key": "SERVICE"
                        }
                    ]
                )
                service_items = []
                results_service = service_res.get("ResultsByTime", [])
                if results_service:
                    groups = results_service[0].get("Groups", [])
                    for g in groups:
                        service_name = g.get("Keys", ["Unknown"])[0]
                        amount_str = g.get("Metrics", {}).get("UnblendedCost", {}).get("Amount", "0.0")
                        cost_val = round(float(amount_str), 2)
                        if cost_val > 0.0:
                            service_items.append({
                                "service": service_name,
                                "cost": cost_val
                            })
                # Sort services by cost descending
                service_items.sort(key=lambda x: x["cost"], reverse=True)
                response_data["services"] = service_items
            except Exception as e_srv:
                pass

            # 4. Get daily cost trend for the current month
            try:
                daily_res = ce_client.get_cost_and_usage(
                    TimePeriod={
                        "Start": current_month_start_str,
                        "End": current_month_end_str
                    },
                    Granularity="DAILY",
                    Metrics=["UnblendedCost"]
                )
                trend_items = []
                results_daily = daily_res.get("ResultsByTime", [])
                for day_data in results_daily:
                    date_str = day_data.get("TimePeriod", {}).get("Start", "")
                    amount_str = day_data.get("Total", {}).get("UnblendedCost", {}).get("Amount", "0.0")
                    cost_val = round(float(amount_str), 2)
                    trend_items.append({
                        "date": date_str,
                        "cost": cost_val
                    })
                response_data["daily_trend"] = trend_items
            except Exception as e_daily:
                pass

        except ClientError as e:
            err_code = e.response.get("Error", {}).get("Code", "")
            err_msg = e.response.get("Error", {}).get("Message", str(e))
            
            # Catch cases where Cost Explorer is not enabled, not configured, or Access Denied
            if err_code in ["AccessDeniedException", "DataUnavailableException", "SubscriptionRequiredException", "ValidationException"]:
                return {
                    "summary": {"current_month_cost": 0.0, "previous_month_cost": 0.0, "currency": "USD"},
                    "services": [],
                    "daily_trend": [],
                    "enabled": False,
                    "message": "AWS Cost Explorer data is not available."
                }
            else:
                return {
                    "summary": {"current_month_cost": 0.0, "previous_month_cost": 0.0, "currency": "USD"},
                    "services": [],
                    "daily_trend": [],
                    "enabled": False,
                    "message": f"AWS API Access Error ({err_code}): {err_msg}"
                }
        except Exception as e:
            return {
                "summary": {"current_month_cost": 0.0, "previous_month_cost": 0.0, "currency": "USD"},
                "services": [],
                "daily_trend": [],
                "enabled": False,
                "message": f"Unexpected Cost Explorer auditing error: {str(e)}"
            }

        return response_data
