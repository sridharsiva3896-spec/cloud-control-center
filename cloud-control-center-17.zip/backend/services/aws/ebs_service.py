import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List

class EBSService:
    """
    Service layer responsible for monitoring and querying AWS EBS (Elastic Block Store)
    volumes and snapshots safely in the selected AWS region.
    """

    @staticmethod
    def get_ebs_monitoring(region: str = None) -> Dict[str, Any]:
        """
        Retrieves Amazon EBS volumes and user-owned snapshots in the region, aggregates metrics,
        and constructs the response. Uses try-except blocks to catch specific AccessDenied or ClientErrors.
        """
        response_payload = {
            "summary": {
                "volumes": 0,
                "available": 0,
                "in_use": 0,
                "snapshots": 0,
                "encrypted": 0
            },
            "volumes": [],
            "snapshots": [],
            "errors": {}
        }

        try:
            # Localized boto3 configuration
            session = boto3.Session()
            config = Config(
                connect_timeout=4,
                read_timeout=8,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # Establish EC2 client (EBS resides in EC2 namespace)
            if region:
                ec2_client = session.client("ec2", region_name=region, config=config)
            else:
                ec2_client = session.client("ec2", config=config)

            # 1. Fetch EBS Volumes
            volumes_list = []
            try:
                paginator = ec2_client.get_paginator("describe_volumes")
                pages = paginator.paginate()
                for page in pages:
                    for vol in page.get("Volumes", []):
                        vol_id = vol.get("VolumeId", "N/A")
                        size = vol.get("Size", 0)
                        vol_type = vol.get("VolumeType", "N/A")
                        state = vol.get("State", "N/A")
                        iops = vol.get("Iops", 0)
                        throughput = vol.get("Throughput", 0)
                        encrypted = vol.get("Encrypted", False)
                        az = vol.get("AvailabilityZone", "N/A")

                        # Handle attached instance details safely
                        attachments = vol.get("Attachments", [])
                        attached_instance_id = "N/A"
                        device_name = "N/A"
                        if attachments:
                            att = attachments[0]
                            attached_instance_id = att.get("InstanceId", "N/A")
                            device_name = att.get("Device", "N/A")

                        create_time = "N/A"
                        if vol.get("CreateTime"):
                            try:
                                create_time = vol.get("CreateTime").isoformat()
                            except Exception:
                                create_time = str(vol.get("CreateTime"))

                        volumes_list.append({
                            "volume_id": vol_id,
                            "size": size,
                            "volume_type": vol_type,
                            "state": state,
                            "iops": iops,
                            "throughput": throughput,
                            "encrypted": encrypted,
                            "az": az,
                            "attached_instance_id": attached_instance_id,
                            "device_name": device_name,
                            "create_time": create_time
                        })
                response_payload["volumes"] = volumes_list
            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "")
                error_msg = e.response.get("Error", {}).get("Message", str(e))
                
                if error_code == "AccessDenied":
                    response_payload["errors"]["volumes"] = "Access Denied: Missing ec2:DescribeVolumes permissions."
                else:
                    response_payload["errors"]["volumes"] = error_msg

            # 2. Fetch EBS Snapshots (Filtering to 'self' to avoid massive public snapshot lists)
            snapshots_list = []
            try:
                paginator_snap = ec2_client.get_paginator("describe_snapshots")
                # CRITICAL: Always use OwnerIds=['self'] for describe_snapshots
                pages_snap = paginator_snap.paginate(OwnerIds=["self"])
                for page in pages_snap:
                    for snap in page.get("Snapshots", []):
                        snap_id = snap.get("SnapshotId", "N/A")
                        snap_vol_id = snap.get("VolumeId", "N/A")
                        state = snap.get("State", "N/A")
                        progress = snap.get("Progress", "N/A")
                        storage_tier = snap.get("StorageTier", "N/A")

                        start_time = "N/A"
                        if snap.get("StartTime"):
                            try:
                                start_time = snap.get("StartTime").isoformat()
                            except Exception:
                                start_time = str(snap.get("StartTime"))

                        snapshots_list.append({
                            "snapshot_id": snap_id,
                            "volume_id": snap_vol_id,
                            "state": state,
                            "progress": progress,
                            "start_time": start_time,
                            "storage_tier": storage_tier
                        })
                response_payload["snapshots"] = snapshots_list
            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "")
                error_msg = e.response.get("Error", {}).get("Message", str(e))
                
                if error_code == "AccessDenied":
                    response_payload["errors"]["snapshots"] = "Access Denied: Missing ec2:DescribeSnapshots permissions."
                else:
                    response_payload["errors"]["snapshots"] = error_msg

            # 3. Process aggregates and totals for the summary dashboards
            available_count = sum(1 for vol in volumes_list if vol["state"].lower() == "available")
            in_use_count = sum(1 for vol in volumes_list if vol["state"].lower() == "in-use")
            encrypted_count = sum(1 for vol in volumes_list if vol["encrypted"])

            response_payload["summary"] = {
                "volumes": len(volumes_list),
                "available": available_count,
                "in_use": in_use_count,
                "snapshots": len(snapshots_list),
                "encrypted": encrypted_count
            }

            # If there's an overarching permission block or regional failure, format as service failure
            if "volumes" in response_payload["errors"] and "snapshots" in response_payload["errors"]:
                response_payload["error"] = "Access Denied or EC2 Endpoint unreachable in this AWS account region."

            return response_payload

        except (NoCredentialsError, PartialCredentialsError):
            return {
                **response_payload,
                "error": "AWS credentials are not configured on the environment host."
            }
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in error_msg.lower() or "region" in error_msg.lower():
                msg = "EBS telemetry resources are currently unavailable in this AWS region."
            else:
                msg = f"AWS EBS Handshake Warning: {error_msg}"
            return {
                **response_payload,
                "error": msg
            }
        except Exception as e:
            return {
                **response_payload,
                "error": f"An unexpected system failure occurred: {str(e)}"
            }
