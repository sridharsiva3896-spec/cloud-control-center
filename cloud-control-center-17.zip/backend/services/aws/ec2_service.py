import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List
from datetime import datetime

class EC2Service:
    """
    Service layer responsible for monitoring and querying EC2 virtual machines on AWS.
    Queries the EC2 DescribeInstances API and extracts critical visual/operational details safely.
    """

    @staticmethod
    def get_ec2_instances(region: str = None) -> Dict[str, Any]:
        """
        Retrieves a list of EC2 instances from the AWS account and computes a summary of states.
        
        Returns:
            Dict containing summary (total, running, stopped) and detailed instances array.
        """
        empty_response = {
            "summary": {
                "total": 0,
                "running": 0,
                "stopped": 0
            },
            "instances": []
        }

        try:
            # Create a localized secure Session and config parameters
            session = boto3.Session()
            config = Config(
                connect_timeout=5,
                read_timeout=10,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # Initialize the EC2 client
            if region:
                ec2_client = session.client("ec2", region_name=region, config=config)
            else:
                ec2_client = session.client("ec2", config=config)
            
            # Query the EC2 instances
            response = ec2_client.describe_instances()
            
            reservations = response.get("Reservations", [])
            instances_list: List[Dict[str, Any]] = []
            
            total = 0
            running = 0
            stopped = 0

            for reservation in reservations:
                for inst in reservation.get("Instances", []):
                    total += 1
                    
                    # 1. Extract instance state details
                    state = inst.get("State", {}).get("Name", "unknown")
                    if state == "running":
                        running += 1
                      # Any state that is "stopped" can be counted here (or we can match "stopped" literally)
                    elif state == "stopped":
                        stopped += 1

                    # 2. Extract Instance Name tag
                    name = "Unnamed Instance"
                    tags = inst.get("Tags", [])
                    for tag in tags:
                        if tag.get("Key") == "Name":
                            name = tag.get("Value", "Unnamed Instance")
                            break

                    # 3. Format LaunchTime
                    launch_time_raw = inst.get("LaunchTime")
                    launch_time_str = "N/A"
                    if isinstance(launch_time_raw, datetime):
                        launch_time_str = launch_time_raw.isoformat()
                    elif launch_time_raw:
                        launch_time_str = str(launch_time_raw)

                    # 4. Construct response dictionary with safe defaults
                    instance_data = {
                        "instance_id": inst.get("InstanceId", "N/A"),
                        "name": name,
                        "state": state,
                        "instance_type": inst.get("InstanceType", "N/A"),
                        "public_ip": inst.get("PublicIpAddress", "N/A"),
                        "private_ip": inst.get("PrivateIpAddress", "N/A"),
                        "availability_zone": inst.get("Placement", {}).get("AvailabilityZone", "N/A"),
                        "launch_time": launch_time_str,
                        "platform": inst.get("Platform", "Linux/Unix"),
                        "vpc_id": inst.get("VpcId", "N/A"),
                        "subnet_id": inst.get("SubnetId", "N/A")
                    }
                    instances_list.append(instance_data)

            return {
                "summary": {
                    "total": total,
                    "running": running,
                    "stopped": stopped
                },
                "instances": instances_list
            }

        except (NoCredentialsError, PartialCredentialsError) as e:
            # Handle credential blockages cleanly without raising backend errors
            return {
                "summary": {
                    "total": 0,
                    "running": 0,
                    "stopped": 0
                },
                "instances": [],
                "error": "AWS credentials not configured on the environment host."
            }
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in error_msg.lower() or "region" in error_msg.lower():
                msg = "Resource unavailable in this region."
            else:
                msg = f"AWS Service Error: {error_msg}"
            return {
                "summary": {
                    "total": 0,
                    "running": 0,
                    "stopped": 0
                },
                "instances": [],
                "error": msg
            }
        except Exception as e:
            return {
                "summary": {
                    "total": 0,
                    "running": 0,
                    "stopped": 0
                },
                "instances": [],
                "error": f"An unexpected system failure occurred: {str(e)}"
            }
