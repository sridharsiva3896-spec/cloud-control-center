import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List
from datetime import datetime

class IAMService:
    """
    Service layer responsible for monitoring and auditing Identity and Access Management (IAM) configurations.
    Uses boto3 to list users, roles, groups, and customer-managed policies defensively.
    """

    @staticmethod
    def get_iam_overview() -> Dict[str, Any]:
        """
        Retrieves a complete audit of IAM security entities.
        Encapsulates each entity query (Users, Groups, Roles, Policies) inside its own try-except boundary,
        ensuring that partial permission blocks (e.g. AccessDenied on Policies) do not trigger a full request failure.
        """
        # Define clean, safe defaults
        response_data = {
            "summary": {
                "users": 0,
                "groups": 0,
                "roles": 0,
                "policies": 0
            },
            "users": [],
            "groups": [],
            "roles": [],
            "policies": [],
            "errors": {}
        }

        try:
            # Create standard session and low-timeout configurations
            session = boto3.Session()
            config = Config(
                connect_timeout=3,
                read_timeout=6,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )
            iam_client = session.client("iam", config=config)
        except Exception as e:
            # Handshake or initialization error
            response_data["errors"]["global"] = f"Failed to initialize AWS IAM client: {str(e)}"
            return response_data

        # ----------------------------------------------------
        # 1. AUDIT IAM USERS
        # ----------------------------------------------------
        try:
            users_resp = iam_client.list_users()
            users_raw = users_resp.get("Users", [])
            users_processed = []

            for u in users_raw:
                user_name = u.get("UserName")
                user_id = u.get("UserId", "N/A")
                arn = u.get("Arn", "N/A")
                
                # Format CreateDate
                create_date_raw = u.get("CreateDate")
                create_date_str = "N/A"
                if isinstance(create_date_raw, datetime):
                    create_date_str = create_date_raw.isoformat()
                elif create_date_raw:
                    create_date_str = str(create_date_raw)

                # Initialize defaults for detailed security controls
                password_enabled = "Unknown"
                mfa_enabled = False
                access_key_count = 0

                # Determine if user has a login profile (password enabled)
                if user_name:
                    try:
                        iam_client.get_login_profile(UserName=user_name)
                        password_enabled = "Enabled"
                    except ClientError as e:
                        err_code = e.response.get("Error", {}).get("Code")
                        if err_code == "NoSuchEntity":
                            password_enabled = "Disabled"
                        elif err_code == "AccessDenied":
                            password_enabled = "Access Denied"
                        else:
                            password_enabled = "Unknown"
                    except Exception:
                        password_enabled = "Unknown"

                    # Check for active MFA devices
                    try:
                        mfa_resp = iam_client.list_mfa_devices(UserName=user_name)
                        mfa_devices = mfa_resp.get("MFADevices", [])
                        mfa_enabled = len(mfa_devices) > 0
                    except ClientError as e:
                        # Fallback silently or flag warning
                        pass
                    except Exception:
                        pass

                    # Fetch active Access Key Count
                    try:
                        keys_resp = iam_client.list_access_keys(UserName=user_name)
                        access_keys = keys_resp.get("AccessKeyMetadata", [])
                        access_key_count = len(access_keys)
                    except ClientError:
                        pass
                    except Exception:
                        pass

                users_processed.append({
                    "user_name": user_name,
                    "user_id": user_id,
                    "arn": arn,
                    "create_date": create_date_str,
                    "password_enabled": password_enabled,
                    "mfa_enabled": mfa_enabled,
                    "access_key_count": access_key_count
                })

            response_data["users"] = users_processed
            response_data["summary"]["users"] = len(users_processed)

        except ClientError as e:
            response_data["errors"]["users"] = f"Access Denied or API failure listing users: {e.response.get('Error', {}).get('Message', str(e))}"
        except Exception as e:
            response_data["errors"]["users"] = f"Unexpected failure listing users: {str(e)}"


        # ----------------------------------------------------
        # 2. AUDIT IAM GROUPS
        # ----------------------------------------------------
        try:
            groups_resp = iam_client.list_groups()
            groups_raw = groups_resp.get("Groups", [])
            groups_processed = []

            for g in groups_raw:
                group_name = g.get("GroupName")
                arn = g.get("Arn", "N/A")
                user_count = 0

                # Count active group memberships via get_group API
                if group_name:
                    try:
                        g_details = iam_client.get_group(GroupName=group_name)
                        user_count = len(g_details.get("Users", []))
                    except ClientError:
                        user_count = 0

                groups_processed.append({
                    "group_name": group_name,
                    "arn": arn,
                    "user_count": user_count
                })

            response_data["groups"] = groups_processed
            response_data["summary"]["groups"] = len(groups_processed)

        except ClientError as e:
            response_data["errors"]["groups"] = f"Access Denied or API failure listing groups: {e.response.get('Error', {}).get('Message', str(e))}"
        except Exception as e:
            response_data["errors"]["groups"] = f"Unexpected failure listing groups: {str(e)}"


        # ----------------------------------------------------
        # 3. AUDIT IAM ROLES
        # ----------------------------------------------------
        try:
            roles_resp = iam_client.list_roles()
            roles_raw = roles_resp.get("Roles", [])
            roles_processed = []

            for r in roles_raw:
                role_name = r.get("RoleName")
                arn = r.get("Arn", "N/A")
                
                # Format CreateDate
                create_date_raw = r.get("CreateDate")
                create_date_str = "N/A"
                if isinstance(create_date_raw, datetime):
                    create_date_str = create_date_raw.isoformat()
                elif create_date_raw:
                    create_date_str = str(create_date_raw)

                roles_processed.append({
                    "role_name": role_name,
                    "arn": arn,
                    "create_date": create_date_str
                })

            response_data["roles"] = roles_processed
            response_data["summary"]["roles"] = len(roles_processed)

        except ClientError as e:
            response_data["errors"]["roles"] = f"Access Denied or API failure listing roles: {e.response.get('Error', {}).get('Message', str(e))}"
        except Exception as e:
            response_data["errors"]["roles"] = f"Unexpected failure listing roles: {str(e)}"


        # ----------------------------------------------------
        # 4. AUDIT CUSTOMER MANAGED POLICIES
        # ----------------------------------------------------
        try:
            # Scope='Local' retrieves customer managed policies specifically
            policies_resp = iam_client.list_policies(Scope="Local")
            policies_raw = policies_resp.get("Policies", [])
            policies_processed = []

            for p in policies_raw:
                policy_name = p.get("PolicyName")
                arn = p.get("Arn", "N/A")
                
                # Format CreateDate
                create_date_raw = p.get("CreateDate")
                create_date_str = "N/A"
                if isinstance(create_date_raw, datetime):
                    create_date_str = create_date_raw.isoformat()
                elif create_date_raw:
                    create_date_str = str(create_date_raw)

                policies_processed.append({
                    "policy_name": policy_name,
                    "arn": arn,
                    "create_date": create_date_str
                })

            response_data["policies"] = policies_processed
            response_data["summary"]["policies"] = len(policies_processed)

        except ClientError as e:
            response_data["errors"]["policies"] = f"Access Denied or API failure listing policies: {e.response.get('Error', {}).get('Message', str(e))}"
        except Exception as e:
            response_data["errors"]["policies"] = f"Unexpected failure listing policies: {str(e)}"

        return response_data
