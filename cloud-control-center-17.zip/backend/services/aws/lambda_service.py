import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List, Optional
from datetime import datetime

class LambdaService:
    """
    Service layer responsible for monitoring and querying AWS Lambda functions safely
    in the selected AWS region.
    """

    @staticmethod
    def get_lambda_monitoring(region: str = None) -> Dict[str, Any]:
        """
        Gathers AWS Lambda functions in the region, aggregates metrics, and builds the response.
        """
        response_payload = {
            "summary": {
                "functions": 0,
                "active": 0,
                "failed": 0
            },
            "functions": [],
            "errors": {}
        }

        try:
            # Localized boto3 configuration
            session = boto3.Session()
            config = Config(
                connect_timeout=4,
                read_timeout=8,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # Establish Lambda client
            if region:
                lambda_client = session.client("lambda", region_name=region, config=config)
            else:
                lambda_client = session.client("lambda", config=config)

            # Call list_functions
            functions_list = []
            try:
                paginator = lambda_client.get_paginator("list_functions")
                pages = paginator.paginate()
                
                for page in pages:
                    for fn in page.get("Functions", []):
                        fn_name = fn.get("FunctionName", "N/A")
                        
                        # Get basic configurations
                        runtime = fn.get("Runtime", "N/A")
                        handler = fn.get("Handler", "N/A")
                        memory_size = fn.get("MemorySize", 0)
                        timeout = fn.get("Timeout", 0)
                        last_modified = fn.get("LastModified", "N/A")
                        package_type = fn.get("PackageType", "N/A")
                        
                        # Handle architectures safely (e.g. ['x86_64'])
                        architectures = fn.get("Architectures", ["x86_64"])
                        architecture = architectures[0] if architectures else "x86_64"
                        
                        # State is only available on some functions/configs, default to 'Active'
                        state = fn.get("State", "Active")

                        # Try to get reserved concurrency for this function
                        concurrency = None
                        try:
                            fn_details = lambda_client.get_function(FunctionName=fn_name)
                            concurrency_config = fn_details.get("Concurrency", {})
                            concurrency = concurrency_config.get("ReservedConcurrentExecutions")
                        except ClientError as ce:
                            # It's fine if we can't get concurrency for a specific function, skip or log
                            pass

                        functions_list.append({
                            "name": fn_name,
                            "runtime": runtime,
                            "handler": handler,
                            "memory_size": memory_size,
                            "timeout": timeout,
                            "last_modified": last_modified,
                            "state": state,
                            "package_type": package_type,
                            "architecture": architecture,
                            "concurrency": concurrency
                        })

                # Process summaries
                active_count = sum(1 for f in functions_list if f["state"] == "Active")
                failed_count = sum(1 for f in functions_list if f["state"] == "Failed")
                
                response_payload["functions"] = functions_list
                response_payload["summary"] = {
                    "functions": len(functions_list),
                    "active": active_count,
                    "failed": failed_count
                }

            except ClientError as e:
                response_payload["errors"]["list_functions"] = e.response.get("Error", {}).get("Message", str(e))
                return {
                    **response_payload,
                    "error": f"Failed to retrieve Lambda list: {e.response.get('Error', {}).get('Message')}"
                }

            return response_payload

        except (NoCredentialsError, PartialCredentialsError):
            return {
                **response_payload,
                "error": "AWS credentials are not configured on the environment host."
            }
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in error_msg.lower() or "region" in error_msg.lower():
                msg = "Lambda telemetry resources are currently unavailable in this AWS region."
            else:
                msg = f"AWS Lambda Handshake Warning: {error_msg}"
            return {
                **response_payload,
                "error": msg
            }
        except Exception as e:
            return {
                **response_payload,
                "error": f"An unexpected system failure occurred: {str(e)}"
            }

    @staticmethod
    def list_functions(region: str = None) -> List[Dict[str, Any]]:
        """
        Lists AWS Lambda functions in the region.
        """
        session = boto3.Session()
        lambda_client = session.client("lambda", region_name=region)
        response = lambda_client.list_functions()
        return response.get("Functions", [])

    @staticmethod
    def get_function_configuration(function_name: str, region: str = None) -> Dict[str, Any]:
        """
        Retrieves configuration metadata for a specific Lambda function.
        """
        session = boto3.Session()
        lambda_client = session.client("lambda", region_name=region)
        return lambda_client.get_function_configuration(FunctionName=function_name)

    @staticmethod
    def get_function(function_name: str, region: str = None) -> Dict[str, Any]:
        """
        Retrieves the details and configuration of a specific Lambda function.
        """
        session = boto3.Session()
        lambda_client = session.client("lambda", region_name=region)
        return lambda_client.get_function(FunctionName=function_name)
