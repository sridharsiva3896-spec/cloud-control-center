import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List

class LoadBalancerService:
    """
    Service layer responsible for monitoring and querying AWS Elastic Load Balancing (ELB v2)
    components safely in the selected AWS region.
    """

    @staticmethod
    def get_load_balancers_monitoring(region: str = None) -> Dict[str, Any]:
        """
        Gathers AWS Elastic Load Balancing (ALB/NLB/GLB) components and aggregates metrics.
        Runs granular individual try-except clauses per resource call to ensure 
        resilience against partial API access restrictions.
        """
        response_payload = {
            "summary": {
                "load_balancers": 0,
                "application_load_balancers": 0,
                "network_load_balancers": 0,
                "gateway_load_balancers": 0,
                "target_groups": 0,
                "healthy_targets": 0,
                "unhealthy_targets": 0
            },
            "load_balancers": [],
            "target_groups": [],
            "listeners": [],
            "target_health": [],
            "errors": {}
        }

        try:
            # Localized boto3 configuration
            session = boto3.Session()
            config = Config(
                connect_timeout=4,
                read_timeout=8,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # Establish ELBv2 client
            if region:
                elbv2_client = session.client("elbv2", region_name=region, config=config)
            else:
                elbv2_client = session.client("elbv2", config=config)

            # 1. Query Load Balancers
            lbs_list = []
            try:
                lbs_resp = elbv2_client.describe_load_balancers()
                for lb in lbs_resp.get("LoadBalancers", []):
                    lb_type = lb.get("Type", "application")
                    lbs_list.append({
                        "name": lb.get("LoadBalancerName", "N/A"),
                        "arn": lb.get("LoadBalancerArn", "N/A"),
                        "type": lb_type,
                        "scheme": lb.get("Scheme", "N/A"),
                        "state": lb.get("State", {}).get("Code", "N/A"),
                        "dns_name": lb.get("DNSName", "N/A"),
                        "vpc_id": lb.get("VpcId", "N/A"),
                        "availability_zones": [az.get("ZoneName") for az in lb.get("AvailabilityZones", []) if az.get("ZoneName")]
                    })

                    if lb_type == "application":
                        response_payload["summary"]["application_load_balancers"] += 1
                    elif lb_type == "network":
                        response_payload["summary"]["network_load_balancers"] += 1
                    elif lb_type == "gateway":
                        response_payload["summary"]["gateway_load_balancers"] += 1

                response_payload["load_balancers"] = lbs_list
                response_payload["summary"]["load_balancers"] = len(lbs_list)
            except ClientError as e:
                response_payload["errors"]["load_balancers"] = e.response.get("Error", {}).get("Message", str(e))

            # 2. Query Target Groups
            tgs_list = []
            try:
                tgs_resp = elbv2_client.describe_target_groups()
                for tg in tgs_resp.get("TargetGroups", []):
                    tgs_list.append({
                        "name": tg.get("TargetGroupName", "N/A"),
                        "arn": tg.get("TargetGroupArn", "N/A"),
                        "protocol": tg.get("Protocol", "N/A"),
                        "port": tg.get("Port", "N/A"),
                        "target_type": tg.get("TargetType", "N/A"),
                        "health_check_path": tg.get("HealthCheckPath", "N/A"),
                        "vpc_id": tg.get("VpcId", "N/A")
                    })
                response_payload["target_groups"] = tgs_list
                response_payload["summary"]["target_groups"] = len(tgs_list)
            except ClientError as e:
                response_payload["errors"]["target_groups"] = e.response.get("Error", {}).get("Message", str(e))

            # 3. Query Listeners per Load Balancer
            listeners_list = []
            if lbs_list:
                for lb in lbs_list:
                    lb_arn = lb["arn"]
                    try:
                        lis_resp = elbv2_client.describe_listeners(LoadBalancerArn=lb_arn)
                        for lis in lis_resp.get("Listeners", []):
                            listeners_list.append({
                                "arn": lis.get("ListenerArn", "N/A"),
                                "load_balancer_arn": lis.get("LoadBalancerArn", "N/A"),
                                "protocol": lis.get("Protocol", "N/A"),
                                "port": lis.get("Port", "N/A"),
                                "default_actions": [act.get("Type") for act in lis.get("DefaultActions", []) if act.get("Type")]
                            })
                    except ClientError as e:
                        response_payload["errors"][f"listeners_{lb_arn}"] = e.response.get("Error", {}).get("Message", str(e))
            response_payload["listeners"] = listeners_list

            # 4. Query Target Health per Target Group
            th_list = []
            healthy_count = 0
            unhealthy_count = 0
            if tgs_list:
                for tg in tgs_list:
                    tg_arn = tg["arn"]
                    try:
                        th_resp = elbv2_client.describe_target_health(TargetGroupArn=tg_arn)
                        for th in th_resp.get("TargetHealthDescriptions", []):
                            h_state = th.get("TargetHealth", {}).get("State", "N/A")
                            th_list.append({
                                "target_group_arn": tg_arn,
                                "target_id": th.get("Target", {}).get("Id", "N/A"),
                                "port": th.get("Target", {}).get("Port", "N/A"),
                                "health_state": h_state,
                                "health_reason": th.get("TargetHealth", {}).get("Reason", "N/A"),
                                "description": th.get("TargetHealth", {}).get("Description", "N/A")
                            })
                            if h_state == "healthy":
                                healthy_count += 1
                            elif h_state == "unhealthy":
                                unhealthy_count += 1
                    except ClientError as e:
                        response_payload["errors"][f"target_health_{tg_arn}"] = e.response.get("Error", {}).get("Message", str(e))
            response_payload["target_health"] = th_list
            response_payload["summary"]["healthy_targets"] = healthy_count
            response_payload["summary"]["unhealthy_targets"] = unhealthy_count

            return response_payload

        except (NoCredentialsError, PartialCredentialsError):
            return {
                **response_payload,
                "error": "AWS credentials are not configured on the environment host."
            }
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in error_msg.lower() or "region" in error_msg.lower():
                msg = "ELB telemetry resources are currently unavailable in this AWS region."
            else:
                msg = f"AWS ELB Handshake Warning: {error_msg}"
            return {
                **response_payload,
                "error": msg
            }
        except Exception as e:
            return {
                **response_payload,
                "error": f"An unexpected system failure occurred: {str(e)}"
            }
