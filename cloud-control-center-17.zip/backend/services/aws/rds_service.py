import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List

class RDSService:
    """
    Service layer responsible for monitoring and querying AWS RDS database instances
    and clusters safely in the selected AWS region.
    """

    @staticmethod
    def get_rds_monitoring(region: str = None) -> Dict[str, Any]:
        """
        Retrieves Amazon RDS database instances and clusters in the region, aggregates metrics,
        and constructs the response. Uses granular try-except blocks to catch specific DBInstanceNotFound,
        AccessDenied, or ClientErrors.
        """
        response_payload = {
            "summary": {
                "instances": 0,
                "clusters": 0,
                "available": 0,
                "stopped": 0
            },
            "instances": [],
            "clusters": [],
            "errors": {}
        }

        try:
            # Localized boto3 configuration
            session = boto3.Session()
            config = Config(
                connect_timeout=4,
                read_timeout=8,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # Establish RDS client
            if region:
                rds_client = session.client("rds", region_name=region, config=config)
            else:
                rds_client = session.client("rds", config=config)

            # 1. Fetch DB Instances
            instances_list = []
            try:
                paginator = rds_client.get_paginator("describe_db_instances")
                pages = paginator.paginate()
                for page in pages:
                    for db in page.get("DBInstances", []):
                        db_id = db.get("DBInstanceIdentifier", "N/A")
                        engine = db.get("Engine", "N/A")
                        version = db.get("EngineVersion", "N/A")
                        inst_class = db.get("DBInstanceClass", "N/A")
                        status = db.get("DBInstanceStatus", "N/A")
                        storage = db.get("AllocatedStorage", 0)
                        multi_az = db.get("MultiAZ", False)
                        az = db.get("AvailabilityZone", "N/A")

                        # Resolve Endpoint address and port safely
                        endpoint_data = db.get("Endpoint", {})
                        endpoint = "N/A"
                        if endpoint_data:
                            addr = endpoint_data.get("Address")
                            port = endpoint_data.get("Port")
                            if addr and port:
                                endpoint = f"{addr}:{port}"
                            elif addr:
                                endpoint = addr

                        instances_list.append({
                            "identifier": db_id,
                            "engine": engine,
                            "version": version,
                            "class": inst_class,
                            "status": status,
                            "storage": storage,
                            "multi_az": multi_az,
                            "endpoint": endpoint,
                            "az": az
                        })
                response_payload["instances"] = instances_list
            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "")
                error_msg = e.response.get("Error", {}).get("Message", str(e))
                
                if error_code == "AccessDenied":
                    response_payload["errors"]["instances"] = "Access Denied: Missing rds:DescribeDBInstances permissions."
                elif error_code == "DBInstanceNotFound":
                    response_payload["errors"]["instances"] = "Database instances not found."
                else:
                    response_payload["errors"]["instances"] = error_msg

            # 2. Fetch DB Clusters (if Aurora or multi-node clusters exist)
            clusters_list = []
            try:
                paginator_cls = rds_client.get_paginator("describe_db_clusters")
                pages_cls = paginator_cls.paginate()
                for page in pages_cls:
                    for cl in page.get("DBClusters", []):
                        cl_id = cl.get("DBClusterIdentifier", "N/A")
                        engine = cl.get("Engine", "N/A")
                        version = cl.get("EngineVersion", "N/A")
                        status = cl.get("Status", "N/A")
                        multi_az = cl.get("MultiAZ", False)
                        
                        # Gather cluster members safely
                        members = []
                        for mb in cl.get("DBClusterMembers", []):
                            m_id = mb.get("DBInstanceIdentifier")
                            if m_id:
                                is_writer = mb.get("IsClusterWriter", False)
                                role = "Writer" if is_writer else "Reader"
                                members.append(f"{m_id} ({role})")

                        clusters_list.append({
                            "identifier": cl_id,
                            "engine": engine,
                            "version": version,
                            "status": status,
                            "multi_az": multi_az,
                            "members": members
                        })
                response_payload["clusters"] = clusters_list
            except ClientError as e:
                error_code = e.response.get("Error", {}).get("Code", "")
                error_msg = e.response.get("Error", {}).get("Message", str(e))
                
                if error_code == "AccessDenied":
                    response_payload["errors"]["clusters"] = "Access Denied: Missing rds:DescribeDBClusters permissions."
                else:
                    response_payload["errors"]["clusters"] = error_msg

            # 3. Process aggregates and totals for the summary dashboard
            available_count = sum(1 for inst in instances_list if inst["status"].lower() == "available")
            stopped_count = sum(1 for inst in instances_list if inst["status"].lower() in ["stopped", "stopping"])

            response_payload["summary"] = {
                "instances": len(instances_list),
                "clusters": len(clusters_list),
                "available": available_count,
                "stopped": stopped_count
            }

            # If there's an overarching permission block or regional failure, format as service failure
            if "instances" in response_payload["errors"] and "clusters" in response_payload["errors"]:
                response_payload["error"] = "Access Denied or Database Endpoint unreachable in this AWS account."

            return response_payload

        except (NoCredentialsError, PartialCredentialsError):
            return {
                **response_payload,
                "error": "AWS credentials are not configured on the environment host."
            }
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in error_msg.lower() or "region" in error_msg.lower():
                msg = "RDS telemetry resources are currently unavailable in this AWS region."
            else:
                msg = f"AWS RDS Handshake Warning: {error_msg}"
            return {
                **response_payload,
                "error": msg
            }
        except Exception as e:
            return {
                **response_payload,
                "error": f"An unexpected system failure occurred: {str(e)}"
            }
