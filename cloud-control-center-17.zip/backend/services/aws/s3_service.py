import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List
from datetime import datetime

class S3Service:
    """
    Service layer responsible for monitoring, indexing, and auditing S3 Buckets.
    Connects via boto3 to query standard metadata (Versioning, Encryption, Public Access, and Location).
    """

    @staticmethod
    def get_s3_buckets() -> Dict[str, Any]:
        """
        Retrieves a list of S3 buckets and audits active parameters for each.
        Uses granular per-bucket try-except structures so access limitations on a single bucket
        do not fail the entire API payload.
        """
        empty_response = {
            "summary": {
                "total_buckets": 0
            },
            "buckets": []
        }

        try:
            # Instantiate localized session and standardized low-timeout config
            session = boto3.Session()
            config = Config(
                connect_timeout=3,
                read_timeout=5,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            s3_client = session.client("s3", config=config)
            
            # List all S3 buckets
            response = s3_client.list_buckets()
            buckets_raw = response.get("Buckets", [])
            total_buckets = len(buckets_raw)

            buckets_list: List[Dict[str, Any]] = []

            for b in buckets_raw:
                name = b.get("Name", "N/A")
                creation_raw = b.get("CreationDate")
                creation_str = "N/A"
                if isinstance(creation_raw, datetime):
                    creation_str = creation_raw.isoformat()
                elif creation_raw:
                    creation_str = str(creation_raw)

                # 1. Bucket ARN
                arn = f"arn:aws:s3:::{name}"

                # 2. Get Bucket Location/Region
                region = "us-east-1"  # S3 standard default
                try:
                    location_resp = s3_client.get_bucket_location(Bucket=name)
                    loc = location_resp.get("LocationConstraint")
                    if loc:
                        region = loc
                except ClientError:
                    # Fallback to default/not available
                    pass

                # 3. Get Versioning Status
                versioning = "Disabled"
                try:
                    version_resp = s3_client.get_bucket_versioning(Bucket=name)
                    status = version_resp.get("Status")
                    if status:
                        versioning = status
                except ClientError:
                    versioning = "Suspended"

                # 4. Get Encryption Status
                encryption = "Disabled"
                try:
                    enc_resp = s3_client.get_bucket_encryption(Bucket=name)
                    rules = enc_resp.get("ServerSideEncryptionConfiguration", {}).get("Rules", [])
                    if rules:
                        encryption = "Enabled"
                except ClientError as e:
                    # ServerSideEncryptionConfigurationNotFoundError is a ClientError with code
                    err_code = e.response.get("Error", {}).get("Code", "")
                    if err_code == "ServerSideEncryptionConfigurationNotFoundError":
                        encryption = "Disabled"
                    else:
                        encryption = "Access Denied"

                # 5. Get Public Access Block Status
                public_access = "Public"
                try:
                    pab_resp = s3_client.get_public_access_block(Bucket=name)
                    pab_conf = pab_resp.get("PublicAccessBlockConfiguration", {})
                    # If all blocks are true, it's safely "Blocked"
                    if (pab_conf.get("BlockPublicAcls") and 
                        pab_conf.get("IgnorePublicAcls") and 
                        pab_conf.get("BlockPublicPolicy") and 
                        pab_conf.get("RestrictPublicBuckets")):
                        public_access = "Blocked"
                    elif (pab_conf.get("BlockPublicAcls") or 
                          pab_conf.get("BlockPublicPolicy")):
                        public_access = "Partially Blocked"
                    else:
                        public_access = "Public"
                except ClientError as e:
                    err_code = e.response.get("Error", {}).get("Code", "")
                    if err_code == "NoSuchPublicAccessBlockConfiguration":
                        public_access = "Public"
                    else:
                        public_access = "Access Denied"

                buckets_list.append({
                    "name": name,
                    "region": region,
                    "creation_date": creation_str,
                    "versioning": versioning,
                    "encryption": encryption,
                    "public_access": public_access,
                    "arn": arn
                })

            return {
                "summary": {
                    "total_buckets": total_buckets
                },
                "buckets": buckets_list
            }

        except (NoCredentialsError, PartialCredentialsError):
            return {
                "summary": {"total_buckets": 0},
                "buckets": [],
                "error": "AWS credentials not configured on the environment host."
            }
        except ClientError as e:
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            return {
                "summary": {"total_buckets": 0},
                "buckets": [],
                "error": f"AWS S3 Handshake Warning: {error_msg}"
            }
        except Exception as e:
            return {
                "summary": {"total_buckets": 0},
                "buckets": [],
                "error": f"An unexpected system failure occurred: {str(e)}"
            }
