import logging
from typing import Dict, Any, List
from services.aws.ec2_service import EC2Service
from services.aws.s3_service import S3Service
from services.aws.iam_service import IAMService

logger = logging.getLogger(__name__)

class AWSSearchService:
    """
    Service responsible for conducting unified case-insensitive global search
    across AWS resource domains by reusing existing monitoring services.
    """

    @staticmethod
    def search_resources(query: str) -> Dict[str, Any]:
        """
        Queries EC2, S3, and IAM services to retrieve resources matching the provided query string.
        Matches EC2 (Instance Name or ID), S3 (Bucket Name), and IAM (User, Role, or Group names).
        """
        results: List[Dict[str, Any]] = []
        clean_query = (query or "").strip().lower()

        if not clean_query:
            return {
                "query": query,
                "total_results": 0,
                "results": []
            }

        # 1. EC2 Instances Search
        try:
            # Call EC2Service directly without calling boto3 inside this module.
            # Passing "us-east-1" ensures a default query region to prevent NoRegionError.
            ec2_data = EC2Service.get_ec2_instances(region="us-east-1")
            instances = ec2_data.get("instances", [])

            for inst in instances:
                name = inst.get("name") or ""
                inst_id = inst.get("instance_id") or ""
                
                # Check match against Name or ID
                if clean_query in name.lower() or clean_query in inst_id.lower():
                    results.append({
                        "service": "EC2",
                        "resource_type": "Instance",
                        "name": name,
                        "resource_id": inst_id,
                        "region": inst.get("availability_zone", "Global")
                    })
        except Exception as e:
            logger.error(f"Error searching EC2 instances: {str(e)}")

        # 2. S3 Buckets Search
        try:
            s3_data = S3Service.get_s3_buckets()
            buckets = s3_data.get("buckets", [])
            for bucket in buckets:
                b_name = bucket.get("name") or ""
                if clean_query in b_name.lower():
                    results.append({
                        "service": "S3",
                        "resource_type": "Bucket",
                        "name": b_name,
                        "resource_id": b_name,
                        "region": bucket.get("region", "Global")
                    })
        except Exception as e:
            logger.error(f"Error searching S3 buckets: {str(e)}")

        # 3. IAM Entities Search (Users, Groups, Roles)
        try:
            iam_data = IAMService.get_iam_overview()
            
            # Users
            users = iam_data.get("users", [])
            for user in users:
                u_name = user.get("user_name") or ""
                if clean_query in u_name.lower():
                    results.append({
                        "service": "IAM",
                        "resource_type": "User",
                        "name": u_name,
                        "resource_id": user.get("user_id", u_name),
                        "region": "Global"
                    })

            # Groups
            groups = iam_data.get("groups", [])
            for group in groups:
                g_name = group.get("group_name") or ""
                if clean_query in g_name.lower():
                    results.append({
                        "service": "IAM",
                        "resource_type": "Group",
                        "name": g_name,
                        "resource_id": g_name,
                        "region": "Global"
                    })

            # Roles
            roles = iam_data.get("roles", [])
            for role in roles:
                r_name = role.get("role_name") or ""
                if clean_query in r_name.lower():
                    results.append({
                        "service": "IAM",
                        "resource_type": "Role",
                        "name": r_name,
                        "resource_id": r_name,
                        "region": "Global"
                    })
        except Exception as e:
            logger.error(f"Error searching IAM entities: {str(e)}")

        return {
            "query": query,
            "total_results": len(results),
            "results": results
        }

