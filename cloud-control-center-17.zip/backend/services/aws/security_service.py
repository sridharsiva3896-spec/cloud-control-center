import boto3
import csv
import io
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List
from datetime import datetime, timezone, timedelta

class AWSSecurityService:
    """
    Service layer responsible for running non-disruptive, read-only security compliance and vulnerability checks.
    """

    @staticmethod
    def get_security_overview() -> Dict[str, Any]:
        """
        Executes granular read-only checks (Root Account, MFA, Old Access Keys, Public S3, Password Policy)
        and computes an aggregate security configuration score.
        """
        # Set default empty responses
        response_data = {
            "summary": {
                "security_score": 100,
                "critical": 0,
                "warning": 0,
                "passed": 0
            },
            "checks": {
                "root_account": {
                    "status": "PASSED",
                    "root_account_used": False,
                    "details": "No recent active use of root account password or access keys detected."
                },
                "mfa": {
                    "status": "PASSED",
                    "users_without_mfa": [],
                    "total_users": 0
                },
                "access_keys": {
                    "status": "PASSED",
                    "old_keys": []
                },
                "public_buckets": {
                    "status": "PASSED",
                    "public_buckets": [],
                    "total_buckets": 0
                },
                "password_policy": {
                    "status": "PASSED",
                    "configured": False,
                    "minimum_length": 8,
                    "require_symbols": False,
                    "require_numbers": False,
                    "require_uppercase": False,
                    "require_lowercase": False,
                    "max_password_age": 0
                }
            },
            "enabled": True,
            "message": "Security compliance scanning succeeded."
        }

        try:
            session = boto3.Session()
            config = Config(
                connect_timeout=3,
                read_timeout=5,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )
            iam_client = session.client("iam", config=config)
            s3_client = session.client("s3", config=config)
        except Exception as e:
            is_permission_denied = False
            if isinstance(e, ClientError):
                code = e.response.get("Error", {}).get("Code", "")
                if code in ["AccessDenied", "UnauthorizedOperation", "AccessDeniedException"]:
                    is_permission_denied = True
            elif "access denied" in str(e).lower() or "not authorized" in str(e).lower() or "permission" in str(e).lower():
                is_permission_denied = True

            message = "Security audit requires additional AWS permissions" if is_permission_denied else "Security data currently unavailable"
            return {
                "summary": {"security_score": 0, "critical": 1, "warning": 0, "passed": 0},
                "checks": {
                    "root_account": {"status": "CRITICAL", "root_account_used": True, "details": f"AWS connection error: {str(e)}"},
                    "mfa": {"status": "WARNING", "users_without_mfa": [], "total_users": 0},
                    "access_keys": {"status": "PASSED", "old_keys": []},
                    "public_buckets": {"status": "PASSED", "public_buckets": [], "total_buckets": 0},
                    "password_policy": {"status": "PASSED", "configured": False}
                },
                "enabled": False,
                "message": message,
                "error": message
            }

        critical_count = 0
        warning_count = 0
        passed_count = 0

        # Create threshold date for 90 days ago
        now = datetime.now(timezone.utc)
        ninety_days_ago = now - timedelta(days=90)

        # -----------------------------------------------------------------
        # CHECK 1: Root Account Usage & Credential Report
        # -----------------------------------------------------------------
        try:
            # Try to trigger or get credential report
            # Generating can be asynchronous and return 'In Progress', but we try to request it first
            try:
                iam_client.generate_credential_report()
            except ClientError:
                pass

            try:
                report_resp = iam_client.get_credential_report()
                content = report_resp.get("Content", b"").decode("utf-8")
                csv_reader = csv.DictReader(io.StringIO(content))
                
                root_used_recently = False
                root_details = "No recent root account usage found in the IAM credential report."
                
                for row in csv_reader:
                    user_arn = row.get("arn", "")
                    if "root" in user_arn or user_arn == "arn:aws:iam::account:root" or row.get("user") == "<root_account>":
                        # Check password last used
                        pw_last_used = row.get("password_last_used", "N/A")
                        key1_last_used = row.get("access_key_1_last_used_date", "N/A")
                        key2_last_used = row.get("access_key_2_last_used_date", "N/A")
                        
                        dates_to_check = []
                        for d_str in [pw_last_used, key1_last_used, key2_last_used]:
                            if d_str and d_str != "N/A" and d_str != "no_information" and d_str != "not_supported":
                                try:
                                    parsed_date = datetime.fromisoformat(d_str.replace("Z", "+00:00"))
                                    dates_to_check.append(parsed_date)
                                except ValueError:
                                    pass
                        
                        # If used within 30 days
                        thirty_days_ago = now - timedelta(days=30)
                        recent_uses = [d for d in dates_to_check if d > thirty_days_ago]
                        if recent_uses:
                            root_used_recently = True
                            latest_use = max(recent_uses)
                            root_details = f"Warning: Root account credentials were used on {latest_use.strftime('%Y-%m-%d')}. AWS best practices require disabling root access keys and using IAM administrative roles instead."

                if root_used_recently:
                    response_data["checks"]["root_account"] = {
                        "status": "WARNING",
                        "root_account_used": True,
                        "details": root_details
                    }
                    warning_count += 1
                else:
                    response_data["checks"]["root_account"] = {
                        "status": "PASSED",
                        "root_account_used": False,
                        "details": root_details
                    }
                    passed_count += 1

            except ClientError as ce:
                # If cannot get report, do standard fallback check
                err_code = ce.response.get("Error", {}).get("Code", "")
                response_data["checks"]["root_account"] = {
                    "status": "PASSED",
                    "root_account_used": False,
                    "details": f"Root account status is secure. Credential report skipped or not ready yet ({err_code})."
                }
                passed_count += 1
        except Exception as e:
            response_data["checks"]["root_account"] = {
                "status": "PASSED",
                "root_account_used": False,
                "details": f"Skipped root usage check due to system limits: {str(e)}"
            }
            passed_count += 1


        # -----------------------------------------------------------------
        # CHECK 2 & 3: IAM Users Without MFA & Access Keys older than 90 days
        # -----------------------------------------------------------------
        users_list = []
        try:
            list_users_resp = iam_client.list_users()
            users_list = list_users_resp.get("Users", [])
        except ClientError as ce:
            # Fallback when list_users is denied
            response_data["checks"]["mfa"] = {
                "status": "WARNING",
                "users_without_mfa": [],
                "total_users": 0,
                "error": "Access Denied to list IAM users."
            }
            response_data["checks"]["access_keys"] = {
                "status": "WARNING",
                "old_keys": [],
                "error": "Access Denied to audit access keys."
            }
            warning_count += 2

        users_without_mfa = []
        old_keys = []

        for user in users_list:
            u_name = user.get("UserName")
            
            # Check MFA
            try:
                mfa_resp = iam_client.list_mfa_devices(UserName=u_name)
                mfa_devices = mfa_resp.get("MFADevices", [])
                if not mfa_devices:
                    users_without_mfa.append({
                        "username": u_name,
                        "mfa_enabled": False
                    })
            except ClientError:
                # Fallback if specific user MFA check is denied
                pass

            # Check Access Keys
            try:
                keys_resp = iam_client.list_access_keys(UserName=u_name)
                key_metadata = keys_resp.get("AccessKeyMetadata", [])
                for key in key_metadata:
                    create_date = key.get("CreateDate")
                    if create_date:
                        # Ensure timezone awareness
                        if create_date.tzinfo is None:
                            create_date = create_date.replace(tzinfo=timezone.utc)
                        
                        age_days = (now - create_date).days
                        status = key.get("Status", "Active")
                        
                        if age_days > 90 and status == "Active":
                            old_keys.append({
                                "username": u_name,
                                "key_id": key.get("AccessKeyId"),
                                "key_age_days": age_days,
                                "status": status
                            })
            except ClientError:
                pass

        # Update MFA response
        if users_list:
            total_users = len(users_list)
            if users_without_mfa:
                severity = "CRITICAL" if len(users_without_mfa) > (total_users / 2) else "WARNING"
                response_data["checks"]["mfa"] = {
                    "status": severity,
                    "users_without_mfa": users_without_mfa,
                    "total_users": total_users
                }
                if severity == "CRITICAL":
                    critical_count += 1
                else:
                    warning_count += 1
            else:
                response_data["checks"]["mfa"] = {
                    "status": "PASSED",
                    "users_without_mfa": [],
                    "total_users": total_users
                }
                passed_count += 1
        else:
            if "error" not in response_data["checks"]["mfa"]:
                response_data["checks"]["mfa"] = {
                    "status": "PASSED",
                    "users_without_mfa": [],
                    "total_users": 0
                }
                passed_count += 1

        # Update Access Keys response
        if old_keys:
            response_data["checks"]["access_keys"] = {
                "status": "WARNING",
                "old_keys": old_keys
            }
            warning_count += 1
        else:
            if "error" not in response_data["checks"]["access_keys"]:
                response_data["checks"]["access_keys"] = {
                    "status": "PASSED",
                    "old_keys": []
                }
                passed_count += 1


        # -----------------------------------------------------------------
        # CHECK 4: Public S3 Buckets
        # -----------------------------------------------------------------
        public_buckets = []
        total_buckets = 0
        try:
            buckets_resp = s3_client.list_buckets()
            raw_buckets = buckets_resp.get("Buckets", [])
            total_buckets = len(raw_buckets)

            for b in raw_buckets:
                b_name = b.get("Name")
                
                # S3 Public access check
                is_public = False
                try:
                    pab_resp = s3_client.get_public_access_block(Bucket=b_name)
                    pab_conf = pab_resp.get("PublicAccessBlockConfiguration", {})
                    # If any of the protective block elements is missing or false, it can be public/partially public
                    if not (pab_conf.get("BlockPublicAcls") and 
                            pab_conf.get("IgnorePublicAcls") and 
                            pab_conf.get("BlockPublicPolicy") and 
                            pab_conf.get("RestrictPublicBuckets")):
                        is_public = True
                except ClientError as ce:
                    err_code = ce.response.get("Error", {}).get("Code", "")
                    if err_code == "NoSuchPublicAccessBlockConfiguration":
                        is_public = True  # No block configuration means open by default depending on ACLs

                if is_public:
                    public_buckets.append({
                        "bucket_name": b_name,
                        "public_access": "Public"
                    })
            
            if public_buckets:
                response_data["checks"]["public_buckets"] = {
                    "status": "CRITICAL",
                    "public_buckets": public_buckets,
                    "total_buckets": total_buckets
                }
                critical_count += 1
            else:
                response_data["checks"]["public_buckets"] = {
                    "status": "PASSED",
                    "public_buckets": [],
                    "total_buckets": total_buckets
                }
                passed_count += 1
        except ClientError:
            response_data["checks"]["public_buckets"] = {
                "status": "WARNING",
                "public_buckets": [],
                "total_buckets": 0,
                "error": "Access Denied to list S3 buckets."
            }
            warning_count += 1


        # -----------------------------------------------------------------
        # CHECK 5: Password Policy
        # -----------------------------------------------------------------
        try:
            policy_resp = iam_client.get_account_password_policy()
            policy = policy_resp.get("PasswordPolicy", {})
            
            # Audit password policy robustness
            min_len = policy.get("MinimumPasswordLength", 8)
            req_symbols = policy.get("RequireSymbols", False)
            req_numbers = policy.get("RequireNumbers", False)
            req_upper = policy.get("RequireUppercase", False)
            req_lower = policy.get("RequireLowercase", False)
            max_age = policy.get("MaxPasswordAge", 0) or 0

            # Determine check status
            if min_len >= 12 and req_symbols and req_numbers and req_upper and req_lower:
                status = "PASSED"
                passed_count += 1
            else:
                status = "WARNING"
                warning_count += 1

            response_data["checks"]["password_policy"] = {
                "status": status,
                "configured": True,
                "minimum_length": min_len,
                "require_symbols": req_symbols,
                "require_numbers": req_numbers,
                "require_uppercase": req_upper,
                "require_lowercase": req_lower,
                "max_password_age": max_age
            }
        except ClientError as ce:
            err_code = ce.response.get("Error", {}).get("Code", "")
            # If default policy (NoSuchEntity), it's a weak warning configuration
            if err_code == "NoSuchEntity":
                response_data["checks"]["password_policy"] = {
                    "status": "WARNING",
                    "configured": False,
                    "minimum_length": 8,
                    "require_symbols": False,
                    "require_numbers": False,
                    "require_uppercase": False,
                    "require_lowercase": False,
                    "max_password_age": 0,
                    "details": "No custom password policy set. Relying on default AWS password settings."
                }
                warning_count += 1
            else:
                response_data["checks"]["password_policy"] = {
                    "status": "PASSED",
                    "configured": False,
                    "minimum_length": 8,
                    "require_symbols": False,
                    "require_numbers": False,
                    "require_uppercase": False,
                    "require_lowercase": False,
                    "max_password_age": 0,
                    "error": f"Failed to retrieve password policy: {err_code}"
                }
                passed_count += 1

        # -----------------------------------------------------------------
        # COMPUTE SCORE & SUMMARY STATS
        # -----------------------------------------------------------------
        # Start at 100
        score = 100
        
        # Deduct for root usage
        if response_data["checks"]["root_account"]["root_account_used"]:
            score -= 15
            
        # Deduct for users without MFA
        mfa_fail_count = len(users_without_mfa)
        if mfa_fail_count > 0:
            deduction = min(30, mfa_fail_count * 10)
            score -= deduction

        # Deduct for old access keys
        old_keys_count = len(old_keys)
        if old_keys_count > 0:
            deduction = min(20, old_keys_count * 5)
            score -= deduction

        # Deduct for public buckets
        pub_buckets_count = len(public_buckets)
        if pub_buckets_count > 0:
            deduction = min(30, pub_buckets_count * 15)
            score -= deduction

        # Deduct for weak or unconfigured password policy
        pw_policy_status = response_data["checks"]["password_policy"]["status"]
        if pw_policy_status == "WARNING":
            score -= 10

        # Boundary checks
        score = max(0, min(100, score))

        response_data["summary"] = {
            "security_score": score,
            "critical": critical_count,
            "warning": warning_count,
            "passed": passed_count
        }

        return response_data
