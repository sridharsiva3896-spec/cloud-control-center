import boto3
import threading
import contextvars
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from typing import Dict, Any, Optional
from config import aws_config

# Save the original boto3.Session class to create real sessions when explicitly requested
_original_session_class = boto3.Session

# ContextVar to store the current request's AWS Session ID header
current_session_id: contextvars.ContextVar[Optional[str]] = contextvars.ContextVar("current_session_id", default=None)

class AWSSessionService:
    """
    Service layer responsible for creating and caching server-side boto3 Sessions,
    detecting active regions, and validating AWS credential state using STS.
    """
    _lock = threading.Lock()
    _sessions: Dict[str, Dict[str, Any]] = {}  # Map of session_id -> session_info_dict

    @classmethod
    def _get_current_session_data(cls) -> Dict[str, Any]:
        session_id = current_session_id.get()
        if not session_id:
            return {
                "active_session": None,
                "is_connected": False,
                "account_id": None,
                "arn": None,
                "user_id": None,
                "region": None
            }
        with cls._lock:
            if session_id not in cls._sessions:
                cls._sessions[session_id] = {
                    "active_session": None,
                    "is_connected": False,
                    "account_id": None,
                    "arn": None,
                    "user_id": None,
                    "region": None
                }
            return cls._sessions[session_id]

    @classmethod
    def is_connected(cls) -> bool:
        session_data = cls._get_current_session_data()
        return session_data.get("is_connected", False)

    @classmethod
    def get_active_session(cls) -> boto3.Session:
        session_data = cls._get_current_session_data()
        if not session_data.get("is_connected") or session_data.get("active_session") is None:
            raise NoCredentialsError()
        return session_data["active_session"]

    @classmethod
    def connect(
        cls,
        aws_access_key_id: str,
        aws_secret_access_key: str,
        aws_session_token: Optional[str] = None,
        region_name: Optional[str] = None
    ) -> Dict[str, Any]:
        """
        Explicitly establishes a real, authenticated boto3 Session and validates credentials.
        """
        try:
            # Force real session creation using saved class to bypass custom initializer
            session = _original_session_class(
                aws_access_key_id=aws_access_key_id,
                aws_secret_access_key=aws_secret_access_key,
                aws_session_token=aws_session_token,
                region_name=region_name or aws_config.default_region
            )
            region = session.region_name or aws_config.default_region
            
            # Verify caller identity via STS
            sts_client = session.client("sts", config=aws_config.botocore_config)
            identity = sts_client.get_caller_identity()
            
            session_id = current_session_id.get()
            if not session_id:
                return {
                    "connected": False,
                    "error_type": "NoSessionIdError",
                    "message": "AWS connection request requires a valid X-AWS-Session-ID header."
                }

            with cls._lock:
                cls._sessions[session_id] = {
                    "active_session": session,
                    "is_connected": True,
                    "account_id": identity.get("Account"),
                    "arn": identity.get("Arn"),
                    "user_id": identity.get("UserId"),
                    "region": region
                }
            
            return {
                "connected": True,
                "account_id": identity.get("Account"),
                "arn": identity.get("Arn"),
                "user_id": identity.get("UserId"),
                "region": region,
                "message": "AWS Session verified successfully"
            }
        except (NoCredentialsError, PartialCredentialsError):
            session_id = current_session_id.get()
            if session_id:
                with cls._lock:
                    cls._sessions.pop(session_id, None)
            return {
                "connected": False,
                "error_type": "NoCredentialsError",
                "message": "Invalid AWS Access Key ID or Secret Access Key."
            }
        except ClientError as e:
            session_id = current_session_id.get()
            if session_id:
                with cls._lock:
                    cls._sessions.pop(session_id, None)
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            error_msg = e.response.get('Error', {}).get('Message', 'Client error during STS validation.')
            return {
                "connected": False,
                "error_type": "ClientError",
                "code": error_code,
                "message": f"AWS authorization error: {error_msg}"
            }
        except Exception as e:
            session_id = current_session_id.get()
            if session_id:
                with cls._lock:
                    cls._sessions.pop(session_id, None)
            return {
                "connected": False,
                "error_type": "SystemError",
                "message": f"An unexpected system error occurred while verifying AWS credentials: {str(e)}"
            }

    @classmethod
    def switch_region(cls, region_name: str) -> Dict[str, Any]:
        """
        Safely switches the active session region, recreating the boto3 Session
        and clients scoped specifically to the new region, preserving the active credentials.
        """
        session_id = current_session_id.get()
        if not session_id:
            return {
                "success": False,
                "message": "AWS connection context requires a valid X-AWS-Session-ID header."
            }
        
        with cls._lock:
            if session_id not in cls._sessions or not cls._sessions[session_id].get("is_connected"):
                return {
                    "success": False,
                    "message": "AWS session not connected."
                }
            
            session_data = cls._sessions[session_id]
            old_session = session_data.get("active_session")
            if not old_session:
                return {
                    "success": False,
                    "message": "No active session context detected to switch region for."
                }
            
            try:
                creds = old_session.get_credentials()
                if not creds:
                    return {
                        "success": False,
                        "message": "Could not extract credentials from existing active session."
                    }
                
                # Recreate the session-scoped client for the new region
                new_session = _original_session_class(
                    aws_access_key_id=creds.access_key,
                    aws_secret_access_key=creds.secret_key,
                    aws_session_token=creds.token,
                    region_name=region_name
                )
                
                # Update the cached session metadata
                cls._sessions[session_id]["active_session"] = new_session
                cls._sessions[session_id]["region"] = region_name
                
                return {
                    "success": True,
                    "region": region_name,
                    "message": f"Session region changed successfully to {region_name}"
                }
            except Exception as e:
                return {
                    "success": False,
                    "message": f"Failed to modify session region context: {str(e)}"
                }

    @classmethod
    def disconnect(cls) -> None:
        """
        Destroys the server-side AWS session for the current request's session ID.
        """
        session_id = current_session_id.get()
        if session_id:
            with cls._lock:
                cls._sessions.pop(session_id, None)

    @classmethod
    def get_session_info(cls) -> Dict[str, Any]:
        """
        Retrieves current session status without initiating a connection.
        """
        session_data = cls._get_current_session_data()
        if session_data.get("is_connected"):
            return {
                "connected": True,
                "account_id": session_data.get("account_id"),
                "arn": session_data.get("arn"),
                "user_id": session_data.get("user_id"),
                "region": session_data.get("region"),
                "message": "AWS Session verified successfully"
            }
        else:
            return {
                "connected": False,
                "message": "AWS not connected"
            }

# Custom Session interceptor to implement Task 1, 2, and 8
def custom_session_initializer(*args, **kwargs):
    # Check if we should bypass, if we are passing explicit credentials, or if we're not connected
    if (
        kwargs.get('_force_real_session') or 
        'aws_access_key_id' in kwargs or 
        'aws_secret_access_key' in kwargs
    ):
        kwargs.pop('_force_real_session', None)
        return _original_session_class(*args, **kwargs)
        
    # If we are not connected, raise NoCredentialsError to block auto-connect
    if not AWSSessionService.is_connected():
        raise NoCredentialsError()
        
    # Return the cached, authenticated server-side session
    return AWSSessionService.get_active_session()

# Apply the monkeypatch!
boto3.Session = custom_session_initializer
