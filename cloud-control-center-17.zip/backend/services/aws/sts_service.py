import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, Optional
from config import aws_config

class STSService:
    """
    AWS Security Token Service (STS) integration wrapper.
    Responsible for validating security credentials, retrieving connected account identifiers, 
    and auditing operational contexts.
    """

    @staticmethod
    def get_caller_identity() -> Dict[str, Any]:
        """
        Queries STS to verify credentials and extract current IAM identity information.
        
        Returns:
            Dict containing connection status and credentials metadata.
        """
        try:
            # Create Session using central config
            session = aws_config.create_session()
            region = session.region_name or aws_config.default_region

            # Configure custom client timeout limits using standardized config
            config = aws_config.botocore_config

            # Initialize STS client securely through session with standard config
            sts_client = session.client(
                "sts",
                config=config
            )
            
            identity = sts_client.get_caller_identity()
            
            return {
                "connected": True,
                "account_id": identity.get("Account"),
                "arn": identity.get("Arn"),
                "user_id": identity.get("UserId"),
                "region": region,
                "message": "AWS Connected Successfully"
            }
            
        except (NoCredentialsError, PartialCredentialsError) as e:
            return {
                "connected": False,
                "error_type": "MissingCredentials",
                "message": "AWS credentials not configured. Please execute 'aws configure' in your terminal."
            }
        except ClientError as e:
            error_code = e.response.get('Error', {}).get('Code', 'Unknown')
            return {
                "connected": False,
                "error_type": "ClientError",
                "code": error_code,
                "message": f"AWS connection rejected: {e.response.get('Error', {}).get('Message', str(e))}"
            }
        except Exception as e:
            return {
                "connected": False,
                "error_type": "SystemError",
                "message": f"System error validating AWS connection: {str(e)}"
            }
