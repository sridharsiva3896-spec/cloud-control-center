import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List

class TagService:
    """
    Service layer responsible for exploring and auditing tags assigned to active AWS resources.
    Uses 'resourcegroupstaggingapi' to locate and extract tag keys and values in the selected region.
    """

    @staticmethod
    def parse_arn(arn: str) -> Dict[str, str]:
        """
        Parses an AWS Resource Name (ARN) to safely extract the service, region, and resource type.
        Example ARN: arn:aws:ec2:us-east-1:123456789012:instance/i-0123456789abcdef0
        """
        parsed = {
            "service": "N/A",
            "region": "N/A",
            "resource_type": "N/A",
            "resource_name": "N/A"
        }
        if not arn or not arn.startswith("arn:"):
            return parsed

        parts = arn.split(":")
        if len(parts) > 2:
            parsed["service"] = parts[2]
        if len(parts) > 3 and parts[3]:
            parsed["region"] = parts[3]
        else:
            parsed["region"] = "global"

        if len(parts) > 5:
            remainder = ":".join(parts[5:])
            if "/" in remainder:
                res_type, *res_name_parts = remainder.split("/")
                parsed["resource_type"] = res_type
                parsed["resource_name"] = "/".join(res_name_parts)
            else:
                parsed["resource_type"] = remainder
                parsed["resource_name"] = remainder
        elif len(parts) == 5:
            # S3 bucket ARNs look like 'arn:aws:s3:::bucket-name'
            if parts[2] == "s3":
                parsed["resource_type"] = "bucket"
                parsed["resource_name"] = parts[4]
            else:
                parsed["resource_type"] = parts[4]
                parsed["resource_name"] = parts[4]

        return parsed

    @classmethod
    def get_resources(cls, region: str = None, service_filter: str = None, tag_key_filter: str = None, tag_value_filter: str = None) -> Dict[str, Any]:
        """
        Queries resources and their respective tags using boto3. Includes manual python-side filtering
        to guarantee robustness and prevent complex API query validation exceptions.
        """
        response_payload = {
            "resources": [],
            "error": None
        }

        try:
            session = boto3.Session()
            config = Config(
                connect_timeout=4,
                read_timeout=8,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # Establish resourcegroupstaggingapi client
            # The resourcegroupstaggingapi client works on a regional basis or acts globally
            target_region = region or "us-east-1"
            client = session.client("resourcegroupstaggingapi", region_name=target_region, config=config)

            paginator = client.get_paginator("get_resources")
            pages = paginator.paginate()

            flattened_results = []

            for page in pages:
                for mapping in page.get("ResourceTagMappingList", []):
                    arn = mapping.get("ResourceARN", "")
                    arn_details = cls.parse_arn(arn)
                    tags = mapping.get("Tags", [])

                    # If no tags exist, we can represent with N/A tag values to allow auditing untagged/partially tagged resources
                    if not tags:
                        flattened_results.append({
                            "arn": arn,
                            "service": arn_details["service"],
                            "region": arn_details["region"],
                            "resource_type": arn_details["resource_type"],
                            "resource_name": arn_details["resource_name"],
                            "tag_key": "N/A",
                            "tag_value": "N/A"
                        })
                    else:
                        for tag in tags:
                            flattened_results.append({
                                "arn": arn,
                                "service": arn_details["service"],
                                "region": arn_details["region"],
                                "resource_type": arn_details["resource_type"],
                                "resource_name": arn_details["resource_name"],
                                "tag_key": tag.get("Key", "N/A"),
                                "tag_value": tag.get("Value", "N/A")
                              })

            # Filter results according to query arguments
            filtered_results = []
            for item in flattened_results:
                # Apply service filter
                if service_filter and service_filter.lower() != "all":
                    if item["service"].lower() != service_filter.lower():
                        continue

                # Apply region filter (from query parameter)
                # Wait, the query parameter 'region' represents either the target API region or resource region filter
                # We can match resource region
                
                # Apply tag_key filter
                if tag_key_filter and tag_key_filter.strip():
                    if tag_key_filter.lower() not in item["tag_key"].lower():
                        continue

                # Apply tag_value filter
                if tag_value_filter and tag_value_filter.strip():
                    if tag_value_filter.lower() not in item["tag_value"].lower():
                        continue

                filtered_results.append(item)

            response_payload["resources"] = filtered_results
            return response_payload

        except (NoCredentialsError, PartialCredentialsError):
            response_payload["error"] = "AWS credentials are not configured on the environment host."
            return response_payload
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code == "AccessDenied":
                response_payload["error"] = "Access Denied: Missing tag:GetResources permissions."
            else:
                response_payload["error"] = f"AWS Tag API Query failed: {error_msg}"
            return response_payload
        except Exception as e:
            response_payload["error"] = f"An unexpected tagging service failure occurred: {str(e)}"
            return response_payload
