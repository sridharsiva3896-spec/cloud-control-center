import boto3
from botocore.exceptions import NoCredentialsError, PartialCredentialsError, ClientError
from botocore.config import Config
from typing import Dict, Any, List

class VpcService:
    """
    Service layer responsible for monitoring and querying AWS Virtual Private Cloud (VPC)
    networking structures safely. Queries describing endpoints for VPCs, Subnets,
    Route Tables, Internet Gateways, NAT Gateways, Security Groups, and Network ACLs.
    """

    @staticmethod
    def get_vpc_monitoring(region: str = None) -> Dict[str, Any]:
        """
        Gathers AWS VPC networking components and aggregates summary metrics.
        Runs granular individual try-except clauses per resource call to ensure 
        resilience against partial API access restrictions.
        """
        # Base structured response
        response_payload = {
            "summary": {
                "vpcs": 0,
                "subnets": 0,
                "route_tables": 0,
                "internet_gateways": 0,
                "nat_gateways": 0,
                "security_groups": 0,
                "network_acls": 0
            },
            "vpcs": [],
            "subnets": [],
            "route_tables": [],
            "internet_gateways": [],
            "nat_gateways": [],
            "security_groups": [],
            "network_acls": [],
            "errors": {}
        }

        try:
            # Localized boto3 configuration
            session = boto3.Session()
            config = Config(
                connect_timeout=4,
                read_timeout=8,
                retries={
                    "max_attempts": 2,
                    "mode": "standard"
                }
            )

            # Establish EC2/VPC client
            if region:
                ec2_client = session.client("ec2", region_name=region, config=config)
            else:
                ec2_client = session.client("ec2", config=config)

            # 1. Query VPCs
            try:
                vpcs_resp = ec2_client.describe_vpcs()
                vpcs_list = []
                for vpc in vpcs_resp.get("Vpcs", []):
                    tags = vpc.get("Tags", [])
                    vpcs_list.append({
                        "vpc_id": vpc.get("VpcId", "N/A"),
                        "cidr_block": vpc.get("CidrBlock", "N/A"),
                        "state": vpc.get("State", "N/A"),
                        "is_default": vpc.get("IsDefault", False),
                        "owner_id": vpc.get("OwnerId", "N/A"),
                        "tags": tags
                    })
                response_payload["vpcs"] = vpcs_list
                response_payload["summary"]["vpcs"] = len(vpcs_list)
            except ClientError as e:
                response_payload["errors"]["vpcs"] = e.response.get("Error", {}).get("Message", str(e))

            # 2. Query Subnets
            try:
                subnets_resp = ec2_client.describe_subnets()
                subnets_list = []
                for sub in subnets_resp.get("Subnets", []):
                    subnets_list.append({
                        "subnet_id": sub.get("SubnetId", "N/A"),
                        "vpc_id": sub.get("VpcId", "N/A"),
                        "cidr_block": sub.get("CidrBlock", "N/A"),
                        "availability_zone": sub.get("AvailabilityZone", "N/A"),
                        "available_ip_count": sub.get("AvailableIpAddressCount", 0),
                        "state": sub.get("State", "N/A")
                    })
                response_payload["subnets"] = subnets_list
                response_payload["summary"]["subnets"] = len(subnets_list)
            except ClientError as e:
                response_payload["errors"]["subnets"] = e.response.get("Error", {}).get("Message", str(e))

            # 3. Query Route Tables
            try:
                rt_resp = ec2_client.describe_route_tables()
                rt_list = []
                for rt in rt_resp.get("RouteTables", []):
                    routes = rt.get("Routes", [])
                    associations = rt.get("Associations", [])
                    rt_list.append({
                        "route_table_id": rt.get("RouteTableId", "N/A"),
                        "vpc_id": rt.get("VpcId", "N/A"),
                        "routes_count": len(routes),
                        "associations_count": len(associations)
                    })
                response_payload["route_tables"] = rt_list
                response_payload["summary"]["route_tables"] = len(rt_list)
            except ClientError as e:
                response_payload["errors"]["route_tables"] = e.response.get("Error", {}).get("Message", str(e))

            # 4. Query Internet Gateways
            try:
                ig_resp = ec2_client.describe_internet_gateways()
                ig_list = []
                for ig in ig_resp.get("InternetGateways", []):
                    attachments = ig.get("Attachments", [])
                    attached_vpcs = [att.get("VpcId") for att in attachments if att.get("VpcId")]
                    ig_list.append({
                        "internet_gateway_id": ig.get("InternetGatewayId", "N/A"),
                        "attached_vpc": attached_vpcs[0] if attached_vpcs else "Unattached"
                    })
                response_payload["internet_gateways"] = ig_list
                response_payload["summary"]["internet_gateways"] = len(ig_list)
            except ClientError as e:
                response_payload["errors"]["internet_gateways"] = e.response.get("Error", {}).get("Message", str(e))

            # 5. Query NAT Gateways
            try:
                nat_resp = ec2_client.describe_nat_gateways()
                nat_list = []
                for nat in nat_resp.get("NatGateways", []):
                    addresses = nat.get("NatGatewayAddresses", [])
                    public_ip = "N/A"
                    if addresses:
                        public_ip = addresses[0].get("PublicIp", "N/A")
                    nat_list.append({
                        "nat_gateway_id": nat.get("NatGatewayId", "N/A"),
                        "state": nat.get("State", "N/A"),
                        "public_ip": public_ip,
                        "subnet_id": nat.get("SubnetId", "N/A"),
                        "vpc_id": nat.get("VpcId", "N/A")
                    })
                response_payload["nat_gateways"] = nat_list
                response_payload["summary"]["nat_gateways"] = len(nat_list)
            except ClientError as e:
                response_payload["errors"]["nat_gateways"] = e.response.get("Error", {}).get("Message", str(e))

            # 6. Query Security Groups
            try:
                sg_resp = ec2_client.describe_security_groups()
                sg_list = []
                for sg in sg_resp.get("SecurityGroups", []):
                    sg_list.append({
                        "group_id": sg.get("GroupId", "N/A"),
                        "group_name": sg.get("GroupName", "N/A"),
                        "description": sg.get("Description", "N/A"),
                        "vpc_id": sg.get("VpcId", "N/A"),
                        "ingress_rule_count": len(sg.get("IpPermissions", [])),
                        "egress_rule_count": len(sg.get("IpPermissionsEgress", []))
                    })
                response_payload["security_groups"] = sg_list
                response_payload["summary"]["security_groups"] = len(sg_list)
            except ClientError as e:
                response_payload["errors"]["security_groups"] = e.response.get("Error", {}).get("Message", str(e))

            # 7. Query Network ACLs
            try:
                nacl_resp = ec2_client.describe_network_acls()
                nacl_list = []
                for nacl in nacl_resp.get("NetworkAcls", []):
                    nacl_list.append({
                        "network_acl_id": nacl.get("NetworkAclId", "N/A"),
                        "vpc_id": nacl.get("VpcId", "N/A"),
                        "rule_count": len(nacl.get("Entries", [])),
                        "is_default": nacl.get("IsDefault", False)
                    })
                response_payload["network_acls"] = nacl_list
                response_payload["summary"]["network_acls"] = len(nacl_list)
            except ClientError as e:
                response_payload["errors"]["network_acls"] = e.response.get("Error", {}).get("Message", str(e))

            return response_payload

        except (NoCredentialsError, PartialCredentialsError):
            return {
                **response_payload,
                "error": "AWS credentials are not configured on the environment host."
            }
        except ClientError as e:
            error_code = e.response.get("Error", {}).get("Code", "")
            error_msg = e.response.get("Error", {}).get("Message", str(e))
            if error_code in ["UnrecognizedClientException", "AuthFailure", "OptInRequired", "SubscriptionRequiredException"] or "unavailable" in error_msg.lower() or "region" in error_msg.lower():
                msg = "VPC telemetry resources are currently unavailable in this AWS region."
            else:
                msg = f"AWS VPC Handshake Warning: {error_msg}"
            return {
                **response_payload,
                "error": msg
            }
        except Exception as e:
            return {
                **response_payload,
                "error": f"An unexpected system failure occurred: {str(e)}"
            }
