import logging
import sys
import json
from datetime import datetime
from typing import Any, Dict, Optional

# Setup the base logger
logger = logging.getLogger("cloud_control_center")
logger.setLevel(logging.INFO)

# Structured stdout handler
handler = logging.StreamHandler(sys.stdout)
formatter = logging.Formatter('[%(asctime)s] [%(levelname)s] %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)

def sanitize_data(data: Any) -> Any:
    """
    Recursively scans and removes sensitive fields (like keys, secrets, tokens)
    to ensure zero leaking of credentials in logs.
    """
    if isinstance(data, dict):
        sanitized = {}
        for k, v in data.items():
            if any(secret_term in k.lower() for secret_term in ["key", "secret", "token", "password", "credential"]):
                sanitized[k] = "[REDACTED_SENSITIVE_VALUE]"
            else:
                sanitized[k] = sanitize_data(v)
        return sanitized
    elif isinstance(data, list):
        return [sanitize_data(item) for item in data]
    return data

def log_api_request(method: str, path: str, query_params: Optional[Dict[str, Any]] = None, body: Optional[Any] = None) -> None:
    """
    Logs incoming HTTP API requests with clean, structured metadata.
    """
    sanitized_params = sanitize_data(query_params) if query_params else {}
    sanitized_body = sanitize_data(body) if body else None
    
    log_payload = {
        "event": "api_request",
        "method": method,
        "path": path,
        "query_params": sanitized_params
    }
    if sanitized_body:
        log_payload["body"] = sanitized_body
        
    logger.info(f"API Request - {method} {path} - Payload: {json.dumps(log_payload)}")

def log_aws_failure(service: str, action: str, error: Exception) -> None:
    """
    Logs AWS API client failures and service handshake warning exceptions.
    """
    log_payload = {
        "event": "aws_api_failure",
        "service": service,
        "action": action,
        "error_type": type(error).__name__,
        "error_message": str(error)
    }
    logger.error(f"AWS API Failure - Service: {service}, Action: {action} - Detail: {json.dumps(log_payload)}")

def log_auth_failure(username: Optional[str], reason: str) -> None:
    """
    Logs authentication or authorization handshaking blocks.
    """
    log_payload = {
        "event": "authentication_failure",
        "user_identity": username or "anonymous",
        "reason": reason
    }
    logger.warning(f"Authentication Failure - Identity: {username or 'anonymous'} - Reason: {json.dumps(log_payload)}")

def log_unexpected_exception(module: str, context: str, error: Exception) -> None:
    """
    Logs unexpected general, system, or runtime errors inside the application.
    """
    log_payload = {
        "event": "unexpected_exception",
        "module": module,
        "context": context,
        "error_type": type(error).__name__,
        "error_message": str(error)
    }
    logger.error(f"Unexpected Exception - Module: {module}, Context: {context} - Detail: {json.dumps(log_payload)}")
