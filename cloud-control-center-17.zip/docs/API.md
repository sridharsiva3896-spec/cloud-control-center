# Cloud Control Center - REST API Specification

This document defines the RESTful endpoints provided by the **Cloud Control Center** backend application.

## 1. Global Standards

- **Base URL**: `/api/v1`
- **Content-Type**: `application/json`
- **Response Format**: Standardized wrapper format for uniform client-side handling.

### Standard Response Templates:

#### Success Response (200 OK / 201 Created)
```json
{
  "success": true,
  "data": { ... },
  "message": "Resource retrieved successfully"
}
```

#### Error Response (400 Bad Request / 401 Unauthorized / 500 Server Error)
```json
{
  "success": false,
  "error": {
    "code": "INVALID_PARAMS",
    "message": "The provided instance_id was not found",
    "details": []
  }
}
```

---

## 2. API Endpoints Reference

### 2.1 System Health
*Provides service telemetry and database status validation.*

- **Endpoint**: `GET /health`
- **Auth Required**: No
- **Headers**: None
- **Success Response (200)**:
```json
{
  "success": true,
  "data": {
    "status": "healthy",
    "version": "1.0.0",
    "database": "connected",
    "aws_connection": "verified"
  }
}
```

### 2.2 EC2 Instance Management
*Retrieves, starts, and stops virtual machine computing resource targets.*

#### List Instances
- **Endpoint**: `GET /aws/instances`
- **Auth Required**: Yes (`Bearer <token>`)
- **Query Params**:
  - `region`: `string` (e.g., `us-east-1`)
  - `state`: `string` (e.g., `running`, `stopped`)
- **Success Response (200)**:
```json
{
  "success": true,
  "data": [
    {
      "instance_id": "i-0a123b456c789def0",
      "name": "Production-API-Gateway",
      "type": "t3.medium",
      "state": "running",
      "launch_time": "2026-06-25T12:00:00Z",
      "private_ip": "10.0.1.24",
      "public_ip": "54.210.12.34",
      "tags": {
        "Environment": "Production",
        "Owner": "SRE-Team"
      }
    }
  ]
}
```

#### Modify Instance State (Start / Stop)
- **Endpoint**: `POST /aws/instances/state`
- **Auth Required**: Yes (`Bearer <token>`)
- **Request Body**:
```json
{
  "instance_id": "i-0a123b456c789def0",
  "action": "stop" 
}
```
*Note: Allowed values for action are: `start`, `stop`, `reboot`.*

- **Success Response (200)**:
```json
{
  "success": true,
  "data": {
    "instance_id": "i-0a123b456c789def0",
    "previous_state": "running",
    "current_state": "stopping"
  },
  "message": "Stop request successfully dispatched to AWS"
}
```

### 2.3 Cloud Cost Aggregations
*Aggregates cloud billing costs across the account using AWS Cost Explorer.*

- **Endpoint**: `GET /aws/costs`
- **Auth Required**: Yes (`Bearer <token>`)
- **Query Params**:
  - `timeframe`: `string` (e.g., `last_30_days`, `last_3_months`)
  - `granularity`: `string` (e.g., `DAILY`, `MONTHLY`)
- **Success Response (200)**:
```json
{
  "success": true,
  "data": {
    "total_amount": 1250.45,
    "currency": "USD",
    "by_service": {
      "Amazon Elastic Compute Cloud - Compute": 542.20,
      "Amazon Relational Database Service": 412.15,
      "Amazon Simple Storage Service": 96.10,
      "AWS Secrets Manager": 200.00
    }
  }
}
```
