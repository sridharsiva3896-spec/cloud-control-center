# AWS Integration & Setup Guidelines
This document guides you through connecting the **Cloud Control Center** to your real-world AWS environment using standard CLI credentials.

---

## Architecture Overview
The platform connects to AWS exclusively from the backend secure proxy layer using the official **Python AWS SDK (`boto3`)**. 

To satisfy the zero-trust corporate security paradigm:
1. **No AWS secret credentials** are hardcoded or preserved on any disk.
2. Credentials are automatically resolved from your native **AWS CLI profile** or standard local shell environment variables.
3. Verification is completed securely via the AWS **Security Token Service (STS)** using `get_caller_identity()`.

---

## 🔑 How boto3 Automatically Resolves Credentials

The official Python SDK (`boto3`) utilizes a predefined **credential resolution chain** to authenticate your API operations without requiring manual configuration within source files:

1. **Environment Variables**: First, it checks the standard shell environment flags:
   * `AWS_ACCESS_KEY_ID`
   * `AWS_SECRET_ACCESS_KEY`
   * `AWS_DEFAULT_REGION`
2. **Shared Credentials File**: If environment flags are absent, `boto3` checks your local machine profile at `~/.aws/credentials` (written by `aws configure`).
3. **Configuration File**: It resolves supplementary settings like primary regions from `~/.aws/config`.
4. **IAM Instance Profiles/ECS Task Roles**: If run inside AWS containers (such as ECS or EC2), it seamlessly queries the local instance metadata service (IMDS) to load temporary security credentials automatically.

---

## 🛠️ Step-by-Step Configuration

### 1. Install the AWS CLI
Ensure that the official AWS CLI is installed on your local operating system.
* **macOS**: `brew install awscli`
* **Windows**: Download the official MSI Installer.
* **Linux**: `sudo apt-get install awscli` or use standard curl installers.

Verify installation in your terminal:
```bash
aws --version
```

### 2. Configure AWS CLI Credentials
Execute the native configuration wizard in your terminal shell:
```bash
aws configure
```
You will be prompted to supply your IAM parameters:
* **AWS Access Key ID**: Your IAM User access key (e.g., `AKIAIOSFODNN7EXAMPLE`)
* **AWS Secret Access Key**: Your IAM User secret key (e.g., `wJalrXUtnFEMI/K7MDENG/bPxRfiCYEXAMPLEKEY`)
* **Default region name**: Your primary region code (e.g., `us-east-1`, `us-west-2`)
* **Default output format**: Set to `json`

### 3. Verify Identity Locally
Execute the STS caller identity command to verify that your credentials resolve successfully:
```bash
aws sts get-caller-identity
```
A successful response will return your connected Account ID, Role/User ARN, and User ID:
```json
{
    "UserId": "AIDACKCEVSN6D2EXAMPLE",
    "Account": "123456789012",
    "Arn": "arn:aws:iam::123456789012:user/admin"
}
```

### 4. Start the Application Backend & Frontend
Boot up your environment servers. If the servers are already running, restart the backend server so the Python runtime updates its local environment caches:
```bash
# Start/Restart backend
python backend/main.py
```

### 5. Verify and Audit
1. Open the **Cloud Control Center** dashboard in your browser.
2. Click the **Connect AWS** action button on the top right navigation bar or the **Verify Session** action inside the credentials card on the dashboard page.
3. Once STS verifies your caller credentials, the dashboard will display a `✅ AWS Connected` status banner and render your dynamic:
   * **AWS Account ID**
   * **Caller Role Session ARN**
   * **Active Region context**
   * **IAM User ID**

---

## 🗺️ Phase 7 - AWS Account Overview

The platform includes a dedicated **AWS Account Overview** page to audit high-level organization properties:

1. **Authentication State**: Dynamic visual feedback highlighting `✔ AWS Connected`.
2. **Account Alias Resolution**: Queries the secure IAM service via `iam_client.list_account_aliases()`. If permission blocks occur (e.g., standard restrictive IAM permissions), it handles them gracefully by displaying `Account Alias unavailable` while allowing the rest of the metadata to load cleanly.
3. **IAM Username Parsing**: Resolves the direct user name from STS or falls back gracefully to the final segment of the validated role ARN.
4. **Geographical Regions Indexing**: Resolves the list of active AWS Regions via EC2 `describe_regions()`. On privilege boundaries/denied permissions, it falls back gracefully to a robust list of active corporate regions and active region badges.

