# Cloud Control Center - System Architecture

This document describes the high-level architecture, design patterns, and deployment topologies for the **Cloud Control Center**.

## 1. Architectural Overview

The Cloud Control Center is designed using **Clean Architecture** and **Domain-Driven Design (DDD)** principles. It enforces strict separation of concerns, ensuring that business logic is independent of external frameworks, databases, and UI components.

```
                  ┌─────────────────────────────────────┐
                  │            Presentation             │
                  │    (React SPA / Tailwind CSS)       │
                  └──────────────────┬──────────────────┘
                                     │ (HTTPS / REST)
                  ┌──────────────────▼──────────────────┐
                  │            API Gateway              │
                  │        (FastAPI / ASGI)             │
                  └──────────────────┬──────────────────┘
                                     │
         ┌───────────────────────────┼───────────────────────────┐
         │ Core Backend Application  │                           │
         │                           │                           │
         │  ┌─────────────────────┐  │  ┌─────────────────────┐  │
         │  │   Handlers/Routes   │  │  │   AWS SDK (Boto3)   │  │
         │  └──────────┬──────────┘  │  └──────────▲──────────┘  │
         │             │             │             │             │
         │  ┌──────────▼──────────┐  │  ┌──────────┴──────────┐  │
         │  │   Use Cases / Core  │◄─┼─►│     Repositories    │  │
         │  │    Business Logic   │  │  │ (DB/AWS Integrations│  │
         │  └──────────┬──────────┘  │  └──────────▲──────────┘  │
         │             │             │             │             │
         │  ┌──────────▼──────────┐  │             │             │
         │  │   Entities/Models   ├──┘             │             │
         │  └─────────────────────┘                │             │
         └─────────────────────────────────────────┼─────────────┘
                                                   │ (SQLAlchemy / Boto3)
                                      ┌────────────▼────────────┐
                                      │   PostgreSQL / Cloud    │
                                      │   Infrastructure APIs   │
                                      └─────────────────────────┘
```

---

## 2. Tiered Core Structure

### 2.1 Domain Layer (Core Entities)
- Contains enterprise business models, value objects, and domain rules.
- Completely framework-agnostic. No SQL-ORM decorators or AWS SDK dependencies in this core layer.

### 2.2 Application Layer (Use Cases)
- Defines the application interface, data transfer objects (DTOs), and core transaction logic.
- Orchestrates the data flow to and from the domain entities, utilizing repository interfaces.

### 2.3 Infrastructure Layer
- Implements repository interfaces for persistent storage (SQLAlchemy + PostgreSQL).
- Houses the AWS SDK (Boto3) connectors to execute commands against AWS APIs (EC2, RDS, IAM, Cost Explorer, CloudWatch).
- Handles third-party service abstractions, logger configurations, and configuration loading.

### 2.4 Interface Layer (Presentation & APIs)
- **Backend API**: FastAPI framework serving as the REST API wrapper around the Application Use Cases.
- **Frontend App**: Single Page Application built on React, utilizing modern component design to interact with the backend APIs.

---

## 3. Production AWS Deployment Topology

The production architecture leverages AWS best practices for high availability, security, and scalability.

```
                                  [ Users ]
                                      │
                                      ▼
                             [ AWS Cloudfront ]
                                      │
                           [ Application Load Balancer ]
                                      │
                 ┌────────────────────┴────────────────────┐
                 ▼                                         ▼
      [ Private Subnet - AZ1 ]                  [ Private Subnet - AZ2 ]
   ┌───────────────────────────┐             ┌───────────────────────────┐
   │ [ ECS Fargate / FastAPI ] │             │ [ ECS Fargate / FastAPI ] │
   └─────────────┬─────────────┘             └─────────────┬─────────────┘
                 │                                         │
                 └────────────────────┬────────────────────┘
                                      ▼
                        [ Private Database Subnets ]
                 ┌─────────────────────────────────────────┐
                 │          [ Amazon RDS PostgeSQL ]       │
                 │              (Multi-AZ Active/Standby)  │
                 └─────────────────────────────────────────┘
```

### Key Infrastructure Components:
- **VPC & Networking**: Custom VPC spanning 2 Availability Zones (AZs) with Public and Private Subnets. NAT Gateways enable secure outbound internet traffic for backend containers in private subnets.
- **Compute Layer**: Amazon ECS on AWS Fargate hosts containerized FastAPI backend nodes behind an Application Load Balancer (ALB). Autoscale policies are triggered via CPU/Memory usage metrics.
- **Data Store**: Multi-AZ Amazon RDS PostgreSQL instance configured with encrypted volumes, automated snapshot schedules, and private subnets accessible only by ECS task security groups.
- **Security & Identity**:
  - **AWS Secrets Manager** stores sensitive database credentials and API keys.
  - **IAM Roles**: Task execution roles are strictly bound to least-privilege policies.
  - **Security Groups** limit inbound traffic to port 443 (HTTPS) at the ALB, and port 5432 (PostgreSQL) is restricted exclusively to the ECS Security Group.
