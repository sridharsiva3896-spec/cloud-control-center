# AWS Cloud Architect - Interview Questions & Key Patterns

This study resource contains high-frequency AWS cloud architectural questions, design patterns, and talking points. These are structured specifically to help you articulate design decisions during senior engineering and cloud architect interviews, using the **Cloud Control Center** as a case study.

---

## Question 1: How do you design for High Availability (HA) and Fault Tolerance when deploying containerized APIs like FastAPI on AWS?

### Suggested Structural Answer:
1. **Multi-AZ Strategy**: Deploy the backend microservice inside an **Elastic Container Service (ECS) on Fargate** cluster, distributing container tasks across at least two private subnets spanning multiple **Availability Zones (AZs)**.
2. **Dynamic Routing**: Place an **Application Load Balancer (ALB)** in public subnets to route external client traffic to healthy tasks in the private subnets. Use HTTP health checks (e.g., checking the `/api/v1/health` endpoint) with conservative thresholds (e.g., 2 consecutive failures before removing a container).
3. **Database High Availability**: Pair the compute layer with an **Amazon RDS PostgreSQL** instance in a **Multi-AZ deployment**. Under the hood, RDS continuously replicates data synchronously to a standby instance in a different AZ. In case of an infrastructure failure or AZ outage, AWS automatically handles DNS failover to the standby in less than 60 seconds with zero data loss.
4. **Auto-Scaling Policy**: Implement Target Tracking scaling policies on the ECS Service based on the average CPU utilization and Application Load Balancer Request Count per Target metrics to absorb sudden traffic spikes.

---

## Question 2: How do you enforce the Principle of Least Privilege (PoLP) for an application interacting with AWS resources?

### Suggested Structural Answer:
- Avoid hardcoding permanent credentials (such as AWS access keys) inside container images or filesystems.
- Use **IAM Roles** instead of IAM Users wherever possible.
- **For local dev**: Use local configuration profiles managed via `aws configure` and restricted IAM credentials that have limited permission policies.
- **For production AWS Fargate**: Configure two distinct roles:
  1. **ECS Task Execution Role**: Grants permission to the ECS agent to perform system operations (e.g., pulling images from Amazon ECR, sending logs to Amazon CloudWatch, fetching secrets from AWS Secrets Manager).
  2. **ECS Task Role**: Grants permissions directly to the running application code (e.g., allowing Boto3 to execute `ec2:DescribeInstances` and `ce:GetCostAndUsage`).
- Craft specific, custom IAM policies restricting access to only the required resources and actions. For example, do not use wildcard policies like `"Action": "ec2:*"`; instead, specify precise read/action APIs like `ec2:DescribeInstances` and `ec2:StartInstances`.

---

## Question 3: How do you secure database credentials, API keys, and other application secrets in a cloud environment?

### Suggested Structural Answer:
- Deploy **AWS Secrets Manager** to store the database credentials (like password and host connection string) and external third-party API keys securely.
- Enable automatic secret rotation policies within Secrets Manager to periodically update passwords in Amazon RDS without human intervention, ensuring credentials remain secure.
- Configure IAM policies to allow the ECS task to read only its respective secret. Integrate Secrets Manager directly into the ECS Task Definition so that secrets are safely injected as standard environment variables into the container during task startup, preventing them from being stored or exposed in Git or image layers.
- Encrypt all secrets at rest using a custom-managed **KMS Customer Managed Key (CMK)**, rather than relying on default AWS-managed keys, to enable fine-grained access audits.

---

## Question 4: How can we optimize AWS costs for this Cloud Control Center workload? (The Well-Architected Cost Optimization Pillar)

### Suggested Structural Answer:
- **Compute Sizing (Serverless vs. Provisioned)**: By utilizing AWS Fargate instead of EC2 servers, we eliminate resource waste from idle compute. We pay only for the exact vCPU and memory allocated per second of task runtime.
- **Auto-Scaling and Scale-to-Zero**: Configure the ECS service scaling policies to scale down to the minimum required tasks during quiet hours (e.g., weekends/nights for internal administrative systems).
- **Database Engine Optimization**: Use Aurora Serverless v2 for workloads with unpredictable or variable traffic, allowing the database database to scale capacities automatically between active peaks and scale down during periods of inactivity.
- **Storage Lifecycle Management**: Apply Amazon S3 lifecycle rules on bucket logs and backup repositories, automatically transitioning data to cheaper storage tiers (like S3 Glacier Deep Archive) after 30 days, or permanently deleting them after 90 days.
