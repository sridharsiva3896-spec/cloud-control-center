# Cloud Control Center - Local Development Guide

This guide is for developers and architects setting up the **Cloud Control Center** application foundation on a local workstation.

---

## 1. Prerequisites

Ensure the following tools are installed on your system before proceeding:

| Software | Minimum Version | Installation Check |
| :--- | :--- | :--- |
| **Docker Engine** | 24.0.0+ | `docker --version` |
| **Docker Compose** | 2.20.0+ | `docker compose version` |
| **Node.js** | v20.0.0+ | `node -v` |
| **Python** | 3.11+ | `python3 --version` |
| **AWS CLI v2** | 2.15.0+ | `aws --version` |

---

## 2. Directory Structure Setup

The core project maintains a separate directory hierarchy for isolated development:

```
cloud-control-center/
├── backend/            # FastAPI / Python Application
├── frontend/           # React / TypeScript Web Dashboard
├── docker/             # Docker configuration (Dockerfiles, compose configs)
├── docs/               # Architecture, API, and AWS references
└── screenshots/        # Portfolio visuals and assets
```

---

## 3. Configuration & Environment Setup

### 3.1 Local Environment Secrets File (`.env`)
Create a copy of `.env.example` in both `backend/` and `frontend/` directories:

```bash
# In backend/
cp .env.example .env
```

### 3.2 Key Variable Declarations:
```env
# Backend Environment
ENVIRONMENT=development
DATABASE_URL=postgresql://postgres:postgres_secure_pass@localhost:5432/cloud_control_db
AWS_REGION=us-east-1
AWS_ACCESS_KEY_ID=mock_or_real_key_here
AWS_SECRET_ACCESS_KEY=mock_or_real_secret_here

# Frontend Environment
VITE_API_URL=http://localhost:8000/api/v1
```

---

## 4. Run Locally (The Containerized Way)

Docker-compose manages both core systems and the database layer simultaneously during local iterations.

```bash
# Navigate to the docker container orchestration folder
cd docker/

# Build containers with fresh changes
docker compose build

# Boot local services in detached mode
docker compose up -d

# Verify all containers are running cleanly
docker compose ps
```

---

## 5. Development Workflows (Non-Containerized)

If you prefer hot-reloads and running directly on your host machine:

### 5.1 Backend Launch (FastAPI)
```bash
cd backend/
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --reload --host 127.0.0.1 --port 8000
```

### 5.2 Frontend Launch (React + Vite)
```bash
cd frontend/
npm install
npm run dev
```
The client application will serve on [http://localhost:5173](http://localhost:5173).
