# Cloud Control Center - Troubleshooting Guide

This guide compiles common errors, edge cases, and diagnostics steps encountered during local development and AWS production deployments of the **Cloud Control Center**.

---

## 1. Local Development Issues

### 1.1 Local PostgreSQL Container Fails to Start
- **Symptom**: Docker logs for the database container display: `bind: address already in use` or connection timeout.
- **Root Cause**: A local instance of PostgreSQL is already running on port `5432` on the host machine.
- **Remedy**:
  - Stop your local database service:
    ```bash
    # On MacOS
    brew services stop postgresql
    
    # On Ubuntu/Debian
    sudo systemctl stop postgresql
    ```
  - Alternatively, change the host port binding inside your `docker-compose.yml` to map to an alternative port (e.g., `5433:5432`).

### 1.2 "No credentials found" when Backend initializes Boto3
- **Symptom**: Backend logs display `botocore.exceptions.NoCredentialsError: Unable to locate credentials`.
- **Root Cause**: Boto3 client initialized without accessible AWS environment variables or config files.
- **Remedy**:
  - Verify your `.env` file in `/backend` contains correct values for `AWS_ACCESS_KEY_ID` and `AWS_SECRET_ACCESS_KEY`.
  - Alternatively, run `aws configure` on your local host to generate credentials in `~/.aws/credentials` and mount that directory into your local docker container.

---

## 2. AWS Cloud Production Issues

### 2.1 ECS Tasks Fail Health Checks and Crash Loop
- **Symptom**: Tasks cycle continuously between `PROVISIONING`, `RUNNING`, and `DEACTIVATING` states.
- **Root Cause**:
  1. The API server did not bind to host `0.0.0.0` or port `8000`. If it bound only to `127.0.0.1`, outside entities like the ALB cannot reach it.
  2. The target group health check path is misconfigured (e.g., pointing to `/` instead of `/api/v1/health` which returns 200).
  3. Security groups do not allow ingress traffic from the ALB into the ECS task security group on port `8000`.
- **Remedy**:
  - Check the Container Logs in Amazon CloudWatch to verify the application server booted successfully.
  - Review Security Group rules: Ensure the ECS security group allows incoming traffic on port `8000` from the ALB security group ID.

### 2.2 ECS Task Cannot Connect to RDS PostgreSQL
- **Symptom**: API times out after 30 seconds when querying the database, displaying `psycopg2.OperationalError: connection to server at ... failed`.
- **Root Cause**: Network traffic is blocked between compute and database subnets.
- **Remedy**:
  - Verify the RDS Security Group has an Inbound rule allowing traffic on port `5432` with the source set specifically to the ECS task Security Group ID.
  - Ensure the RDS database subnet group is part of the same VPC and routing tables are not conflicting.
