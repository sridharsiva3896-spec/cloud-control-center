import { HashRouter as Router, Routes, Route } from 'react-router-dom';
import MainLayout from './layouts/MainLayout';
import DashboardPage from './pages/DashboardPage';
import AWSAccountPage from './pages/AWSAccountPage';
import EC2Page from './pages/EC2Page';
import S3Page from './pages/S3Page';
import IAMPage from './pages/IAMPage';
import CloudWatchPage from './pages/CloudWatchPage';
import CloudTrailPage from './pages/CloudTrailPage';
import CostExplorerPage from './pages/CostExplorerPage';
import SecurityPage from './pages/SecurityPage';
import SearchPage from './pages/SearchPage';
import VPCMonitoringPage from './pages/VPCMonitoringPage';
import LoadBalancerMonitoringPage from './pages/LoadBalancerMonitoringPage';
import LambdaMonitoringPage from './pages/LambdaMonitoringPage';
import RDSMonitoringPage from './pages/RDSMonitoringPage';
import EBSMonitoringPage from './pages/EBSMonitoringPage';
import TagExplorerPage from './pages/TagExplorerPage';
import { BackendStatusProvider } from './api/BackendStatusContext';
import { RegionProvider } from './context/RegionContext';
import { NotificationProvider } from './context/NotificationContext';
import { 
  ServerCrash
} from 'lucide-react';

/**
 * Root Application Entry Point.
 * Implements HashRouter to serve safe, portable route states in standard iframe containers.
 */
export default function App() {
  return (
    <BackendStatusProvider>
      <RegionProvider>
        <NotificationProvider>
          <Router>
            <MainLayout>
            <Routes>
            
            {/* Main Dashboard Portal */}
            <Route path="/" element={<DashboardPage />} />

            {/* AWS Account Module Route */}
            <Route path="/aws-account" element={<AWSAccountPage />} />

            {/* EC2 Instance Route */}
            <Route path="/ec2" element={<EC2Page />} />

            {/* S3 Buckets Route */}
            <Route path="/s3" element={<S3Page />} />

            {/* IAM Identifiers Route */}
            <Route path="/iam" element={<IAMPage />} />

            {/* CloudWatch Telemetry Route */}
            <Route path="/cloudwatch" element={<CloudWatchPage />} />

            {/* CloudTrail Audit History Route */}
            <Route path="/cloudtrail" element={<CloudTrailPage />} />

            {/* Cost Explorer Route */}
            <Route path="/cost" element={<CostExplorerPage />} />

            {/* Security Compliance Route */}
            <Route path="/security" element={<SecurityPage />} />

            {/* Global AWS Search Route */}
            <Route path="/search" element={<SearchPage />} />

            {/* VPC Networking Monitoring Route */}
            <Route path="/vpc" element={<VPCMonitoringPage />} />

            {/* Load Balancer Monitoring Route */}
            <Route path="/load-balancers" element={<LoadBalancerMonitoringPage />} />

            {/* Lambda Monitoring Route */}
            <Route path="/lambda" element={<LambdaMonitoringPage />} />

            {/* RDS Monitoring Route */}
            <Route path="/rds" element={<RDSMonitoringPage />} />

            {/* EBS Monitoring Route */}
            <Route path="/ebs" element={<EBSMonitoringPage />} />

            {/* Tag Explorer Route */}
            <Route path="/tags" element={<TagExplorerPage />} />

            {/* Catch-all Not Found Handler */}
            <Route path="*" element={
              <div className="py-20 flex flex-col items-center justify-center text-center space-y-4">
                <ServerCrash className="w-12 h-12 text-rose-500" />
                <h2 className="text-lg font-bold font-mono uppercase text-white">404 - Page Not Found</h2>
                <p className="text-xs text-slate-500">The requested administration pathway does not exist in the dashboard index.</p>
              </div>
            } />

          </Routes>
        </MainLayout>
      </Router>
    </NotificationProvider>
    </RegionProvider>
  </BackendStatusProvider>
  );
}
