import { createContext, useContext, useState, useEffect, ReactNode, useCallback } from 'react';
import { getHealth } from '../services/healthService';
import { connectAWS, AWSConnectionResponse, AWSConnectCredentials } from '../services/awsService';
import { getAWSSession, logoutAWS } from '../services/sessionService';

export type ConnectionStatus = 'checking' | 'connected' | 'offline';

export interface AWSConnectionState {
  connected: boolean;
  checking: boolean;
  accountId?: string;
  arn?: string;
  userId?: string;
  region?: string;
  error?: string | null;
  errorType?: string;
}

interface BackendStatusContextType {
  status: ConnectionStatus;
  error: string | null;
  triggerRetry: () => Promise<void>;
  awsState: AWSConnectionState;
  triggerConnectAWS: (credentials?: AWSConnectCredentials) => Promise<AWSConnectionResponse>;
  disconnectAWSLocal: () => Promise<void> | void;
}

const BackendStatusContext = createContext<BackendStatusContextType | undefined>(undefined);

/**
 * Hook to consume the backend connection state anywhere in the application.
 */
export function useBackendStatus() {
  const context = useContext(BackendStatusContext);
  if (!context) {
    throw new Error('useBackendStatus must be used within a BackendStatusProvider');
  }
  return context;
}

interface ProviderProps {
  children: ReactNode;
}

/**
 * BackendStatusProvider manages live polling, manual retries, and AWS connection state.
 */
export function BackendStatusProvider({ children }: ProviderProps) {
  const [status, setStatus] = useState<ConnectionStatus>('checking');
  const [error, setError] = useState<string | null>(null);
  
  const [awsState, setAwsState] = useState<AWSConnectionState>({
    connected: false,
    checking: false,
    error: null
  });

  const checkConnection = useCallback(async () => {
    setStatus('checking');
    setError(null);
    try {
      const data = await getHealth();
      if (data.status === 'healthy') {
        setStatus('connected');
        
        // Verify active AWS session on the backend to synchronize state
        try {
          const sessionData = await getAWSSession();
          if (sessionData.connected) {
            setAwsState({
              connected: true,
              checking: false,
              accountId: sessionData.account_id,
              arn: sessionData.arn,
              userId: sessionData.user_id,
              region: sessionData.region,
              error: null
            });
          } else {
            setAwsState({
              connected: false,
              checking: false,
              error: null
            });
          }
        } catch (sessErr) {
          console.error('Failed to sync AWS session on connection check', sessErr);
        }
      } else {
        setStatus('offline');
        setError('Backend reported sub-optimal status.');
      }
    } catch (err: any) {
      setStatus('offline');
      setError(err.message || 'Unable to establish standard connection.');
    }
  }, []);

  const triggerConnectAWS = useCallback(async (credentials?: AWSConnectCredentials): Promise<AWSConnectionResponse> => {
    if (!credentials) {
      window.dispatchEvent(new Event('open-connect-modal'));
      return { connected: false, message: 'Opening AWS Connection Modal' };
    }

    setAwsState(prev => ({ ...prev, checking: true, error: null, errorType: undefined }));
    try {
       const data: AWSConnectionResponse = await connectAWS(credentials);
      if (data.connected) {
        setAwsState({
          connected: true,
          checking: false,
          accountId: data.account_id,
          arn: data.arn,
          userId: data.user_id,
          region: data.region,
          error: null
        });
        // Dispatch event to notify modules to reload
        window.dispatchEvent(new Event('aws-login'));
      } else {
        setAwsState({
          connected: false,
          checking: false,
          error: data.message,
          errorType: data.error_type
        });
      }
      return data;
    } catch (err: any) {
      const errorResponse: AWSConnectionResponse = {
        connected: false,
        message: err.message || 'Unable to establish standard STS connection.',
        error_type: 'NetworkError'
      };
      setAwsState({
        connected: false,
        checking: false,
        error: errorResponse.message,
        errorType: errorResponse.error_type
      });
      return errorResponse;
    }
  }, []);

  const disconnectAWSLocal = useCallback(async () => {
    setAwsState(prev => ({ ...prev, checking: true }));
    try {
      await logoutAWS();
    } catch (err) {
      console.error('Failed to terminate AWS backend session', err);
    } finally {
      setAwsState({
        connected: false,
        checking: false,
        error: null
      });
      // Notify other parts of application of logout
      window.dispatchEvent(new Event('aws-logout'));
    }
  }, []);

  // Poll or check on load
  useEffect(() => {
    checkConnection();
  }, [checkConnection]);

  return (
    <BackendStatusContext.Provider value={{
      status,
      error,
      triggerRetry: checkConnection,
      awsState,
      triggerConnectAWS,
      disconnectAWSLocal
    }}>
      {children}
    </BackendStatusContext.Provider>
  );
}
