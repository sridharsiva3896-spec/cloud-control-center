import axios from 'axios';

// Dynamically determine the base URL. 
// When running in the AI Studio cloud sandbox/preview environment (non-localhost),
// we use relative paths (empty baseURL) to let the container's integrated proxy route `/api` traffic.
// In local development on localhost, we fallback to the default port 8000.
const getBaseURL = (): string => {
  const envUrl = (import.meta as any).env?.VITE_API_URL;
  if (envUrl) {
    return envUrl;
  }
  
  if (typeof window !== 'undefined') {
    const hostname = window.location.hostname;
    if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
      return ''; // Relative path
    }
  }
  
  return 'http://127.0.0.1:8000';
};

// Instantiate Axios client with custom default configurations
const apiClient = axios.create({
  baseURL: getBaseURL(),
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
  },
});

// Generate or retrieve a random, stateless session ID for this browser session/tab.
// This is not a credential and is only used to identify the isolated AWS session on the backend.
let awsSessionId = '';
if (typeof window !== 'undefined') {
  try {
    awsSessionId = window.sessionStorage.getItem('aws_session_id') || '';
    if (!awsSessionId) {
      awsSessionId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
      window.sessionStorage.setItem('aws_session_id', awsSessionId);
    }
  } catch (err) {
    console.warn('sessionStorage is not available. Falling back to in-memory session ID.', err);
    awsSessionId = Math.random().toString(36).substring(2, 15) + Math.random().toString(36).substring(2, 15);
  }
}

// Add a request interceptor to append the session ID header
apiClient.interceptors.request.use((config) => {
  if (awsSessionId) {
    config.headers['X-AWS-Session-ID'] = awsSessionId;
  }
  return config;
});

export default apiClient;
