import React from 'react';
import { useNotification } from '../hooks/useNotification';
import { Bell } from 'lucide-react';

interface NotificationBellProps {
  onToggle: () => void;
  isOpen: boolean;
}

export const NotificationBell: React.FC<NotificationBellProps> = ({ 
  onToggle, 
  isOpen 
}) => {
  const { unreadCount } = useNotification();

  return (
    <button
      id="notification-bell-button"
      onClick={onToggle}
      className={`relative p-2 rounded-xl border transition-all duration-200 ${
        isOpen 
          ? 'bg-slate-800/80 border-slate-700 text-white' 
          : 'bg-slate-800/40 border-slate-800/80 text-slate-300 hover:text-white hover:bg-slate-800/60'
      }`}
      title="Toggle notification center"
    >
      <Bell className={`w-4 h-4 ${unreadCount > 0 ? 'animate-bounce-subtle' : ''}`} />
      
      {unreadCount > 0 && (
        <span 
          className="absolute -top-1.5 -right-1.5 flex h-4 min-w-4 px-1 items-center justify-center rounded-full bg-amber-500 text-[9px] font-bold font-mono text-slate-950 shadow-lg border border-slate-950 animate-pulse-subtle"
          id="notification-unread-badge"
        >
          {unreadCount > 9 ? '9+' : unreadCount}
        </span>
      )}
    </button>
  );
};
