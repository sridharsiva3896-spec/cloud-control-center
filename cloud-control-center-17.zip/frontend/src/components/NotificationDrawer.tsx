import React, { useRef, useEffect } from 'react';
import { useNotification } from '../hooks/useNotification';
import { NotificationItem } from './NotificationItem';
import { 
  X, 
  Trash2, 
  CheckSquare, 
  BellOff 
} from 'lucide-react';

interface NotificationDrawerProps {
  isOpen: boolean;
  onClose: () => void;
}

export const NotificationDrawer: React.FC<NotificationDrawerProps> = ({ 
  isOpen, 
  onClose 
}) => {
  const { notifications, markAsRead, markAllRead, clearAll } = useNotification();
  const drawerRef = useRef<HTMLDivElement>(null);

  // Close drawer on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      // Don't close if we clicked the bell icon button which toggles it
      const target = event.target as HTMLElement;
      if (target.closest('#notification-bell-button')) {
        return;
      }

      if (drawerRef.current && !drawerRef.current.contains(event.target as Node)) {
        onClose();
      }
    }

    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div 
      ref={drawerRef}
      className="fixed inset-y-0 right-0 z-50 w-full sm:w-96 bg-slate-950 border-l border-slate-900 shadow-2xl flex flex-col animate-slide-in-right"
      id="notification-drawer"
    >
      {/* Header section with utilities */}
      <div className="p-4 border-b border-slate-900 flex items-center justify-between bg-slate-900/40">
        <div className="flex items-center gap-2">
          <span className="text-sm font-bold font-mono text-slate-200">
            Notifications
          </span>
          {notifications.length > 0 && (
            <span className="text-[10px] font-mono font-bold bg-amber-500/15 text-amber-500 px-1.5 py-0.5 rounded-full border border-amber-500/20">
              {notifications.length}
            </span>
          )}
        </div>

        <button
          onClick={onClose}
          className="text-slate-500 hover:text-white p-1 rounded-lg hover:bg-slate-900 transition-colors"
          title="Close Panel"
        >
          <X className="w-4 h-4" />
        </button>
      </div>

      {/* Utilities for batch operations */}
      {notifications.length > 0 && (
        <div className="px-4 py-2 bg-slate-900/20 border-b border-slate-900 flex items-center justify-between text-[11px] font-mono text-slate-500">
          <button
            onClick={markAllRead}
            className="hover:text-amber-500 flex items-center gap-1 transition-colors"
            title="Mark all notifications as read"
          >
            <CheckSquare className="w-3.5 h-3.5" />
            Mark All Read
          </button>

          <button
            onClick={clearAll}
            className="hover:text-rose-500 flex items-center gap-1 transition-colors"
            title="Clear all notification logs"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear All
          </button>
        </div>
      )}

      {/* Main notification lists */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-900/60 custom-scrollbar">
        {notifications.length === 0 ? (
          <div className="py-20 flex flex-col items-center justify-center text-center space-y-4 px-6">
            <div className="w-12 h-12 rounded-2xl bg-slate-900/50 flex items-center justify-center border border-slate-800">
              <BellOff className="w-5 h-5 text-slate-500" />
            </div>
            <div className="space-y-1">
              <h5 className="text-xs font-semibold text-slate-300 font-mono">No Notifications</h5>
              <p className="text-[11px] text-slate-500 max-w-xs leading-relaxed font-sans">
                You're all caught up! Real-time alerts, health heartbeats, and region transitions will be logged here.
              </p>
            </div>
          </div>
        ) : (
          notifications.map((notification) => (
            <NotificationItem
              key={notification.id}
              notification={notification}
              onMarkRead={markAsRead}
            />
          ))
        )}
      </div>

      {/* Footer statistics */}
      {notifications.length > 0 && (
        <div className="p-3 border-t border-slate-900 bg-slate-950 text-center text-[10px] font-mono text-slate-600">
          Log persistence capped at 100 historical records.
        </div>
      )}
    </div>
  );
};
