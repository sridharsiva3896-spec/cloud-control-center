import React from 'react';
import { Notification } from '../context/NotificationContext';
import { 
  CheckCircle2, 
  Info, 
  AlertTriangle, 
  XCircle, 
  Check, 
  Clock 
} from 'lucide-react';

interface NotificationItemProps {
  notification: Notification;
  onMarkRead: (id: string) => void;
}

export const NotificationItem: React.FC<NotificationItemProps> = ({ 
  notification, 
  onMarkRead 
}) => {
  const { id, title, message, type, timestamp, read, source } = notification;

  // Render icon depending on the notification level type
  const renderIcon = () => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />;
      case 'warning':
        return <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />;
      case 'error':
        return <XCircle className="w-4 h-4 text-rose-500 shrink-0" />;
      case 'info':
      default:
        return <Info className="w-4 h-4 text-sky-500 shrink-0" />;
    }
  };

  // Convert ISO timestamp into a user-friendly format (e.g., "10:15:30" or "June 27, 10:15")
  const formatTime = (isoString: string) => {
    try {
      const date = new Date(isoString);
      return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    } catch {
      return isoString;
    }
  };

  return (
    <div 
      className={`p-3.5 transition-all duration-200 border-l-2 flex flex-col gap-1.5 relative group ${
        read 
          ? 'bg-slate-950/20 border-l-transparent' 
          : 'bg-slate-900/40 border-l-amber-500'
      } hover:bg-slate-900/70`}
      id={`notification-item-${id}`}
    >
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2">
          {renderIcon()}
          <span className="font-mono text-[10px] uppercase font-bold tracking-wider text-slate-500">
            {source || 'System'}
          </span>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
            <Clock className="w-3 h-3" />
            {formatTime(timestamp)}
          </span>

          {!read && (
            <button
              onClick={() => onMarkRead(id)}
              className="text-slate-500 hover:text-amber-500 p-0.5 rounded transition-colors"
              title="Mark as Read"
            >
              <Check className="w-3 h-3" />
            </button>
          )}
        </div>
      </div>

      <div className="space-y-1 pl-6">
        <h4 className={`text-xs font-semibold ${read ? 'text-slate-400' : 'text-slate-100'}`}>
          {title}
        </h4>
        <p className="text-slate-400 text-[11px] leading-relaxed break-words font-sans">
          {message}
        </p>
      </div>
    </div>
  );
};
