import React from 'react';
import { useNotification } from '../hooks/useNotification';
import { 
  CheckCircle2, 
  XCircle, 
  X 
} from 'lucide-react';

export const ToastNotification: React.FC = () => {
  const { toasts, removeToast } = useNotification();

  if (toasts.length === 0) return null;

  return (
    <div 
      className="fixed top-20 right-4 z-50 flex flex-col gap-2 w-full max-w-sm pointer-events-none"
      id="toast-notification-container"
    >
      {toasts.map((toast) => {
        const isSuccess = toast.type === 'success';
        return (
          <div
            key={toast.id}
            className={`pointer-events-auto flex items-start gap-3 p-4 rounded-xl shadow-2xl border border-slate-800 backdrop-blur-md bg-slate-950/95 animate-fade-in-up transition-all`}
            id={`toast-item-${toast.id}`}
          >
            {isSuccess ? (
              <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            ) : (
              <XCircle className="w-5 h-5 text-rose-500 shrink-0 mt-0.5" />
            )}
            
            <div className="flex-1 space-y-1">
              <h5 className="text-xs font-semibold text-slate-100 font-sans">
                {toast.title}
              </h5>
              <p className="text-[11px] text-slate-400 font-sans leading-relaxed">
                {toast.message}
              </p>
            </div>

            <button
              onClick={() => removeToast(toast.id)}
              className="text-slate-500 hover:text-white p-0.5 rounded transition-colors shrink-0"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        );
      })}
    </div>
  );
};
