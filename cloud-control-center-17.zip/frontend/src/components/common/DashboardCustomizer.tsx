import { useState, useEffect } from 'react';
import { 
  Settings, X, Eye, EyeOff, MoveUp, MoveDown, RotateCcw, Save, GripVertical 
} from 'lucide-react';
import { useNotification } from '../../hooks/useNotification';

export interface CardItem {
  id: string;
  title: string;
}

const DEFAULT_CARDS: CardItem[] = [
  { id: 'session', title: 'AWS Session' },
  { id: 'account', title: 'AWS Account' },
  { id: 'ec2', title: 'Amazon EC2' },
  { id: 's3', title: 'Amazon S3' },
  { id: 'iam', title: 'IAM Active Scopes' },
  { id: 'security', title: 'Security Monitor' },
  { id: 'load_balancer', title: 'Load Balancers' },
  { id: 'lambda', title: 'AWS Lambda' },
  { id: 'vpc', title: 'VPC Monitoring' },
  { id: 'rds', title: 'Amazon RDS' },
  { id: 'ebs', title: 'Amazon EBS' },
  { id: 'cloudwatch', title: 'CloudWatch Alarms' },
  { id: 'cloudtrail', title: 'CloudTrail Logs' }
];

interface DashboardCustomizerProps {
  onLayoutChange: (layout: string[], hidden: string[]) => void;
  id?: string;
}

export default function DashboardCustomizer({ onLayoutChange, id }: DashboardCustomizerProps) {
  const [isOpen, setIsOpen] = useState(false);
  const [cards, setCards] = useState<CardItem[]>(DEFAULT_CARDS);
  const [hiddenCardIds, setHiddenCardIds] = useState<string[]>([]);
  const { addNotification } = useNotification();

  // Load layout on mount
  useEffect(() => {
    const savedLayout = localStorage.getItem('dashboard_layout');
    const savedHidden = localStorage.getItem('dashboard_hidden_cards');

    if (savedLayout) {
      try {
        const layoutIds = JSON.parse(savedLayout) as string[];
        // Map saved IDs back to card configurations, append any missing new cards
        const ordered = layoutIds
          .map(id => DEFAULT_CARDS.find(c => c.id === id))
          .filter((c): c is CardItem => !!c);
        
        const missing = DEFAULT_CARDS.filter(c => !layoutIds.includes(c.id));
        setCards([...ordered, ...missing]);
      } catch (e) {
        setCards(DEFAULT_CARDS);
      }
    } else {
      setCards(DEFAULT_CARDS);
    }

    if (savedHidden) {
      try {
        setHiddenCardIds(JSON.parse(savedHidden) as string[]);
      } catch (e) {
        setHiddenCardIds([]);
      }
    }
  }, []);

  // Update parent when cards state updates
  const propagateChanges = (currentCards: CardItem[], currentHidden: string[]) => {
    const layoutIds = currentCards.map(c => c.id);
    onLayoutChange(layoutIds, currentHidden);
  };

  // Toggle visibility of a card
  const handleToggleVisible = (cardId: string) => {
    let nextHidden: string[];
    if (hiddenCardIds.includes(cardId)) {
      nextHidden = hiddenCardIds.filter(id => id !== cardId);
    } else {
      nextHidden = [...hiddenCardIds, cardId];
    }
    setHiddenCardIds(nextHidden);
    propagateChanges(cards, nextHidden);
  };

  // Up/down reordering
  const handleMove = (index: number, direction: 'up' | 'down') => {
    const nextIndex = direction === 'up' ? index - 1 : index + 1;
    if (nextIndex < 0 || nextIndex >= cards.length) return;

    const updated = [...cards];
    const temp = updated[index];
    updated[index] = updated[nextIndex];
    updated[nextIndex] = temp;

    setCards(updated);
    propagateChanges(updated, hiddenCardIds);
  };

  // Save changes explicitly to Local Storage
  const handleSave = () => {
    const layoutIds = cards.map(c => c.id);
    localStorage.setItem('dashboard_layout', JSON.stringify(layoutIds));
    localStorage.setItem('dashboard_hidden_cards', JSON.stringify(hiddenCardIds));
    
    addNotification(
      'Layout Saved',
      'Your customized dashboard card ordering and visibility settings have been saved.',
      'success',
      'System'
    );
    setIsOpen(false);
  };

  // Reset layout to defaults
  const handleReset = () => {
    localStorage.removeItem('dashboard_layout');
    localStorage.removeItem('dashboard_hidden_cards');
    
    setCards(DEFAULT_CARDS);
    setHiddenCardIds([]);
    onLayoutChange(DEFAULT_CARDS.map(c => c.id), []);

    addNotification(
      'Layout Reset',
      'Dashboard layout and card visibility reverted to original standard system defaults.',
      'info',
      'System'
    );
    setIsOpen(false);
  };

  // Native HTML5 Drag and Drop handlers
  const handleDragStart = (e: React.DragEvent, index: number) => {
    e.dataTransfer.setData('text/plain', String(index));
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent, targetIndex: number) => {
    e.preventDefault();
    const sourceIndex = Number(e.dataTransfer.getData('text/plain'));
    if (isNaN(sourceIndex) || sourceIndex === targetIndex) return;

    const updated = [...cards];
    const [removed] = updated.splice(sourceIndex, 1);
    updated.splice(targetIndex, 0, removed);

    setCards(updated);
    propagateChanges(updated, hiddenCardIds);
  };

  return (
    <div id={id} className="relative inline-block font-mono">
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700/80 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all duration-200 shadow-md active:scale-95 cursor-pointer select-none"
      >
        <Settings className="w-4 h-4 text-slate-400" />
        <span>Customize Dashboard</span>
      </button>

      {isOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-50 flex items-center justify-center p-4 animate-fade-in">
          <div className="bg-[#0b0e17] border border-slate-800 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[85vh]">
            
            {/* Header */}
            <div className="p-4 border-b border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Settings className="w-4 h-4 text-blue-400" />
                <h2 className="text-sm font-bold text-white uppercase tracking-wider">
                  Dashboard Settings
                </h2>
              </div>
              <button
                onClick={() => setIsOpen(false)}
                className="text-slate-500 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Instruction Banner */}
            <div className="px-4 py-2 bg-blue-500/5 border-b border-blue-500/10 text-[11px] text-slate-400 leading-relaxed font-sans">
              Drag-and-drop cards to change layout order, or use the visibility switches to toggle widgets off/on.
            </div>

            {/* Cards List Panel */}
            <div className="flex-1 overflow-y-auto p-4 space-y-2">
              {cards.map((card, idx) => {
                const isHidden = hiddenCardIds.includes(card.id);
                return (
                  <div
                    key={card.id}
                    draggable
                    onDragStart={(e) => handleDragStart(e, idx)}
                    onDragOver={handleDragOver}
                    onDrop={(e) => handleDrop(e, idx)}
                    className={`flex items-center justify-between p-3 rounded-xl border transition-all cursor-grab active:cursor-grabbing ${
                      isHidden 
                        ? 'bg-slate-900/20 border-slate-900 text-slate-600' 
                        : 'bg-[#121624] border-slate-800 hover:border-slate-700/70 text-slate-200'
                    }`}
                  >
                    <div className="flex items-center gap-3">
                      <GripVertical className="w-4 h-4 text-slate-600 shrink-0" />
                      <span className="text-xs font-bold font-mono">
                        {card.title}
                      </span>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      {/* Up Reorder button */}
                      <button
                        type="button"
                        onClick={() => handleMove(idx, 'up')}
                        disabled={idx === 0}
                        className="p-1 text-slate-500 hover:text-slate-300 disabled:opacity-20 disabled:hover:text-slate-500"
                        title="Move Up"
                      >
                        <MoveUp className="w-3.5 h-3.5" />
                      </button>

                      {/* Down Reorder button */}
                      <button
                        type="button"
                        onClick={() => handleMove(idx, 'down')}
                        disabled={idx === cards.length - 1}
                        className="p-1 text-slate-500 hover:text-slate-300 disabled:opacity-20 disabled:hover:text-slate-500"
                        title="Move Down"
                      >
                        <MoveDown className="w-3.5 h-3.5" />
                      </button>

                      {/* Visibility Toggle Switch */}
                      <button
                        type="button"
                        onClick={() => handleToggleVisible(card.id)}
                        className={`p-1 rounded-lg transition-colors ml-2 ${
                          isHidden 
                            ? 'text-rose-500 hover:bg-rose-500/5' 
                            : 'text-emerald-400 hover:bg-emerald-500/5'
                        }`}
                        title={isHidden ? 'Show Card' : 'Hide Card'}
                      >
                        {isHidden ? (
                          <EyeOff className="w-4 h-4" />
                        ) : (
                          <Eye className="w-4 h-4" />
                        )}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Bottom Actions Footer */}
            <div className="p-4 border-t border-slate-800 bg-[#07090f] flex items-center justify-between gap-3">
              <button
                type="button"
                onClick={handleReset}
                className="flex items-center gap-1.5 px-3 py-2 bg-slate-900 hover:bg-rose-950/20 text-slate-400 hover:text-rose-400 border border-slate-800 hover:border-rose-900/30 rounded-xl text-xs font-bold transition-all"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span>Restore Defaults</span>
              </button>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={() => setIsOpen(false)}
                  className="px-3.5 py-2 text-slate-400 hover:text-white text-xs font-bold transition-all"
                >
                  Cancel
                </button>
                <button
                  type="button"
                  onClick={handleSave}
                  className="flex items-center gap-1.5 px-4 py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-bold transition-all shadow-md active:scale-95"
                >
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Configuration</span>
                </button>
              </div>
            </div>

          </div>
        </div>
      )}
    </div>
  );
}
