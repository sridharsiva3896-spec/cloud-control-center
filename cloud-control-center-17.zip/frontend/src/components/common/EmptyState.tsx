import { LucideIcon } from 'lucide-react';

interface EmptyStateProps {
  title: string;
  description: string;
  icon: LucideIcon;
  id?: string;
}

export default function EmptyState({ title, description, icon: Icon, id }: EmptyStateProps) {
  return (
    <div 
      id={id}
      className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500 font-mono"
    >
      <Icon className="w-10 h-10 text-slate-600 stroke-[1.5]" />
      <div className="flex flex-col gap-1 max-w-sm mx-auto">
        <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">{title}</p>
        <p className="text-[11px] text-slate-500 font-medium font-sans leading-relaxed">
          {description}
        </p>
      </div>
    </div>
  );
}
