import { useState, useRef, useEffect } from 'react';
import { Download, FileSpreadsheet, FileJson, ChevronDown } from 'lucide-react';
import { exportToCSV } from '../../utils/exportCsv';
import { exportToJSON } from '../../utils/exportJson';
import { useNotification } from '../../hooks/useNotification';

interface ExportMenuProps<T> {
  data: T[];
  filenamePrefix: string;
  id?: string;
}

export default function ExportMenu<T extends Record<string, any>>({ 
  data, 
  filenamePrefix,
  id 
}: ExportMenuProps<T>) {
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);
  const { addNotification } = useNotification();

  // Close when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleExportCSV = () => {
    setIsOpen(false);
    const filename = `${filenamePrefix}_${new Date().toISOString().slice(0, 10)}.csv`;
    const success = exportToCSV(data, filename);
    if (success) {
      addNotification('Export Successful', `Data exported as CSV to ${filename}`, 'info', 'System');
    } else {
      addNotification('Export Failed', 'Unable to compile dataset to CSV schema.', 'error', 'System');
    }
  };

  const handleExportJSON = () => {
    setIsOpen(false);
    const filename = `${filenamePrefix}_${new Date().toISOString().slice(0, 10)}.json`;
    const success = exportToJSON(data, filename);
    if (success) {
      addNotification('Export Successful', `Data exported as JSON to ${filename}`, 'info', 'System');
    } else {
      addNotification('Export Failed', 'Unable to compile dataset to JSON format.', 'error', 'System');
    }
  };

  return (
    <div id={id} ref={menuRef} className="relative inline-block text-left font-mono">
      <button
        onClick={() => setIsOpen(!isOpen)}
        disabled={data.length === 0}
        className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700/85 disabled:opacity-50 text-slate-300 hover:text-white rounded-xl text-xs font-bold transition-all shadow-md cursor-pointer select-none"
      >
        <Download className="w-3.5 h-3.5" />
        <span>Export</span>
        <ChevronDown className="w-3 h-3 text-slate-500" />
      </button>

      {isOpen && (
        <div className="absolute right-0 mt-2 w-44 rounded-xl bg-[#0f1422] border border-slate-800 shadow-2xl z-50 overflow-hidden py-1">
          <div className="px-3 py-1.5 text-[9px] font-bold text-slate-500 uppercase tracking-widest border-b border-slate-800/60">
            Export {data.length} Records
          </div>
          
          <button
            onClick={handleExportCSV}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/40 text-left transition-all"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Download CSV</span>
          </button>
          
          <button
            onClick={handleExportJSON}
            className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-slate-300 hover:text-white hover:bg-slate-800/40 text-left transition-all"
          >
            <FileJson className="w-4 h-4 text-purple-400" />
            <span>Download JSON</span>
          </button>
        </div>
      )}
    </div>
  );
}
