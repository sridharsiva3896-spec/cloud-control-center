import { Filter, RotateCcw } from 'lucide-react';

export interface FilterField {
  key: string;
  label: string;
  value: string;
  options: string[] | { label: string; value: string }[];
  onChange: (val: string) => void;
}

interface FilterPanelProps {
  fields: FilterField[];
  onReset?: () => void;
  id?: string;
}

export default function FilterPanel({ fields, onReset, id }: FilterPanelProps) {
  return (
    <div 
      id={id}
      className="flex flex-wrap items-center gap-3 w-full font-mono text-xs"
    >
      {fields.map((field) => {
        return (
          <div 
            key={field.key}
            className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0"
          >
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              {field.label}:
            </span>
            <select
              value={field.value}
              onChange={(e) => field.onChange(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {field.options.map((opt) => {
                const label = typeof opt === 'string' ? opt : opt.label;
                const val = typeof opt === 'string' ? opt : opt.value;
                return (
                  <option key={val} value={val} className="bg-[#121829] text-slate-200">
                    {label}
                  </option>
                );
              })}
            </select>
          </div>
        );
      })}

      {onReset && (
        <button
          onClick={onReset}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-900/40 hover:bg-slate-900/80 border border-slate-800/80 hover:border-slate-700/80 text-slate-400 hover:text-slate-200 rounded-xl transition-all cursor-pointer select-none"
          title="Reset Filters"
        >
          <RotateCcw className="w-3 h-3" />
          <span className="text-[10px] font-bold uppercase tracking-wider">Reset</span>
        </button>
      )}
    </div>
  );
}
