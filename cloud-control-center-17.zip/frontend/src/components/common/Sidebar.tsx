import { 
  LayoutDashboard, 
  Cloud, 
  Cpu, 
  Database, 
  Network,
  Lock, 
  Activity, 
  History, 
  TrendingUp, 
  ShieldCheck,
  Server,
  Zap,
  HardDrive,
  Tag
} from 'lucide-react';
import { NavLink } from 'react-router-dom';

interface SidebarProps {
  isOpen: boolean;
  onClose?: () => void;
}

/**
 * Sidebar navigation component for the Cloud Control Center.
 * Lists the core modules of the AWS administration portal.
 */
export default function Sidebar({ isOpen, onClose }: SidebarProps) {
  const menuItems = [
    { name: 'Dashboard', path: '/', icon: LayoutDashboard },
    { name: 'AWS Account', path: '/aws-account', icon: Cloud },
    { name: 'Tag Explorer', path: '/tags', icon: Tag },
    { name: 'EC2 Instances', path: '/ec2', icon: Cpu },
    { name: 'S3 Buckets', path: '/s3', icon: Database },
    { name: 'VPC Monitoring', path: '/vpc', icon: Network },
    { name: 'Load Balancers', path: '/load-balancers', icon: Server },
    { name: 'Lambda Monitoring', path: '/lambda', icon: Zap },
    { name: 'RDS Monitoring', path: '/rds', icon: Database },
    { name: 'EBS Monitoring', path: '/ebs', icon: HardDrive },
    { name: 'IAM Scopes', path: '/iam', icon: Lock },
    { name: 'CloudWatch Metrics', path: '/cloudwatch', icon: Activity },
    { name: 'CloudTrail Audit', path: '/cloudtrail', icon: History },
    { name: 'Cost Explorer', path: '/cost', icon: TrendingUp },
    { name: 'Security Monitor', path: '/security', icon: ShieldCheck },
  ];

  return (
    <>
      {/* Mobile Sidebar Backdrop Overlay */}
      {isOpen && (
        <div 
          className="fixed inset-0 bg-slate-950/60 backdrop-blur-sm z-30 lg:hidden"
          onClick={onClose}
        />
      )}

      {/* Sidebar Container */}
      <aside 
        id="sidebar"
        className={`fixed lg:static top-0 left-0 bottom-0 w-64 bg-[#0f1422] border-r border-slate-800/80 z-40 transform transition-transform duration-300 ease-in-out lg:transform-none flex flex-col h-full ${
          isOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'
        }`}
      >
        {/* Branding header in Sidebar */}
        <div className="h-16 flex items-center px-6 border-b border-slate-800/80 bg-slate-900/40">
          <div className="flex items-center gap-2.5">
            <span className="flex items-center justify-center bg-gradient-to-tr from-amber-500 to-amber-600 p-1.5 rounded-lg text-slate-950 shadow-md shadow-amber-500/10">
              <Cloud className="w-5 h-5" />
            </span>
            <span className="font-bold text-sm tracking-wide text-white font-mono uppercase">AWS Control Center</span>
          </div>
        </div>

        {/* Navigation list */}
        <nav className="flex-1 px-4 py-6 space-y-1 overflow-y-auto custom-scrollbar">
          {menuItems.map((item) => {
            const Icon = item.icon;
            return (
              <NavLink
                key={item.name}
                to={item.path}
                onClick={onClose}
                className={({ isActive }) => `
                  flex items-center gap-3 px-4 py-3 rounded-xl text-xs font-semibold tracking-wide transition-all duration-150 group
                  ${isActive 
                    ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40 border border-transparent'
                  }
                `}
              >
                <Icon className="w-4 h-4 shrink-0 transition-transform group-hover:scale-105" />
                <span>{item.name}</span>
              </NavLink>
            );
          })}
        </nav>

        {/* Console Footnote */}
        <div className="p-4 border-t border-slate-800/60 bg-slate-900/20">
          <div className="bg-slate-950/50 p-3 rounded-lg border border-slate-800/50">
            <div className="text-[10px] text-slate-500 font-mono flex items-center justify-between">
              <span>Environment</span>
              <span className="text-amber-500 font-semibold">Sandbox</span>
            </div>
          </div>
        </div>
      </aside>
    </>
  );
}
