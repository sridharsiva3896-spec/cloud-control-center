import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { 
  Search, 
  Sun, 
  Moon, 
  Menu, 
  Zap, 
  Server, 
  Database, 
  User, 
  Key, 
  Users, 
  Loader2, 
  X,
  Globe,
  ChevronDown
} from 'lucide-react';
import { useBackendStatus } from '../../api/BackendStatusContext';
import { searchAWS } from '../../services/searchService';
import { SearchResult } from '../../types/search';
import { useRegion } from '../../hooks/useRegion';
import { NotificationBell } from '../NotificationBell';
import { NotificationDrawer } from '../NotificationDrawer';

interface TopNavbarProps {
  onMenuToggle: () => void;
  onConnectClick: () => void;
  isDarkTheme: boolean;
  onThemeToggle?: () => void;
}

/**
 * Top horizontal navigation bar.
 * Provides controls for searching modules, toggling UI themes, and connecting accounts.
 */
export default function TopNavbar({ 
  onMenuToggle, 
  onConnectClick, 
  isDarkTheme, 
  onThemeToggle 
}: TopNavbarProps) {
  const { status, awsState, disconnectAWSLocal } = useBackendStatus();
  const { selectedRegion, changeRegion, regions, regionDetails } = useRegion();
  const navigate = useNavigate();

  const [searchVal, setSearchVal] = useState('');
  const [suggestions, setSuggestions] = useState<SearchResult[]>([]);
  const [loading, setLoading] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [showRegionDropdown, setShowRegionDropdown] = useState(false);
  const [isNotificationsOpen, setIsNotificationsOpen] = useState(false);

  const containerRef = useRef<HTMLDivElement>(null);
  const regionDropdownRef = useRef<HTMLDivElement>(null);

  // Close region dropdown on click outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (regionDropdownRef.current && !regionDropdownRef.current.contains(event.target as Node)) {
        setShowRegionDropdown(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Debounced query fetching
  useEffect(() => {
    const trimmed = searchVal.trim();
    if (!trimmed) {
      setSuggestions([]);
      setLoading(false);
      return;
    }

    setLoading(true);
    const timeoutId = setTimeout(async () => {
      try {
        const response = await searchAWS(trimmed);
        setSuggestions(response.results || []);
      } catch (err) {
        console.error('Failed to load search suggestions', err);
        setSuggestions([]);
      } finally {
        setLoading(false);
      }
    }, 300);

    return () => clearTimeout(timeoutId);
  }, [searchVal]);

  // Click outside to dismiss dropdown suggestions
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (containerRef.current && !containerRef.current.contains(event.target as Node)) {
        setShowSuggestions(false);
      }
    }
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = searchVal.trim();
    if (trimmed) {
      navigate(`/search?q=${encodeURIComponent(trimmed)}`);
      setShowSuggestions(false);
    }
  };

  const handleSuggestionClick = (item: SearchResult) => {
    setSearchVal(item.name);
    navigate(`/search?q=${encodeURIComponent(item.name)}`);
    setShowSuggestions(false);
  };

  const clearInput = () => {
    setSearchVal('');
    setSuggestions([]);
  };

  const getServiceIcon = (service: string, resourceType: string) => {
    switch (service) {
      case 'EC2':
        return <Server className="w-3.5 h-3.5 text-orange-400" />;
      case 'S3':
        return <Database className="w-3.5 h-3.5 text-emerald-400" />;
      case 'IAM':
        if (resourceType === 'Role') return <Key className="w-3.5 h-3.5 text-purple-400" />;
        if (resourceType === 'Group') return <Users className="w-3.5 h-3.5 text-purple-400" />;
        return <User className="w-3.5 h-3.5 text-purple-400" />;
      default:
        return <Search className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  const getBadgeColors = (service: string) => {
    switch (service) {
      case 'EC2':
        return 'text-orange-400 bg-orange-500/10 border-orange-500/15';
      case 'S3':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15';
      case 'IAM':
        return 'text-purple-400 bg-purple-500/10 border-purple-500/15';
      default:
        return 'text-slate-400 bg-slate-500/10 border-slate-500/15';
    }
  };

  return (
    <>
      <header className="bg-[#0f1422] border-b border-slate-800/80 sticky top-0 z-20">
        
        {/* Main Navigation Row */}
        <div className="h-16 px-4 md:px-6 flex items-center justify-between">
          
          {/* Search Input Section */}
          <div className="flex items-center gap-4 flex-1 max-w-md" ref={containerRef}>
            <button 
              id="mobile-menu-btn"
              onClick={onMenuToggle}
              className="lg:hidden p-2 rounded-lg bg-slate-800/50 border border-slate-700/60 text-slate-300 hover:text-white"
              aria-label="Toggle navigation menu"
            >
              <Menu className="w-5 h-5" />
            </button>

            <form onSubmit={handleSearchSubmit} className="relative w-full hidden sm:block">
              <span className="absolute inset-y-0 left-3 flex items-center text-slate-500 pointer-events-none">
                {loading ? (
                  <Loader2 className="w-4 h-4 animate-spin text-slate-400" />
                ) : (
                  <Search className="w-4 h-4" />
                )}
              </span>
              <input 
                type="text" 
                value={searchVal}
                onChange={(e) => {
                  setSearchVal(e.target.value);
                  setShowSuggestions(true);
                }}
                onFocus={() => setShowSuggestions(true)}
                placeholder="Search resources, services, and documentation..." 
                className="w-full pl-10 pr-10 py-2 bg-slate-950 border border-slate-800/80 rounded-xl text-xs text-slate-300 placeholder-slate-500 focus:outline-none focus:border-amber-500/50 transition-colors font-mono"
              />
              {searchVal && (
                <button 
                  type="button"
                  onClick={clearInput}
                  className="absolute inset-y-0 right-3 flex items-center text-slate-500 hover:text-slate-300"
                >
                  <X className="w-4 h-4" />
                </button>
              )}

              {/* Suggestions Dropdown */}
              {showSuggestions && searchVal.trim() && (
                <div className="absolute top-full left-0 right-0 mt-2 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-50 font-mono text-xs">
                  {loading && suggestions.length === 0 ? (
                    <div className="px-4 py-3 text-xs text-slate-500 flex items-center gap-2">
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Scanning AWS cloud indices...
                    </div>
                  ) : suggestions.length === 0 ? (
                    <div className="px-4 py-3 text-xs text-slate-500">
                      No matching AWS resources found.
                    </div>
                  ) : (
                    <div className="divide-y divide-slate-900">
                      {suggestions.slice(0, 6).map((item, idx) => (
                        <button
                          key={`${item.resource_id}-${idx}`}
                          type="button"
                          onClick={() => handleSuggestionClick(item)}
                          className="w-full text-left px-4 py-2.5 hover:bg-slate-900 flex items-center justify-between text-xs transition-colors group"
                        >
                          <div className="flex items-center gap-2.5 min-w-0">
                            <div className="shrink-0 p-1.5 rounded-lg bg-slate-900 border border-slate-800/50">
                              {getServiceIcon(item.service, item.resource_type)}
                            </div>
                            <div className="truncate">
                              <span className="font-bold text-slate-200 group-hover:text-white">{item.name}</span>
                              <span className="text-[10px] text-slate-500 block uppercase font-bold tracking-wide">{item.resource_type}</span>
                            </div>
                          </div>

                          <span className={`px-2 py-0.5 text-[9px] font-bold rounded uppercase border shrink-0 ${getBadgeColors(item.service)}`}>
                            {item.service}
                          </span>
                        </button>
                      ))}
                      {suggestions.length > 6 && (
                        <button
                          type="submit"
                          className="w-full px-4 py-2 text-center text-[10px] uppercase font-bold text-amber-500 hover:bg-slate-900 border-t border-slate-900"
                        >
                          View all {suggestions.length} results
                        </button>
                      )}
                    </div>
                  )}
                </div>
              )}
            </form>
          </div>

          {/* Action utilities and controls */}
          <div className="flex items-center gap-3">
            
            {/* Region Switcher */}
            <div className="relative shrink-0" ref={regionDropdownRef} id="region-switcher-dropdown">
              <button
                onClick={() => setShowRegionDropdown(!showRegionDropdown)}
                className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/40 hover:bg-slate-800/80 border border-slate-800/80 rounded-xl text-xs font-mono font-medium text-slate-300 hover:text-white transition-colors animate-pulse-subtle"
                title="Switch AWS Region"
              >
                <Globe className="w-3.5 h-3.5 text-amber-500" />
                <span className="hidden sm:inline">🌍 {selectedRegion}</span>
                <span className="sm:hidden">🌍 {selectedRegion.substring(0, 5)}..</span>
                <ChevronDown className="w-3 h-3 text-slate-500" />
              </button>

              {showRegionDropdown && (
                <div className="absolute right-0 mt-2 w-48 bg-slate-950 border border-slate-800 rounded-xl shadow-2xl overflow-hidden z-50 font-mono text-xs">
                  <div className="px-3 py-2 border-b border-slate-900 bg-slate-900/40 text-slate-500 text-[10px] uppercase font-bold tracking-wider">
                    Select AWS Region
                  </div>
                  <div className="max-h-60 overflow-y-auto divide-y divide-slate-900">
                    {(regionDetails && regionDetails.length > 0 ? regionDetails : regions.map(r => ({ code: r, name: r }))).map((item) => (
                      <button
                        key={item.code}
                        onClick={() => {
                          changeRegion(item.code);
                          setShowRegionDropdown(false);
                        }}
                        className={`w-full text-left px-3.5 py-2 hover:bg-slate-900 flex items-center justify-between transition-colors ${
                          item.code === selectedRegion ? 'text-amber-500 font-semibold bg-slate-900/30' : 'text-slate-300 hover:text-white'
                        }`}
                      >
                        <div className="flex flex-col text-left">
                          <span className="font-semibold">{item.code}</span>
                          <span className="text-[10px] text-slate-500">{item.name}</span>
                        </div>
                        {item.code === selectedRegion && <span className="text-amber-500">●</span>}
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Notification Bell */}
            <NotificationBell isOpen={isNotificationsOpen} onToggle={() => setIsNotificationsOpen(!isNotificationsOpen)} />

            {/* Theme Toggle (UI only) */}
            <button 
              id="theme-toggle"
              onClick={onThemeToggle}
              className="p-2 rounded-xl bg-slate-800/40 border border-slate-800/80 text-slate-400 hover:text-slate-200 transition-colors"
              title="Toggle system theme"
            >
              {isDarkTheme ? <Moon className="w-4 h-4" /> : <Sun className="w-4 h-4" />}
            </button>

            {/* Connect AWS Action */}
            {awsState.connected ? (
              <button
                id="logout-aws-btn"
                onClick={disconnectAWSLocal}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-rose-600 to-rose-700 hover:from-rose-500 hover:to-rose-600 text-white font-bold text-xs uppercase tracking-wider rounded-xl transition-all duration-150 shadow-md shadow-rose-600/5"
              >
                Sign Out
              </button>
            ) : (
              <button
                id="connect-aws-btn"
                onClick={onConnectClick}
                className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl transition-all duration-150 shadow-md shadow-amber-500/5"
              >
                <Zap className="w-3.5 h-3.5 fill-current" />
                Connect AWS
              </button>
            )}
          </div>

        </div>

        {/* Compact Horizontal Account/Session details Row */}
        <div className="border-t border-slate-800/50 bg-slate-950/40 px-4 md:px-6 py-2 flex items-center justify-between text-[11px] font-mono text-slate-400 overflow-x-auto whitespace-nowrap scrollbar-none gap-6 select-none">
          <div className="flex items-center gap-6">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-bold uppercase">Account:</span>
              <span className="text-slate-200 font-bold">{awsState.connected ? awsState.accountId : '--'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-bold uppercase">Alias:</span>
              <span className="text-slate-200 font-bold">{awsState.connected ? 'Production' : '--'}</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-bold uppercase">User:</span>
              <span className="text-slate-200 font-bold truncate max-w-[120px]" title={awsState.userId}>
                {awsState.connected ? (awsState.userId?.split('/').pop() || awsState.userId) : '--'}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-bold uppercase">ARN:</span>
              <span className="text-slate-300 font-bold truncate max-w-[150px]" title={awsState.arn}>
                {awsState.connected ? awsState.arn : '--'}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-bold uppercase">Region:</span>
              <span className="text-amber-500 font-bold">{selectedRegion}</span>
            </div>
          </div>

          <div className="flex items-center gap-5">
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-bold uppercase">Backend:</span>
              <span className={`font-bold uppercase ${status === 'connected' ? 'text-emerald-400' : status === 'checking' ? 'text-amber-400' : 'text-rose-400'}`}>
                {status === 'connected' ? '🟢 ONLINE' : status === 'checking' ? 'Checking' : '🔴 OFFLINE'}
              </span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="text-slate-500 font-bold uppercase">AWS:</span>
              <span className={`font-bold uppercase ${awsState.connected ? 'text-emerald-400' : 'text-rose-400'}`}>
                {awsState.connected ? '🟢 CONNECTED' : '🔴 DISCONNECTED'}
              </span>
            </div>
          </div>
        </div>

      </header>
      <NotificationDrawer isOpen={isNotificationsOpen} onClose={() => setIsNotificationsOpen(false)} />
    </>
  );
}
