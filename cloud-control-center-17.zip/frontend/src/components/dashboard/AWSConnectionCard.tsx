import { useState } from 'react';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Cpu, 
  Globe, 
  User, 
  KeyRound, 
  Copy, 
  Check, 
  RefreshCw,
  LogOut
} from 'lucide-react';
import { useBackendStatus } from '../../api/BackendStatusContext';

interface AWSConnectionCardProps {
  onConnectClick?: () => void;
}

/**
 * AWSConnectionCard shows real-time credential validation context from STS.
 * Responsively renders connection parameter tags or action guides if disconnected.
 */
export default function AWSConnectionCard({ onConnectClick }: AWSConnectionCardProps) {
  const { awsState, triggerConnectAWS, disconnectAWSLocal } = useBackendStatus();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 1500);
  };

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden relative group">
      
      {/* Dynamic top gradient bar based on status */}
      <div className={`h-1.5 w-full ${
        awsState.connected ? 'bg-gradient-to-r from-emerald-500 to-teal-500' : 'bg-gradient-to-r from-slate-700 to-slate-800'
      }`}></div>

      <div className="p-6 space-y-6">
        
        {/* Header with status badges */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
              AWS Connection Status
            </span>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${
                awsState.connected ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'
              }`}></span>
              <h3 className="text-sm font-bold text-white font-mono uppercase">
                {awsState.connected ? '✅ AWS Connected' : '🔴 Disconnected'}
              </h3>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {awsState.connected ? (
              <button
                onClick={disconnectAWSLocal}
                className="px-3 py-1.5 bg-slate-800/60 hover:bg-slate-800 text-slate-400 hover:text-rose-400 rounded-lg text-xs font-semibold flex items-center gap-1.5 border border-slate-800 transition-all duration-200"
                title="Disconnect from AWS Profile Session"
              >
                <LogOut className="w-3.5 h-3.5" />
                Disconnect
              </button>
            ) : (
              <button
                onClick={onConnectClick || (() => { triggerConnectAWS(); })}
                disabled={awsState.checking}
                className="px-4 py-1.5 bg-amber-500 hover:bg-amber-400 disabled:bg-slate-800 text-slate-950 disabled:text-slate-500 font-bold text-xs uppercase tracking-wider rounded-lg flex items-center gap-1.5 transition-all"
              >
                {awsState.checking ? (
                  <>
                    <RefreshCw className="w-3.5 h-3.5 animate-spin" />
                    Connecting...
                  </>
                ) : (
                  <>
                    <KeyRound className="w-3.5 h-3.5" />
                    Verify Session
                  </>
                )}
              </button>
            )}
          </div>
        </div>

        {/* Credentials metrics details layout */}
        {awsState.connected ? (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Account ID Card info */}
            <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-4 flex items-start gap-3 relative group/card">
              <Cpu className="w-4.5 h-4.5 text-amber-500 shrink-0 mt-0.5" />
              <div className="space-y-1 min-w-0 flex-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                  Account Identifier
                </span>
                <span className="text-xs font-mono font-bold text-slate-300 break-all select-all block">
                  {awsState.accountId}
                </span>
              </div>
              <button
                onClick={() => handleCopy(awsState.accountId || '', 'account')}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors absolute top-2 right-2 opacity-0 group-hover/card:opacity-100"
                title="Copy Account ID"
              >
                {copiedField === 'account' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Region Card Info */}
            <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-4 flex items-start gap-3 relative group/card">
              <Globe className="w-4.5 h-4.5 text-sky-500 shrink-0 mt-0.5" />
              <div className="space-y-1 min-w-0 flex-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                  Resolved Region
                </span>
                <span className="text-xs font-mono font-bold text-slate-300 break-all block">
                  {awsState.region}
                </span>
              </div>
              <button
                onClick={() => handleCopy(awsState.region || '', 'region')}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors absolute top-2 right-2 opacity-0 group-hover/card:opacity-100"
                title="Copy Region"
              >
                {copiedField === 'region' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* User ID info */}
            <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-4 flex items-start gap-3 md:col-span-2 relative group/card">
              <User className="w-4.5 h-4.5 text-teal-500 shrink-0 mt-0.5" />
              <div className="space-y-1 min-w-0 flex-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                  IAM Identity User ID
                </span>
                <span className="text-xs font-mono font-bold text-slate-300 break-all select-all block">
                  {awsState.userId}
                </span>
              </div>
              <button
                onClick={() => handleCopy(awsState.userId || '', 'user')}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors absolute top-2 right-2 opacity-0 group-hover/card:opacity-100"
                title="Copy User ID"
              >
                {copiedField === 'user' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

            {/* Session ARN details */}
            <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-4 flex items-start gap-3 md:col-span-2 relative group/card">
              <ShieldCheck className="w-4.5 h-4.5 text-purple-500 shrink-0 mt-0.5" />
              <div className="space-y-1 min-w-0 flex-1">
                <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                  Caller Role Session ARN
                </span>
                <span className="text-xs font-mono font-bold text-slate-400 break-all select-all block">
                  {awsState.arn}
                </span>
              </div>
              <button
                onClick={() => handleCopy(awsState.arn || '', 'arn')}
                className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors absolute top-2 right-2 opacity-0 group-hover/card:opacity-100"
                title="Copy ARN"
              >
                {copiedField === 'arn' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              </button>
            </div>

          </div>
        ) : (
          <div className="bg-slate-950/40 border border-slate-800/40 rounded-xl p-6 flex flex-col items-center justify-center text-center space-y-4">
            
            <div className="w-10 h-10 rounded-xl bg-slate-900 flex items-center justify-center border border-slate-800/60">
              <ShieldAlert className="w-5 h-5 text-slate-500" />
            </div>

            <div className="space-y-1.5 max-w-sm">
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                No active session parameters found
              </h4>
              <p className="text-xs text-slate-500 leading-relaxed">
                Connect your workspace account parameters using the system configuration drawer to ingest STS caller identities.
              </p>
            </div>

            {awsState.error && (
              <div className="w-full bg-rose-500/5 border border-rose-500/15 p-4 rounded-xl text-left space-y-3">
                <h5 className="text-[11px] font-bold text-rose-400 uppercase tracking-wide font-mono flex items-center gap-1.5">
                  <ShieldAlert className="w-4 h-4 text-rose-500" />
                  Unable to connect to AWS
                </h5>
                <p className="text-xs text-rose-200/90 leading-relaxed">
                  {awsState.error}
                </p>
                <div className="space-y-1 bg-slate-950 p-3 rounded-lg border border-rose-900/20">
                  <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider block">
                    Troubleshooting CLI Command:
                  </span>
                  <code className="text-xs font-mono text-teal-300 block select-all">
                    aws configure
                  </code>
                </div>
                <p className="text-[10px] text-slate-500 leading-relaxed">
                  Configure your standard profile credentials using the terminal interface, then restart the backend environment process to refresh cache contexts.
                </p>
              </div>
            )}

          </div>
        )}

      </div>
    </div>
  );
}
