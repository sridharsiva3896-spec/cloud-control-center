import { useState } from 'react';
import { useAWSSession } from '../../hooks/useAWSSession';
import { 
  ShieldCheck, 
  ShieldAlert, 
  Cpu, 
  Globe, 
  User, 
  KeyRound, 
  Copy, 
  Check, 
  RefreshCw,
  Terminal
} from 'lucide-react';

interface AWSSessionCardProps {
  onRefresh?: () => Promise<void>;
  isRefreshingGlobal?: boolean;
}

/**
 * AWSSessionCard component
 * Renders the state of the boto3 AWS Session and verified STS identity.
 */
export default function AWSSessionCard({ onRefresh, isRefreshingGlobal = false }: AWSSessionCardProps) {
  const { session, loading, error, refetch } = useAWSSession();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 1500);
  };

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden relative group shadow-xl">
      
      {/* Dynamic top gradient bar based on connectivity status */}
      <div className={`h-1.5 w-full transition-all duration-300 ${
        loading 
          ? 'bg-gradient-to-r from-slate-600 to-slate-500 animate-pulse' 
          : session?.connected 
            ? 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-400' 
            : 'bg-gradient-to-r from-rose-500 to-amber-600'
      }`}></div>

      <div className="p-6 space-y-6">
        
        {/* Header Section */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
              AWS Infrastructure Session
            </span>
            <div className="flex items-center gap-2">
              <span className={`w-2.5 h-2.5 rounded-full ${
                loading 
                  ? 'bg-slate-500 animate-pulse' 
                  : session?.connected 
                    ? 'bg-emerald-500 animate-pulse' 
                    : 'bg-rose-500'
              }`}></span>
              <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wide">
                {loading 
                  ? 'Checking AWS Session...' 
                  : session?.connected 
                    ? 'Connected' 
                    : 'AWS Not Connected'}
              </h3>
            </div>
          </div>

          <div>
            <button
              onClick={async () => {
                if (onRefresh) {
                  await onRefresh();
                } else {
                  await refetch(true);
                }
              }}
              disabled={loading || isRefreshingGlobal}
              className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-200 hover:text-white font-mono font-bold text-xs uppercase tracking-wider rounded-xl border border-slate-700/80 flex items-center gap-1.5 transition-all"
            >
              <RefreshCw className={`w-3.5 h-3.5 ${(loading || isRefreshingGlobal) ? 'animate-spin' : ''}`} />
              Refresh State
            </button>
          </div>
        </div>

        {/* Loading Skeleton Panel */}
        {loading && (
          <div className="space-y-4 animate-pulse">
            <div className="h-16 bg-slate-900/60 rounded-xl border border-slate-800/50"></div>
            <div className="h-16 bg-slate-900/60 rounded-xl border border-slate-800/50"></div>
          </div>
        )}

        {/* Connected state display */}
        {!loading && session?.connected && (
          <div className="space-y-4">
            
            {/* Quick success callout */}
            <div className="bg-emerald-500/10 border border-emerald-500/15 p-4 rounded-xl flex items-center gap-3">
              <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0" />
              <p className="text-xs text-emerald-200/90 font-medium leading-relaxed">
                AWS Credentials Session active. Caller identity confirmed through secure STS verification.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              
              {/* Account ID Card */}
              <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 flex items-start justify-between gap-3 relative group/item">
                <div className="flex items-start gap-3 min-w-0">
                  <Cpu className="w-4.5 h-4.5 text-amber-500 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 min-w-0">
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                      AWS Account ID
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-200 select-all truncate block">
                      {session.account_id}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(session.account_id || '', 'accountId')}
                  className="p-1 rounded-lg text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                  title="Copy Account ID"
                >
                  {copiedField === 'accountId' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* Resolved Region Card */}
              <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 flex items-start justify-between gap-3 relative group/item">
                <div className="flex items-start gap-3 min-w-0">
                  <Globe className="w-4.5 h-4.5 text-sky-500 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 min-w-0">
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                      AWS Region
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-200 truncate block">
                      {session.region}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(session.region || '', 'region')}
                  className="p-1 rounded-lg text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                  title="Copy Region"
                >
                  {copiedField === 'region' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* User ID Card */}
              <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 flex items-start justify-between gap-3 md:col-span-2 relative group/item">
                <div className="flex items-start gap-3 min-w-0">
                  <User className="w-4.5 h-4.5 text-teal-400 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 min-w-0">
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                      IAM User ID
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-200 select-all truncate block">
                      {session.user_id}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(session.user_id || '', 'userId')}
                  className="p-1 rounded-lg text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                  title="Copy User ID"
                >
                  {copiedField === 'userId' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

              {/* Role ARN Card */}
              <div className="bg-slate-950/40 border border-slate-800/60 rounded-xl p-4 flex items-start justify-between gap-3 md:col-span-2 relative group/item">
                <div className="flex items-start gap-3 min-w-0">
                  <KeyRound className="w-4.5 h-4.5 text-purple-400 shrink-0 mt-0.5" />
                  <div className="space-y-0.5 min-w-0">
                    <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono block">
                      Caller Identity ARN
                    </span>
                    <span className="text-xs font-mono font-bold text-slate-300 select-all break-all block">
                      {session.arn}
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => handleCopy(session.arn || '', 'arn')}
                  className="p-1 rounded-lg text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                  title="Copy Role ARN"
                >
                  {copiedField === 'arn' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                </button>
              </div>

            </div>
          </div>
        )}

        {/* Disconnected or error display */}
        {!loading && !session?.connected && (
          <div className="space-y-4">
            
            {/* Warning Callout */}
            <div className="bg-rose-500/10 border border-rose-500/15 p-4 rounded-xl flex items-start gap-3">
              <ShieldAlert className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-rose-300 uppercase tracking-wide font-mono">
                  Credential Handshake Offline
                </h4>
                <p className="text-xs text-rose-200/80 leading-relaxed">
                  {error || 'No active AWS credentials could be resolved on the backend host.'}
                </p>
              </div>
            </div>

            {/* Step-by-step CLI command walkthrough */}
            <div className="bg-slate-950/60 border border-slate-800/80 rounded-xl p-5 space-y-4">
              <div className="flex items-center gap-2 text-slate-400 border-b border-slate-900 pb-2">
                <Terminal className="w-4.5 h-4.5 text-slate-500" />
                <span className="text-[11px] font-mono uppercase tracking-wide font-bold">
                  Quick AWS CLI Configuration Setup
                </span>
              </div>

              <div className="space-y-3.5 text-xs text-slate-400">
                <p className="leading-relaxed">
                  The application boto3 backend automatically reads standard configurations from your profile. Configure your credentials using the terminal:
                </p>

                <div className="space-y-2">
                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-900 font-mono text-[11px] text-teal-300 flex justify-between items-center group/code">
                    <span>$ aws configure</span>
                    <button
                      onClick={() => handleCopy('aws configure', 'cliConfigure')}
                      className="text-slate-600 hover:text-slate-400 transition"
                      title="Copy standard CLI command"
                    >
                      {copiedField === 'cliConfigure' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                  <div className="bg-slate-950 p-3 rounded-lg border border-slate-900 font-mono text-[11px] text-teal-300 flex justify-between items-center group/code">
                    <span>$ aws sts get-caller-identity</span>
                    <button
                      onClick={() => handleCopy('aws sts get-caller-identity', 'cliSts')}
                      className="text-slate-600 hover:text-slate-400 transition"
                      title="Verify STS credentials"
                    >
                      {copiedField === 'cliSts' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                    </button>
                  </div>
                </div>

                <div className="text-[11px] text-slate-500 italic flex items-center gap-1">
                  <span>After running configuration commands, please restart the backend service.</span>
                </div>
              </div>
            </div>

          </div>
        )}

      </div>
    </div>
  );
}
