import { LucideIcon, ArrowUpRight } from 'lucide-react';

interface DashboardCardProps {
  title: string;
  icon: LucideIcon;
  value?: string;
  label?: string;
  statusText?: string;
  colorClass?: string;
  badge?: string;
}

/**
 * DashboardCard represents an executive status tile for a specific AWS resource.
 * Employs custom gradients, indicators, and labels.
 */
export default function DashboardCard({
  title,
  icon: Icon,
  value = '--',
  label = 'Not Synced',
  statusText = 'No active connection',
  colorClass = 'text-amber-500 bg-amber-500/10 border-amber-500/15',
  badge
}: DashboardCardProps) {
  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/80 transition-all duration-200 flex flex-col justify-between h-[175px] group relative overflow-hidden">
      
      {/* Subtle hover gradient */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-slate-800/20 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>

      <div>
        <div className="flex items-center justify-between mb-2.5">
          <div className="flex items-center gap-2">
            <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
              {title}
            </span>
            {badge && (
              <span className="px-1.5 py-0.5 rounded bg-amber-500/15 text-amber-400 border border-amber-500/20 text-[8px] font-mono font-bold uppercase tracking-wider">
                {badge}
              </span>
            )}
          </div>
          <div className={`w-9 h-9 rounded-xl ${colorClass} flex items-center justify-center border`}>
            <Icon className="w-4 h-4" />
          </div>
        </div>

        {/* Large Metric Display with proper placeholders */}
        <div className="space-y-0.5">
          <h2 className="text-3xl font-black text-white font-mono leading-none tracking-tight">
            {value}
          </h2>
          <p className="text-[11px] text-slate-400 font-medium">
            {label}
          </p>
        </div>
      </div>

      <div className="border-t border-slate-800/60 mt-3.5 pt-3 flex items-center justify-between text-[10px] font-mono text-slate-500">
        <span className="flex items-center gap-1.5">
          <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
          {statusText}
        </span>
        <ArrowUpRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 group-hover:text-slate-400 transition-all duration-200" />
      </div>

    </div>
  );
}
