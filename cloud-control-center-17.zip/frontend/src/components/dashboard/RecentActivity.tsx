import { useCloudTrail } from '../../hooks/useCloudTrail';
import { 
  Terminal, 
  AlertTriangle,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { motion } from 'motion/react';
import { useState, useEffect } from 'react';

/**
 * RecentActivity shows a highly compact list of the latest 5 management plane events 
 * retrieved from AWS CloudTrail, styled exactly like the other overview widgets.
 */
export default function RecentActivity() {
  const { data, loading, error, refetch } = useCloudTrail();

  const events = data?.events || [];
  const isEnabled = data?.enabled ?? true;

  // Get the latest 5 events
  const latestEvents = events.slice(0, 5);

  const [lastUpdated, setLastUpdated] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );

  useEffect(() => {
    if (data) {
      setLastUpdated(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
    }
  }, [data]);

  const formatEventTime = (timeStr: string) => {
    if (!timeStr || timeStr === 'N/A') return '--:--';
    const d = new Date(timeStr);
    return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/80 hover:shadow-xl hover:shadow-slate-950/30 transition-all duration-300 flex flex-col justify-between h-auto min-h-[300px] group relative overflow-hidden focus-within:ring-2 focus-within:ring-amber-500/50"
    >
      {/* Subtle hover gradient */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-slate-800/20 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>

      {/* Header section */}
      <div className="border-b border-slate-800/60 pb-3 mb-4 shrink-0">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <div className="p-1.5 bg-slate-950 rounded-lg border border-slate-800/50 text-rose-500 shrink-0">
              <Terminal className="w-4 h-4" />
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                Recent Activity
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">Latest management plane audit logs</p>
            </div>
          </div>
          <Link 
            to="/cloudtrail" 
            className="text-[10px] font-mono font-bold text-amber-500 hover:text-amber-400 flex items-center gap-1 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded px-1 py-0.5"
            aria-label="View all Recent Activity"
          >
            <span>View All →</span>
          </Link>
        </div>
      </div>

      {/* Content Area */}
      <div className="flex-1 min-h-0 flex flex-col justify-center">
        {loading ? (
          /* Skeleton Loading State */
          <div className="space-y-3.5 animate-pulse w-full">
            {[1, 2, 3, 4, 5].map((i) => (
              <div key={i} className="h-6 bg-slate-900/50 rounded-lg border border-slate-800/10"></div>
            ))}
          </div>
        ) : error || !isEnabled ? (
          /* Error or Service Disabled State */
          <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/10 text-rose-300 text-xs flex flex-col justify-center items-center h-full text-center space-y-2">
            <div className="p-2 bg-rose-500/10 border border-rose-500/20 rounded-lg">
              <AlertTriangle className="w-4 h-4 text-rose-400" />
            </div>
            <div>
              <h5 className="font-bold uppercase tracking-wider font-mono text-[10px] text-slate-200">
                CloudTrail Error
              </h5>
              <p className="text-slate-500 text-[10px] mt-0.5 max-w-xs leading-relaxed font-mono">
                {error || "Audit logs are currently unavailable."}
              </p>
            </div>
            <button 
              onClick={refetch} 
              className="px-2.5 py-1 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-rose-400 font-bold font-mono text-[9px] rounded uppercase tracking-wider transition-all mt-1 focus:outline-none focus:ring-1 focus:ring-rose-500"
            >
              Retry
            </button>
          </div>
        ) : events.length === 0 ? (
          /* Empty State */
          <div className="flex flex-col items-center justify-center text-center py-4 px-2 h-full">
            <div className="p-2 bg-slate-900/40 rounded-lg border border-slate-800/40 mb-2">
              <Terminal className="w-4 h-4 text-slate-500" />
            </div>
            <p className="text-[11px] text-slate-400 font-mono mb-1.5">No resources found.</p>
            <Link 
              to="/cloudtrail" 
              className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-amber-500 hover:text-amber-400 transition"
            >
              <span>View Monitoring</span>
              <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
        ) : (
          /* Real Compact Table Data */
          <div className="w-full h-full overflow-hidden flex flex-col justify-center select-none mt-1">
            <div className="overflow-x-auto scrollbar-none">
              <table className="w-full text-left border-collapse">
                <thead>
                  <tr className="border-b border-slate-800/60 text-[9px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                    <th className="pb-2 font-mono w-[15%]">Time</th>
                    <th className="pb-2 font-mono w-[15%]">Service</th>
                    <th className="pb-2 font-mono w-[45%]">Event</th>
                    <th className="pb-2 font-mono w-[25%]">User</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/40 font-mono text-[10.5px]">
                  {latestEvents.map((item) => {
                    const time = formatEventTime(item.event_time);
                    const service = (item.event_source || '').split('.')[0].toUpperCase();
                    const eventName = item.event_name;
                    const username = item.username;
                    return (
                      <tr key={item.event_id} className="hover:bg-slate-900/20 transition-colors">
                        <td className="py-3.5 text-slate-400 whitespace-nowrap">{time}</td>
                        <td className="py-3.5">
                          <span className="px-1.5 py-0.5 rounded text-[8px] font-bold bg-slate-950 border border-slate-900 text-amber-500">
                            {service}
                          </span>
                        </td>
                        <td className="py-3.5 text-white font-semibold truncate" title={eventName}>
                          {eventName}
                        </td>
                        <td className="py-3.5 text-slate-300 truncate" title={username}>
                          {username}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>

      {/* Footer Section */}
      <div className="border-t border-slate-800/60 mt-4 pt-3 flex items-center justify-between text-[10px] font-mono text-slate-500 shrink-0">
        <span className="flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${loading ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`}></span>
          <span>Last Updated: {lastUpdated}</span>
        </span>
        <span className="text-slate-600">Sync Status</span>
      </div>
    </motion.div>
  );
}
