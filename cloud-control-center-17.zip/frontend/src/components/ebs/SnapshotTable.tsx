import { useState, useMemo } from 'react';
import { Search, Filter, Copy, Check, Camera, BarChart } from 'lucide-react';
import { EBSSnapshot } from '../../types/ebs';

interface SnapshotTableProps {
  snapshots: EBSSnapshot[];
  loading: boolean;
}

export default function SnapshotTable({ snapshots, loading }: SnapshotTableProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedState, setSelectedState] = useState('All');
  const [selectedTier, setSelectedTier] = useState('All');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(`${label}_${text}`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Dynamic state list
  const statesList = useMemo(() => {
    const list = new Set<string>();
    snapshots.forEach(s => {
      if (s.state && s.state !== 'N/A') {
        list.add(s.state);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [snapshots]);

  // Dynamic tiers list
  const tiersList = useMemo(() => {
    const list = new Set<string>();
    snapshots.forEach(s => {
      if (s.storage_tier && s.storage_tier !== 'N/A') {
        list.add(s.storage_tier);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [snapshots]);

  // Filtered snapshots
  const filteredSnapshots = useMemo(() => {
    return snapshots.filter(s => {
      const matchesSearch = 
        s.snapshot_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        s.volume_id.toLowerCase().includes(searchQuery.toLowerCase());

      const matchesState = selectedState === 'All' || s.state === selectedState;
      const matchesTier = selectedTier === 'All' || s.storage_tier === selectedTier;

      return matchesSearch && matchesState && matchesTier;
    });
  }, [snapshots, searchQuery, selectedState, selectedTier]);

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-purple-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Retrieving EBS snapshots registry...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      
      {/* Search & Filter Controls */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4 font-mono">
        
        {/* Search Input */}
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search by Snapshot ID or Volume ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#121829] border border-slate-800 focus:border-slate-700/80 rounded-xl py-2 pl-10 pr-4 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
          />
        </div>

        {/* Filters Selection Grid */}
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          
          {/* State Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              State:
            </span>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {statesList.map(st => (
                <option key={st} value={st} className="bg-[#121829] text-slate-200">
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Tier Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <BarChart className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Tier:
            </span>
            <select
              value={selectedTier}
              onChange={(e) => setSelectedTier(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {tiersList.map(tr => (
                <option key={tr} value={tr} className="bg-[#121829] text-slate-200">
                  {tr}
                </option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Main Snapshots Table Card */}
      {filteredSnapshots.length === 0 ? (
        <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500 font-mono font-bold">
          <Camera className="w-10 h-10 text-slate-600 stroke-[1.5]" />
          <div className="flex flex-col gap-1">
            <p className="text-xs text-slate-400 font-bold">No EBS Snapshots Found</p>
            <p className="text-[11px] text-slate-500 font-medium">
              No point-in-time snapshots match your active filters or search terms.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/20">
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Snapshot ID</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Source Volume ID</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">State</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Progress</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Storage Tier</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Start Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                {filteredSnapshots.map((snap) => {
                  const isIdCopied = copiedText === `snap_${snap.snapshot_id}`;
                  const isVolCopied = copiedText === `vol_${snap.volume_id}`;
                  const isCompleted = snap.state.toLowerCase() === 'completed';

                  return (
                    <tr key={snap.snapshot_id} className="hover:bg-slate-800/20 transition-colors">
                      
                      {/* Snapshot ID */}
                      <td className="p-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-100 font-bold select-all truncate max-w-[150px]" title={snap.snapshot_id}>
                            {snap.snapshot_id}
                          </span>
                          <button
                            onClick={() => copyToClipboard(snap.snapshot_id, 'snap')}
                            className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                            title="Copy Snapshot ID"
                          >
                            {isIdCopied ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Source Volume ID */}
                      <td className="p-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-300 select-all truncate max-w-[150px]" title={snap.volume_id}>
                            {snap.volume_id}
                          </span>
                          <button
                            onClick={() => copyToClipboard(snap.volume_id, 'vol')}
                            className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                            title="Copy Volume ID"
                          >
                            {isVolCopied ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* State */}
                      <td className="p-4 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                          isCompleted
                            ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/15'
                            : 'bg-amber-500/5 text-amber-400 border-amber-500/15'
                        }`}>
                          <span className={`w-1 h-1 rounded-full ${isCompleted ? 'bg-emerald-400' : 'bg-amber-400'}`} />
                          {snap.state}
                        </span>
                      </td>

                      {/* Progress */}
                      <td className="p-4 whitespace-nowrap text-slate-200">
                        <div className="flex items-center gap-2">
                          <div className="w-16 bg-slate-800 h-1.5 rounded-full overflow-hidden">
                            <div 
                              className="bg-purple-500 h-full rounded-full" 
                              style={{ width: snap.progress.includes('%') ? snap.progress : `${snap.progress}%` }}
                            />
                          </div>
                          <span className="text-[11px] font-semibold text-slate-300">{snap.progress}</span>
                        </div>
                      </td>

                      {/* Storage Tier */}
                      <td className="p-4 whitespace-nowrap">
                        <span className="inline-flex px-1.5 py-0.5 rounded text-[10px] font-semibold bg-slate-900 border border-slate-800 text-slate-400 uppercase">
                          {snap.storage_tier}
                        </span>
                      </td>

                      {/* Start Time */}
                      <td className="p-4 whitespace-nowrap text-slate-500 text-[11px]">
                        {snap.start_time !== 'N/A' 
                          ? new Date(snap.start_time).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })
                          : 'N/A'
                        }
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
