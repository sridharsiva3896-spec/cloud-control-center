import { HardDrive, Camera, CheckCircle2, Lock } from 'lucide-react';
import { EBSSummary } from '../../types/ebs';

interface SummaryCardsProps {
  summary?: EBSSummary;
  loading: boolean;
}

export default function SummaryCards({ summary, loading }: SummaryCardsProps) {
  const stats = [
    {
      title: 'Total Volumes',
      value: summary?.volumes ?? 0,
      icon: HardDrive,
      color: 'text-blue-400 bg-blue-500/10 border-blue-500/15',
      desc: 'All provisioned block storage units'
    },
    {
      title: 'Available Volumes',
      value: summary?.available ?? 0,
      icon: CheckCircle2,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15',
      desc: 'Storage units unattached and ready'
    },
    {
      title: 'Active Snapshots',
      value: summary?.snapshots ?? 0,
      icon: Camera,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/15',
      desc: 'Point-in-time backup snapshots'
    },
    {
      title: 'Encrypted Volumes',
      value: summary?.encrypted ?? 0,
      icon: Lock,
      color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/15',
      desc: 'Volumes secured with AWS KMS encryption'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <div
            key={idx}
            className={`border rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 shadow-lg ${
              loading 
                ? 'bg-slate-900/40 border-slate-800/60 animate-pulse' 
                : 'bg-[#0f1422] border-slate-800/80 hover:border-slate-700/80'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono font-medium tracking-wide text-slate-400 uppercase">
                {stat.title}
              </span>
              <div className={`p-2 rounded-lg border ${stat.color}`}>
                <Icon className="w-4 h-4 stroke-[2]" />
              </div>
            </div>
            
            <div>
              <div className="text-3xl font-mono font-bold text-white tracking-tight mb-1">
                {loading ? '...' : stat.value.toLocaleString()}
              </div>
              <p className="text-xs text-slate-400 font-sans leading-tight">
                {stat.desc}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
