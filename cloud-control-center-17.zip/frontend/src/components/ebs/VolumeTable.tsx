import { useState, useMemo } from 'react';
import { Search, Filter, Copy, Check, HardDrive, Globe, Shield } from 'lucide-react';
import { EBSVolume } from '../../types/ebs';

interface VolumeTableProps {
  volumes: EBSVolume[];
  loading: boolean;
}

export default function VolumeTable({ volumes, loading }: VolumeTableProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedState, setSelectedState] = useState('All');
  const [selectedType, setSelectedType] = useState('All');
  const [selectedEncrypted, setSelectedEncrypted] = useState('All');
  const [selectedAZ, setSelectedAZ] = useState('All');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(`${label}_${text}`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Dynamic filter list for States
  const statesList = useMemo(() => {
    const list = new Set<string>();
    volumes.forEach(v => {
      if (v.state && v.state !== 'N/A') {
        list.add(v.state);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [volumes]);

  // Dynamic filter list for Volume Types
  const typesList = useMemo(() => {
    const list = new Set<string>();
    volumes.forEach(v => {
      if (v.volume_type && v.volume_type !== 'N/A') {
        list.add(v.volume_type);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [volumes]);

  // Dynamic filter list for AZs
  const azsList = useMemo(() => {
    const list = new Set<string>();
    volumes.forEach(v => {
      if (v.az && v.az !== 'N/A') {
        list.add(v.az);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [volumes]);

  // Filter volumes locally
  const filteredVolumes = useMemo(() => {
    return volumes.filter(v => {
      const matchesSearch = 
        v.volume_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        v.attached_instance_id.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesState = selectedState === 'All' || v.state === selectedState;
      const matchesType = selectedType === 'All' || v.volume_type === selectedType;
      const matchesAZ = selectedAZ === 'All' || v.az === selectedAZ;
      
      let matchesEncrypted = true;
      if (selectedEncrypted === 'Yes') matchesEncrypted = v.encrypted === true;
      if (selectedEncrypted === 'No') matchesEncrypted = v.encrypted === false;

      return matchesSearch && matchesState && matchesType && matchesAZ && matchesEncrypted;
    });
  }, [volumes, searchQuery, selectedState, selectedType, selectedAZ, selectedEncrypted]);

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Retrieving EBS storage volumes inventory...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      
      {/* Search & Filter Controls */}
      <div className="flex flex-col xl:flex-row gap-4 justify-between items-start xl:items-center bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4 font-mono">
        
        {/* Search Input */}
        <div className="relative w-full xl:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search by Volume ID or Instance ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#121829] border border-slate-800 focus:border-slate-700/80 rounded-xl py-2 pl-10 pr-4 text-xs text-white placeholder-slate-500 focus:outline-none transition-all"
          />
        </div>

        {/* Multi Filters Selection Grid */}
        <div className="flex flex-wrap gap-3 w-full xl:w-auto">
          
          {/* State Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              State:
            </span>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {statesList.map(st => (
                <option key={st} value={st} className="bg-[#121829] text-slate-200">
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Volume Type Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Type:
            </span>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {typesList.map(ty => (
                <option key={ty} value={ty} className="bg-[#121829] text-slate-200">
                  {ty}
                </option>
              ))}
            </select>
          </div>

          {/* Encrypted Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Shield className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Encrypted:
            </span>
            <select
              value={selectedEncrypted}
              onChange={(e) => setSelectedEncrypted(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              <option value="All" className="bg-[#121829] text-slate-200">All</option>
              <option value="Yes" className="bg-[#121829] text-slate-200">Yes</option>
              <option value="No" className="bg-[#121829] text-slate-200">No</option>
            </select>
          </div>

          {/* Availability Zone Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider">
              Zone:
            </span>
            <select
              value={selectedAZ}
              onChange={(e) => setSelectedAZ(e.target.value)}
              className="bg-transparent text-xs font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {azsList.map(az => (
                <option key={az} value={az} className="bg-[#121829] text-slate-200">
                  {az}
                </option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Main Volumes Table Card */}
      {filteredVolumes.length === 0 ? (
        <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500 font-mono">
          <HardDrive className="w-10 h-10 text-slate-600 stroke-[1.5]" />
          <div className="flex flex-col gap-1">
            <p className="text-xs font-bold text-slate-400">No EBS Volumes Found</p>
            <p className="text-[11px] text-slate-500">
              No block storage volumes match your active filters or search terms.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/20">
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">Volume ID</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">Size / Type</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">State</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">Performance (IOPS/Mbps)</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">Encrypted</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">Availability Zone</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">Attached Resource</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-mono">Create Time</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                {filteredVolumes.map((vol) => {
                  const isIdCopied = copiedText === `vol_${vol.volume_id}`;
                  const isInstCopied = copiedText === `inst_${vol.attached_instance_id}`;
                  const isAttached = vol.state.toLowerCase() === 'in-use';

                  return (
                    <tr key={vol.volume_id} className="hover:bg-slate-800/20 transition-colors">
                      
                      {/* Volume ID */}
                      <td className="p-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-100 font-bold select-all truncate max-w-[150px]" title={vol.volume_id}>
                            {vol.volume_id}
                          </span>
                          <button
                            onClick={() => copyToClipboard(vol.volume_id, 'vol')}
                            className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                            title="Copy Volume ID"
                          >
                            {isIdCopied ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Size & Type */}
                      <td className="p-4 whitespace-nowrap">
                        <div className="flex flex-col gap-0.5">
                          <span className="text-slate-200 font-bold">
                            {vol.size} GiB
                          </span>
                          <span className="text-[10px] text-slate-500 uppercase font-semibold">{vol.volume_type}</span>
                        </div>
                      </td>

                      {/* State */}
                      <td className="p-4 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[10px] font-bold uppercase border ${
                          isAttached
                            ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/15'
                            : 'bg-rose-500/5 text-rose-400 border-rose-500/15'
                        }`}>
                          <span className={`w-1 h-1 rounded-full ${isAttached ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                          {vol.state}
                        </span>
                      </td>

                      {/* Performance (IOPS/Throughput) */}
                      <td className="p-4 whitespace-nowrap text-slate-300">
                        <div className="flex flex-col gap-0.5">
                          <span className="font-semibold">{vol.iops ? `${vol.iops} IOPS` : 'N/A'}</span>
                          {vol.throughput ? (
                            <span className="text-[10px] text-slate-500">{vol.throughput} MiB/s</span>
                          ) : null}
                        </div>
                      </td>

                      {/* Encrypted */}
                      <td className="p-4 whitespace-nowrap">
                        <span className={`inline-flex px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase ${
                          vol.encrypted 
                            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/15 font-bold' 
                            : 'bg-slate-950/40 border border-slate-800 text-slate-500'
                        }`}>
                          {vol.encrypted ? 'Encrypted' : 'Plain'}
                        </span>
                      </td>

                      {/* Availability Zone */}
                      <td className="p-4 whitespace-nowrap text-slate-400 text-[11px]">
                        {vol.az}
                      </td>

                      {/* Attached Resource (Instance ID & Device Name) */}
                      <td className="p-4 whitespace-nowrap text-slate-400 max-w-xs">
                        {vol.attached_instance_id && vol.attached_instance_id !== 'N/A' ? (
                          <div className="flex flex-col gap-0.5">
                            <div className="flex items-center gap-1.5">
                              <span className="font-bold text-slate-200 select-all max-w-[140px] truncate" title={vol.attached_instance_id}>
                                {vol.attached_instance_id}
                              </span>
                              <button
                                onClick={() => copyToClipboard(vol.attached_instance_id, 'inst')}
                                className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                                title="Copy Instance ID"
                              >
                                {isInstCopied ? (
                                  <Check className="w-3 h-3 text-emerald-400" />
                                ) : (
                                  <Copy className="w-3 h-3" />
                                )}
                              </button>
                            </div>
                            <span className="text-[10px] text-slate-500 font-semibold uppercase">Mount: {vol.device_name}</span>
                          </div>
                        ) : (
                          <span className="text-slate-500 italic">Unattached</span>
                        )}
                      </td>

                      {/* Create Time */}
                      <td className="p-4 whitespace-nowrap text-slate-500 text-[11px]">
                        {vol.create_time !== 'N/A' 
                          ? new Date(vol.create_time).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })
                          : 'N/A'
                        }
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
