import { useState, useMemo } from 'react';
import { Search, Filter, Copy, Check, Zap } from 'lucide-react';
import { LambdaFunction } from '../../types/lambda';

interface FunctionTableProps {
  functions: LambdaFunction[];
  loading: boolean;
}

export default function FunctionTable({ functions, loading }: FunctionTableProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedRuntime, setSelectedRuntime] = useState('All');
  const [selectedState, setSelectedState] = useState('All');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(`${label}_${text}`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Dynamic filter lists
  const runtimes = useMemo(() => {
    const list = new Set<string>();
    functions.forEach(fn => {
      if (fn.runtime && fn.runtime !== 'N/A') {
        list.add(fn.runtime);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [functions]);

  const states = useMemo(() => {
    const list = new Set<string>();
    functions.forEach(fn => {
      if (fn.state && fn.state !== 'N/A') {
        list.add(fn.state);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [functions]);

  // Filter functions
  const filteredFunctions = useMemo(() => {
    return functions.filter(fn => {
      const matchesSearch = 
        fn.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        fn.runtime.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesRuntime = selectedRuntime === 'All' || fn.runtime === selectedRuntime;
      const matchesState = selectedState === 'All' || fn.state === selectedState;

      return matchesSearch && matchesRuntime && matchesState;
    });
  }, [functions, searchQuery, selectedRuntime, selectedState]);

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-orange-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Retrieving AWS Lambda functions...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Search & Filter Controls */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4">
        
        {/* Search */}
        <div className="relative w-full md:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search by Function Name or Runtime..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#121829] border border-slate-800 focus:border-slate-700/80 rounded-xl py-2 pl-10 pr-4 text-xs font-mono text-white placeholder-slate-500 focus:outline-none transition-all"
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap gap-3 w-full md:w-auto">
          
          {/* Runtime Dropdown */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
              Runtime:
            </span>
            <select
              value={selectedRuntime}
              onChange={(e) => setSelectedRuntime(e.target.value)}
              className="bg-transparent text-xs font-mono font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {runtimes.map(rt => (
                <option key={rt} value={rt} className="bg-[#121829] text-slate-200">
                  {rt}
                </option>
              ))}
            </select>
          </div>

          {/* State Dropdown */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
              State:
            </span>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="bg-transparent text-xs font-mono font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {states.map(st => (
                <option key={st} value={st} className="bg-[#121829] text-slate-200">
                  {st}
                </option>
              ))}
            </select>
          </div>

        </div>
      </div>

      {/* Main Table Card */}
      {filteredFunctions.length === 0 ? (
        <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
          <Zap className="w-10 h-10 text-slate-600 stroke-[1.5]" />
          <div className="flex flex-col gap-1">
            <p className="text-xs font-mono font-bold text-slate-400">No Functions Found</p>
            <p className="text-[11px] text-slate-500">
              No serverless lambda functions found matching the active query or filter in this region.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/20">
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Function Name</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Runtime</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">State</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Memory / Timeout</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Concurrency</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Architecture</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Handler / Package</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Last Modified</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                {filteredFunctions.map((fn) => {
                  const isCopied = copiedText === `name_${fn.name}`;
                  
                  return (
                    <tr key={fn.name} className="hover:bg-slate-800/20 transition-colors">
                      {/* Name */}
                      <td className="p-4 max-w-xs">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-100 font-bold select-all truncate" title={fn.name}>
                            {fn.name}
                          </span>
                          <button
                            onClick={() => copyToClipboard(fn.name, 'name')}
                            className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                            title="Copy Name"
                          >
                            {isCopied ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Runtime */}
                      <td className="p-4 whitespace-nowrap text-slate-300">
                        <span className="bg-slate-950/40 border border-slate-800/40 px-2 py-0.5 rounded text-[11px] font-semibold text-slate-300">
                          {fn.runtime}
                        </span>
                      </td>

                      {/* State */}
                      <td className="p-4 whitespace-nowrap">
                        <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
                          fn.state === 'Active'
                            ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                            : fn.state === 'Failed'
                            ? 'bg-rose-500/5 text-rose-400 border-rose-500/10'
                            : 'bg-amber-500/5 text-amber-400 border-amber-500/10'
                        }`}>
                          {fn.state}
                        </span>
                      </td>

                      {/* Memory & Timeout */}
                      <td className="p-4 whitespace-nowrap text-slate-300">
                        <div className="flex flex-col gap-0.5">
                          <span>{fn.memory_size} MB</span>
                          <span className="text-[10px] text-slate-500">Timeout: {fn.timeout}s</span>
                        </div>
                      </td>

                      {/* Concurrency */}
                      <td className="p-4 whitespace-nowrap text-slate-300">
                        {fn.concurrency !== undefined && fn.concurrency !== null ? (
                          <span className="text-emerald-400 font-bold">{fn.concurrency}</span>
                        ) : (
                          <span className="text-slate-500 font-medium">Unreserved</span>
                        )}
                      </td>

                      {/* Architecture */}
                      <td className="p-4 whitespace-nowrap">
                        <span className="px-1.5 py-0.5 rounded bg-blue-500/10 text-blue-400 border border-blue-500/15 text-[10px] font-semibold uppercase">
                          {fn.architecture}
                        </span>
                      </td>

                      {/* Handler & Package */}
                      <td className="p-4 max-w-xs text-slate-400">
                        <div className="flex flex-col gap-0.5">
                          <span className="truncate select-all" title={fn.handler}>{fn.handler}</span>
                          <span className="text-[10px] text-slate-500 capitalize">{fn.package_type} Package</span>
                        </div>
                      </td>

                      {/* Last Modified */}
                      <td className="p-4 whitespace-nowrap text-slate-500 text-[11px]">
                        {fn.last_modified !== 'N/A' 
                          ? new Date(fn.last_modified).toLocaleDateString('en-US', {
                              month: 'short',
                              day: 'numeric',
                              year: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })
                          : 'N/A'
                        }
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
