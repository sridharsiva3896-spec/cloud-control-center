import { Zap, Play, AlertCircle } from 'lucide-react';
import { LambdaSummary } from '../../types/lambda';

interface SummaryCardsProps {
  summary?: LambdaSummary;
  loading: boolean;
}

export default function SummaryCards({ summary, loading }: SummaryCardsProps) {
  const stats = [
    {
      title: 'Total Functions',
      value: summary?.functions ?? 0,
      icon: Zap,
      color: 'text-orange-400 bg-orange-500/10 border-orange-500/15',
      desc: 'All serverless functions in region'
    },
    {
      title: 'Active Functions',
      value: summary?.active ?? 0,
      icon: Play,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15',
      desc: 'Functions initialized & active'
    },
    {
      title: 'Failed Functions',
      value: summary?.failed ?? 0,
      icon: AlertCircle,
      color: summary && summary.failed > 0 
        ? 'text-rose-400 bg-rose-500/20 border-rose-500/30' 
        : 'text-slate-400 bg-slate-500/10 border-slate-500/15',
      desc: 'Functions in a failed initialization state'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {stats.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <div
            key={idx}
            className={`border rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 shadow-lg ${
              loading 
                ? 'bg-slate-900/40 border-slate-800/60 animate-pulse' 
                : 'bg-[#0f1422] border-slate-800/80 hover:border-slate-700/80'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono font-medium tracking-wide text-slate-400 uppercase">
                {stat.title}
              </span>
              <div className={`p-2 rounded-lg border ${stat.color}`}>
                <Icon className="w-4 h-4 stroke-[2]" />
              </div>
            </div>
            
            <div>
              <div className="text-3xl font-mono font-bold text-white tracking-tight mb-1">
                {loading ? '...' : stat.value.toLocaleString()}
              </div>
              <p className="text-xs text-slate-400 font-sans leading-tight">
                {stat.desc}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
