import { useState } from 'react';
import { Radio, Copy, Check } from 'lucide-react';
import { ListenerInfo } from '../../types/loadBalancer';

interface ListenerTableProps {
  listeners: ListenerInfo[];
  loading: boolean;
}

export default function ListenerTable({ listeners, loading }: ListenerTableProps) {
  const [copiedArn, setCopiedArn] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedArn(text);
    setTimeout(() => setCopiedArn(null), 2000);
  };

  // Helper to extract a friendly Load Balancer name from its ARN
  const getLoadBalancerName = (arn: string) => {
    if (!arn || arn === 'N/A') return 'N/A';
    try {
      // format: arn:aws:elasticloadbalancing:region:account:loadbalancer/type/name/id
      const parts = arn.split('/');
      if (parts.length >= 3) {
        return parts[parts.length - 2];
      }
    } catch (e) {
      // ignore
    }
    return arn;
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-indigo-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Retrieving listener parameters...</span>
      </div>
    );
  }

  if (listeners.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Radio className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Listeners Found</p>
          <p className="text-[11px] text-slate-500">
            No active listener profiles associated with load balancers in this region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-bold">Protocol</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-bold">Port</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-bold">Default Action</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-bold">Parent Load Balancer</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 font-bold">Listener ARN</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {listeners.map((lis) => {
              const isCopied = copiedArn === lis.arn;
              const lbFriendlyName = getLoadBalancerName(lis.load_balancer_arn);

              return (
                <tr key={lis.arn} className="hover:bg-slate-800/20 transition-colors">
                  {/* Protocol */}
                  <td className="p-4 whitespace-nowrap">
                    <span className="px-2.5 py-0.5 rounded bg-indigo-500/5 text-indigo-400 border border-indigo-500/10 text-[10px] font-bold uppercase">
                      {lis.protocol}
                    </span>
                  </td>

                  {/* Port */}
                  <td className="p-4 whitespace-nowrap text-slate-100 font-bold">
                    {lis.port}
                  </td>

                  {/* Default Action */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex flex-wrap gap-1">
                      {lis.default_actions && lis.default_actions.length > 0 ? (
                        lis.default_actions.map((act, i) => (
                          <span
                            key={i}
                            className="text-[10px] bg-slate-900 border border-slate-800 text-amber-400 font-semibold px-2 py-0.5 rounded"
                          >
                            {act}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-500">N/A</span>
                      )}
                    </div>
                  </td>

                  {/* Parent Load Balancer */}
                  <td className="p-4 whitespace-nowrap text-slate-300 font-semibold">
                    {lbFriendlyName}
                  </td>

                  {/* Listener ARN */}
                  <td className="p-4 max-w-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-500 select-all truncate max-w-[200px]" title={lis.arn}>
                        {lis.arn}
                      </span>
                      <button
                        onClick={() => copyToClipboard(lis.arn)}
                        className="text-slate-600 hover:text-slate-400 transition-colors shrink-0"
                        title="Copy Listener ARN"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
