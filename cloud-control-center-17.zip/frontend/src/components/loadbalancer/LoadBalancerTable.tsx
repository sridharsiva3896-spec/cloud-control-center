import { useState } from 'react';
import { Server, Copy, Check } from 'lucide-react';
import { LoadBalancerInfo } from '../../types/loadBalancer';

interface LoadBalancerTableProps {
  loadBalancers: LoadBalancerInfo[];
  loading: boolean;
}

export default function LoadBalancerTable({ loadBalancers, loading }: LoadBalancerTableProps) {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(`${label}_${text}`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-sky-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Retrieving elastic load balancers...</span>
      </div>
    );
  }

  if (loadBalancers.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Server className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Load Balancers Found</p>
          <p className="text-[11px] text-slate-500">
            No active load balancers found matching the query in this region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Name / ARN</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Type</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Scheme</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">State</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">DNS Name</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">VPC ID</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Availability Zones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {loadBalancers.map((lb) => {
              const isNameCopied = copiedText === `arn_${lb.arn}`;
              const isDnsCopied = copiedText === `dns_${lb.dns_name}`;
              const isVpcCopied = copiedText === `vpc_${lb.vpc_id}`;

              return (
                <tr key={lb.arn} className="hover:bg-slate-800/20 transition-colors">
                  {/* Name & ARN */}
                  <td className="p-4 max-w-xs">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-100 font-bold select-all">{lb.name}</span>
                        <button
                          onClick={() => copyToClipboard(lb.arn, 'arn')}
                          className="text-slate-500 hover:text-slate-300 transition-colors"
                          title="Copy ARN"
                        >
                          {isNameCopied ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-500 truncate" title={lb.arn}>
                        {lb.arn}
                      </span>
                    </div>
                  </td>

                  {/* Type */}
                  <td className="p-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
                      lb.type === 'application'
                        ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                        : lb.type === 'network'
                        ? 'bg-indigo-500/5 text-indigo-400 border-indigo-500/10'
                        : 'bg-purple-500/5 text-purple-400 border-purple-500/10'
                    }`}>
                      {lb.type}
                    </span>
                  </td>

                  {/* Scheme */}
                  <td className="p-4 whitespace-nowrap text-slate-300">
                    {lb.scheme}
                  </td>

                  {/* State */}
                  <td className="p-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
                      lb.state === 'active'
                        ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                        : lb.state === 'provisioning'
                        ? 'bg-amber-500/5 text-amber-400 border-amber-500/10'
                        : 'bg-rose-500/5 text-rose-400 border-rose-500/10'
                    }`}>
                      {lb.state}
                    </span>
                  </td>

                  {/* DNS Name */}
                  <td className="p-4 max-w-xs">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-300 select-all truncate max-w-[180px]" title={lb.dns_name}>
                        {lb.dns_name}
                      </span>
                      <button
                        onClick={() => copyToClipboard(lb.dns_name, 'dns')}
                        className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                        title="Copy DNS Name"
                      >
                        {isDnsCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* VPC ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 select-all">{lb.vpc_id}</span>
                      {lb.vpc_id !== 'N/A' && (
                        <button
                          onClick={() => copyToClipboard(lb.vpc_id, 'vpc')}
                          className="text-slate-600 hover:text-slate-400 transition-colors"
                          title="Copy VPC ID"
                        >
                          {isVpcCopied ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      )}
                    </div>
                  </td>

                  {/* Availability Zones */}
                  <td className="p-4">
                    <div className="flex flex-wrap gap-1">
                      {lb.availability_zones && lb.availability_zones.length > 0 ? (
                        lb.availability_zones.map((az) => (
                          <span
                            key={az}
                            className="text-[9px] bg-slate-900 border border-slate-800 text-slate-300 px-1.5 py-0.5 rounded whitespace-nowrap"
                          >
                            {az}
                          </span>
                        ))
                      ) : (
                        <span className="text-slate-500">N/A</span>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
