import { Server, Cpu, Layers, ShieldCheck, ShieldAlert, Radio, Globe } from 'lucide-react';
import { LoadBalancerSummary } from '../../types/loadBalancer';

interface SummaryCardsProps {
  summary?: LoadBalancerSummary;
  loading: boolean;
}

export default function SummaryCards({ summary, loading }: SummaryCardsProps) {
  const stats = [
    {
      title: 'Total Load Balancers',
      value: summary?.load_balancers ?? 0,
      icon: Server,
      color: 'text-sky-400 bg-sky-500/10 border-sky-500/15',
      desc: 'All managed balances'
    },
    {
      title: 'Application (ALB)',
      value: summary?.application_load_balancers ?? 0,
      icon: Globe,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15',
      desc: 'Layer 7 HTTP/HTTPS Routing'
    },
    {
      title: 'Network (NLB)',
      value: summary?.network_load_balancers ?? 0,
      icon: Radio,
      color: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/15',
      desc: 'Layer 4 TCP/UDP High-Perf'
    },
    {
      title: 'Gateway (GLB)',
      value: summary?.gateway_load_balancers ?? 0,
      icon: Cpu,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/15',
      desc: 'Layer 3 Third-Party Appliances'
    },
    {
      title: 'Target Groups',
      value: summary?.target_groups ?? 0,
      icon: Layers,
      color: 'text-amber-400 bg-amber-500/10 border-amber-500/15',
      desc: 'Destination groups registered'
    },
    {
      title: 'Healthy Targets',
      value: summary?.healthy_targets ?? 0,
      icon: ShieldCheck,
      color: 'text-teal-400 bg-teal-500/10 border-teal-500/15',
      desc: 'Endpoints passing health'
    },
    {
      title: 'Unhealthy Targets',
      value: summary?.unhealthy_targets ?? 0,
      icon: ShieldAlert,
      color: summary && summary.unhealthy_targets > 0 
        ? 'text-rose-400 bg-rose-500/20 border-rose-500/30' 
        : 'text-slate-400 bg-slate-500/10 border-slate-500/15',
      desc: 'Endpoints failing health checks'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 xl:grid-cols-7 gap-4">
      {stats.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <div
            key={idx}
            className={`border rounded-2xl p-4 flex flex-col justify-between transition-all duration-300 shadow-lg ${
              loading 
                ? 'bg-slate-900/40 border-slate-800/60 animate-pulse' 
                : 'bg-[#0b0f19]/90 border-slate-800/80 hover:border-slate-700/80'
            }`}
          >
            <div className="flex items-center justify-between mb-3">
              <span className="text-[11px] font-mono font-medium tracking-wide text-slate-400 uppercase">
                {stat.title}
              </span>
              <div className={`p-1.5 rounded-lg border ${stat.color}`}>
                <Icon className="w-4 h-4 stroke-[1.5]" />
              </div>
            </div>
            
            <div>
              <div className="text-2xl font-mono font-bold text-white tracking-tight mb-1">
                {loading ? '...' : stat.value.toLocaleString()}
              </div>
              <p className="text-[10px] text-slate-500 font-sans leading-tight">
                {stat.desc}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
