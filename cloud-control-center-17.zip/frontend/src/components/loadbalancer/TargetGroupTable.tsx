import { useState } from 'react';
import { Layers, Copy, Check } from 'lucide-react';
import { TargetGroupInfo } from '../../types/loadBalancer';

interface TargetGroupTableProps {
  targetGroups: TargetGroupInfo[];
  loading: boolean;
}

export default function TargetGroupTable({ targetGroups, loading }: TargetGroupTableProps) {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(`${label}_${text}`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Retrieving target groups...</span>
      </div>
    );
  }

  if (targetGroups.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Layers className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Target Groups Found</p>
          <p className="text-[11px] text-slate-500">
            No target groups discovered in this region or matching the filter.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Target Group Name / ARN</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Protocol</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Port</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Target Type</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Health Check Path</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">VPC ID</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {targetGroups.map((tg) => {
              const isArnCopied = copiedText === `arn_${tg.arn}`;
              const isVpcCopied = copiedText === `vpc_${tg.vpc_id}`;

              return (
                <tr key={tg.arn} className="hover:bg-slate-800/20 transition-colors">
                  {/* Name / ARN */}
                  <td className="p-4 max-w-xs">
                    <div className="flex flex-col gap-1">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-100 font-bold select-all">{tg.name}</span>
                        <button
                          onClick={() => copyToClipboard(tg.arn, 'arn')}
                          className="text-slate-500 hover:text-slate-300 transition-colors"
                          title="Copy ARN"
                        >
                          {isArnCopied ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                      <span className="text-[10px] text-slate-500 truncate" title={tg.arn}>
                        {tg.arn}
                      </span>
                    </div>
                  </td>

                  {/* Protocol */}
                  <td className="p-4 whitespace-nowrap">
                    <span className="px-2 py-0.5 rounded bg-slate-900 border border-slate-850 text-slate-300 text-[10px] font-bold uppercase">
                      {tg.protocol}
                    </span>
                  </td>

                  {/* Port */}
                  <td className="p-4 whitespace-nowrap text-slate-100 font-bold">
                    {tg.port}
                  </td>

                  {/* Target Type */}
                  <td className="p-4 whitespace-nowrap text-slate-300 uppercase text-[10px]">
                    {tg.target_type}
                  </td>

                  {/* Health Check Path */}
                  <td className="p-4 whitespace-nowrap text-slate-300">
                    <span className="bg-slate-900/60 px-1.5 py-0.5 rounded text-slate-400 font-semibold border border-slate-800/50">
                      {tg.health_check_path || '/'}
                    </span>
                  </td>

                  {/* VPC ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 select-all">{tg.vpc_id}</span>
                      {tg.vpc_id !== 'N/A' && (
                        <button
                          onClick={() => copyToClipboard(tg.vpc_id, 'vpc')}
                          className="text-slate-600 hover:text-slate-400 transition-colors"
                          title="Copy VPC ID"
                        >
                          {isVpcCopied ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      )}
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
