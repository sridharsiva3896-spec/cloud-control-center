import { useState } from 'react';
import { ShieldAlert, Copy, Check } from 'lucide-react';
import { TargetHealthInfo } from '../../types/loadBalancer';

interface TargetHealthTableProps {
  targetHealths: TargetHealthInfo[];
  loading: boolean;
}

export default function TargetHealthTable({ targetHealths, loading }: TargetHealthTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(text);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getTargetGroupName = (arn: string) => {
    if (!arn || arn === 'N/A') return 'N/A';
    try {
      // format: arn:aws:elasticloadbalancing:region:account:targetgroup/name/id
      const parts = arn.split('/');
      if (parts.length >= 2) {
        return parts[parts.length - 2];
      }
    } catch (e) {
      // ignore
    }
    return arn;
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-teal-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying target health indexes...</span>
      </div>
    );
  }

  if (targetHealths.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <ShieldAlert className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Target Health Records</p>
          <p className="text-[11px] text-slate-500">
            No registered target endpoints found or health status queries are not available in this region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Target ID</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Port</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Health State</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Reason</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Description</th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Target Group</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {targetHealths.map((th, index) => {
              const uniqueKey = `${th.target_group_arn}_${th.target_id}_${th.port}_${index}`;
              const isCopied = copiedId === th.target_id;
              const tgFriendlyName = getTargetGroupName(th.target_group_arn);

              return (
                <tr key={uniqueKey} className="hover:bg-slate-800/20 transition-colors">
                  {/* Target ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-100 font-bold select-all">{th.target_id}</span>
                      <button
                        onClick={() => copyToClipboard(th.target_id)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Target ID"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Port */}
                  <td className="p-4 whitespace-nowrap text-slate-200">
                    {th.port}
                  </td>

                  {/* Health State */}
                  <td className="p-4 whitespace-nowrap">
                    <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
                      th.health_state === 'healthy'
                        ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                        : th.health_state === 'unhealthy'
                        ? 'bg-rose-500/5 text-rose-400 border-rose-500/10'
                        : th.health_state === 'unused'
                        ? 'bg-amber-500/5 text-amber-400 border-amber-500/10'
                        : 'bg-slate-500/5 text-slate-400 border-slate-500/10'
                    }`}>
                      {th.health_state}
                    </span>
                  </td>

                  {/* Reason */}
                  <td className="p-4 whitespace-nowrap text-slate-400">
                    {th.health_reason && th.health_reason !== 'N/A' ? (
                      <span className="text-amber-400/90 font-medium">
                        {th.health_reason}
                      </span>
                    ) : (
                      <span className="text-slate-600">—</span>
                    )}
                  </td>

                  {/* Description */}
                  <td className="p-4 text-slate-400 max-w-xs truncate" title={th.description}>
                    {th.description && th.description !== 'N/A' ? th.description : <span className="text-slate-600">—</span>}
                  </td>

                  {/* Parent Target Group Name */}
                  <td className="p-4 whitespace-nowrap text-slate-300 font-medium">
                    {tgFriendlyName}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
