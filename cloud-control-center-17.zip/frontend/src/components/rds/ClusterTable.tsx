import { useState } from 'react';
import { Copy, Check, Network, Shield } from 'lucide-react';
import { RDSCluster } from '../../types/rds';
import ExportMenu from '../common/ExportMenu';

interface ClusterTableProps {
  clusters: RDSCluster[];
  loading: boolean;
}

export default function ClusterTable({ clusters, loading }: ClusterTableProps) {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(`${label}_${text}`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  if (loading) {
    return null; // The instances skeleton is already running, we can render nothing or a small loading indicator
  }

  if (clusters.length === 0) {
    return null; // Only show Cluster section if there are actually database clusters configured
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Network className="w-4 h-4 text-purple-400" />
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            Database Clusters ({clusters.length})
          </h3>
        </div>
        <ExportMenu data={clusters} filenamePrefix="AWS_RDS_Clusters" />
      </div>

      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-slate-800 bg-slate-900/20">
                <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Cluster Identifier</th>
                <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Engine / Version</th>
                <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Status</th>
                <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">High Availability</th>
                <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Cluster Members</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
              {clusters.map((cl) => {
                const isIdCopied = copiedText === `cl_id_${cl.identifier}`;
                const isAvailable = cl.status.toLowerCase() === 'available';

                return (
                  <tr key={cl.identifier} className="hover:bg-slate-800/20 transition-colors">
                    
                    {/* Cluster Identifier */}
                    <td className="p-4 whitespace-nowrap">
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-100 font-bold select-all truncate" title={cl.identifier}>
                          {cl.identifier}
                        </span>
                        <button
                          onClick={() => copyToClipboard(cl.identifier, 'cl_id')}
                          className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                          title="Copy Cluster ID"
                        >
                          {isIdCopied ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    </td>

                    {/* Engine & Version */}
                    <td className="p-4 whitespace-nowrap">
                      <div className="flex flex-col gap-0.5">
                        <span className="text-slate-200 font-bold capitalize">
                          {cl.engine}
                        </span>
                        <span className="text-[10px] text-slate-500">v{cl.version}</span>
                      </div>
                    </td>

                    {/* Status */}
                    <td className="p-4 whitespace-nowrap">
                      <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase border ${
                        isAvailable
                          ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/15'
                          : 'bg-rose-500/5 text-rose-400 border-rose-500/15'
                      }`}>
                        <span className={`w-1.5 h-1.5 rounded-full ${isAvailable ? 'bg-emerald-400' : 'bg-rose-400'}`} />
                        {cl.status}
                      </span>
                    </td>

                    {/* HA Details */}
                    <td className="p-4 whitespace-nowrap text-slate-400">
                      <div className="flex items-center gap-1.5">
                        <Shield className={`w-3.5 h-3.5 ${cl.multi_az ? 'text-purple-400' : 'text-slate-500'}`} />
                        <span className={`text-[10px] font-semibold ${cl.multi_az ? 'text-purple-400' : 'text-slate-500'}`}>
                          {cl.multi_az ? 'Multi-AZ Cluster Enabled' : 'Single-AZ Cluster'}
                        </span>
                      </div>
                    </td>

                    {/* Cluster Members */}
                    <td className="p-4 text-slate-400">
                      {cl.members.length === 0 ? (
                        <span className="text-slate-500">No members configured</span>
                      ) : (
                        <div className="flex flex-wrap gap-1.5">
                          {cl.members.map((member, mIdx) => (
                            <span
                              key={mIdx}
                              className="px-1.5 py-0.5 rounded bg-slate-950/40 border border-slate-800/60 text-[10px] text-slate-300 font-medium"
                            >
                              {member}
                            </span>
                          ))}
                        </div>
                      )}
                    </td>

                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
