import { useState, useMemo } from 'react';
import { Search, Filter, Copy, Check, Database, Globe } from 'lucide-react';
import { RDSInstance } from '../../types/rds';

interface RDSInstanceTableProps {
  instances: RDSInstance[];
  loading: boolean;
}

export default function RDSInstanceTable({ instances, loading }: RDSInstanceTableProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedEngine, setSelectedEngine] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [selectedMultiAZ, setSelectedMultiAZ] = useState('All');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(`${label}_${text}`);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Dynamic filter list for Engines
  const engines = useMemo(() => {
    const list = new Set<string>();
    instances.forEach(inst => {
      if (inst.engine && inst.engine !== 'N/A') {
        list.add(inst.engine);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [instances]);

  // Dynamic filter list for Statuses
  const statuses = useMemo(() => {
    const list = new Set<string>();
    instances.forEach(inst => {
      if (inst.status && inst.status !== 'N/A') {
        list.add(inst.status);
      }
    });
    return ['All', ...Array.from(list).sort()];
  }, [instances]);

  // Filter instances locally
  const filteredInstances = useMemo(() => {
    return instances.filter(inst => {
      const matchesSearch = 
        inst.identifier.toLowerCase().includes(searchQuery.toLowerCase()) ||
        inst.engine.toLowerCase().includes(searchQuery.toLowerCase());
      
      const matchesEngine = selectedEngine === 'All' || inst.engine === selectedEngine;
      const matchesStatus = selectedStatus === 'All' || inst.status === selectedStatus;
      
      let matchesMultiAZ = true;
      if (selectedMultiAZ === 'Yes') matchesMultiAZ = inst.multi_az === true;
      if (selectedMultiAZ === 'No') matchesMultiAZ = inst.multi_az === false;

      return matchesSearch && matchesEngine && matchesStatus && matchesMultiAZ;
    });
  }, [instances, searchQuery, selectedEngine, selectedStatus, selectedMultiAZ]);

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Retrieving RDS instances inventory...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      
      {/* Search & Filter Controls */}
      <div className="flex flex-col xl:flex-row gap-4 justify-between items-start xl:items-center bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4">
        
        {/* Search Input */}
        <div className="relative w-full xl:w-96">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            placeholder="Search by DB Identifier or Engine..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-[#121829] border border-slate-800 focus:border-slate-700/80 rounded-xl py-2 pl-10 pr-4 text-xs font-mono text-white placeholder-slate-500 focus:outline-none transition-all"
          />
        </div>

        {/* Multi Filters Selection Grid */}
        <div className="flex flex-wrap gap-3 w-full xl:w-auto">
          
          {/* Engine Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
              Engine:
            </span>
            <select
              value={selectedEngine}
              onChange={(e) => setSelectedEngine(e.target.value)}
              className="bg-transparent text-xs font-mono font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {engines.map(eng => (
                <option key={eng} value={eng} className="bg-[#121829] text-slate-200">
                  {eng}
                </option>
              ))}
            </select>
          </div>

          {/* Status Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Filter className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
              Status:
            </span>
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="bg-transparent text-xs font-mono font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              {statuses.map(st => (
                <option key={st} value={st} className="bg-[#121829] text-slate-200">
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Multi-AZ Filter */}
          <div className="flex items-center gap-2 bg-[#121829] border border-slate-800 rounded-xl px-3 py-1.5 shrink-0">
            <Globe className="w-3.5 h-3.5 text-slate-500" />
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
              Multi-AZ:
            </span>
            <select
              value={selectedMultiAZ}
              onChange={(e) => setSelectedMultiAZ(e.target.value)}
              className="bg-transparent text-xs font-mono font-medium text-slate-200 focus:outline-none cursor-pointer pr-1"
            >
              <option value="All" className="bg-[#121829] text-slate-200">All</option>
              <option value="Yes" className="bg-[#121829] text-slate-200">Yes</option>
              <option value="No" className="bg-[#121829] text-slate-200">No</option>
            </select>
          </div>

        </div>
      </div>

      {/* Primary instances table body */}
      {filteredInstances.length === 0 ? (
        <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
          <Database className="w-10 h-10 text-slate-600 stroke-[1.5]" />
          <div className="flex flex-col gap-1">
            <p className="text-xs font-mono font-bold text-slate-400">No RDS Instances Found</p>
            <p className="text-[11px] text-slate-500">
              No database instances match your active filters or search terms.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/20">
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">DB Identifier</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Engine / Version</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Status</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Instance Class</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Storage Size</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Multi-AZ / Region AZ</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Endpoint Address</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                {filteredInstances.map((inst) => {
                  const isIdCopied = copiedText === `id_${inst.identifier}`;
                  const isEndpointCopied = copiedText === `end_${inst.endpoint}`;
                  const isAvailable = inst.status.toLowerCase() === 'available';

                  return (
                    <tr key={inst.identifier} className="hover:bg-slate-800/20 transition-colors">
                      
                      {/* DB Identifier */}
                      <td className="p-4 whitespace-nowrap">
                        <div className="flex items-center gap-1.5">
                          <span className="text-slate-100 font-bold select-all truncate max-w-[180px]" title={inst.identifier}>
                            {inst.identifier}
                          </span>
                          <button
                            onClick={() => copyToClipboard(inst.identifier, 'id')}
                            className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                            title="Copy Identifier"
                          >
                            {isIdCopied ? (
                              <Check className="w-3 h-3 text-emerald-400" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>

                      {/* Engine & Version */}
                      <td className="p-4 whitespace-nowrap">
                        <div className="flex flex-col gap-0.5">
                          <span className="text-slate-200 font-bold capitalize">
                            {inst.engine}
                          </span>
                          <span className="text-[10px] text-slate-500">v{inst.version}</span>
                        </div>
                      </td>

                      {/* Status */}
                      <td className="p-4 whitespace-nowrap">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase border ${
                          isAvailable
                            ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/15'
                            : inst.status.toLowerCase().includes('stopped') || inst.status.toLowerCase().includes('stopping')
                            ? 'bg-rose-500/5 text-rose-400 border-rose-500/15'
                            : 'bg-amber-500/5 text-amber-400 border-amber-500/15 animate-pulse'
                        }`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            isAvailable 
                              ? 'bg-emerald-400 shadow-sm shadow-emerald-400/50' 
                              : 'bg-rose-400'
                          }`} />
                          {inst.status}
                        </span>
                      </td>

                      {/* Instance Class */}
                      <td className="p-4 whitespace-nowrap text-slate-300">
                        <span className="bg-slate-950/40 border border-slate-800/40 px-2 py-0.5 rounded text-[11px] font-semibold text-slate-300">
                          {inst.class}
                        </span>
                      </td>

                      {/* Storage Size */}
                      <td className="p-4 whitespace-nowrap text-slate-300 font-bold">
                        {inst.storage} GiB
                      </td>

                      {/* Multi-AZ & Availability Zone */}
                      <td className="p-4 whitespace-nowrap text-slate-400">
                        <div className="flex flex-col gap-0.5">
                          <span className={`text-[10px] font-semibold ${inst.multi_az ? 'text-purple-400' : 'text-slate-500'}`}>
                            {inst.multi_az ? 'Multi-AZ Deploy' : 'Single-AZ'}
                          </span>
                          <span className="text-[10px] text-slate-500">AZ: {inst.az}</span>
                        </div>
                      </td>

                      {/* Endpoint Address */}
                      <td className="p-4 max-w-xs text-slate-400">
                        <div className="flex items-center gap-1.5">
                          <span className="truncate select-all text-[11px]" title={inst.endpoint}>
                            {inst.endpoint}
                          </span>
                          {inst.endpoint !== 'N/A' && (
                            <button
                              onClick={() => copyToClipboard(inst.endpoint, 'end')}
                              className="text-slate-500 hover:text-slate-300 transition-colors shrink-0"
                              title="Copy Connection string"
                            >
                              {isEndpointCopied ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          )}
                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
