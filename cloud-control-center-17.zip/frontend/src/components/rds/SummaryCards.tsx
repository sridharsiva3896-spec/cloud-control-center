import { Database, Network, CheckCircle2, AlertTriangle } from 'lucide-react';
import { RDSSummary } from '../../types/rds';

interface SummaryCardsProps {
  summary?: RDSSummary;
  loading: boolean;
}

export default function SummaryCards({ summary, loading }: SummaryCardsProps) {
  const stats = [
    {
      title: 'Total Instances',
      value: summary?.instances ?? 0,
      icon: Database,
      color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15',
      desc: 'All relational database hosts'
    },
    {
      title: 'DB Clusters',
      value: summary?.clusters ?? 0,
      icon: Network,
      color: 'text-purple-400 bg-purple-500/10 border-purple-500/15',
      desc: 'Multi-node high availability groups'
    },
    {
      title: 'Available',
      value: summary?.available ?? 0,
      icon: CheckCircle2,
      color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/15',
      desc: 'Instances online & accepting connections'
    },
    {
      title: 'Stopped / Stopping',
      value: summary?.stopped ?? 0,
      icon: AlertTriangle,
      color: summary && summary.stopped > 0
        ? 'text-rose-400 bg-rose-500/20 border-rose-500/30'
        : 'text-slate-400 bg-slate-500/10 border-slate-500/15',
      desc: 'Offline or transitioning hosts'
    }
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {stats.map((stat, idx) => {
        const Icon = stat.icon;
        return (
          <div
            key={idx}
            className={`border rounded-2xl p-5 flex flex-col justify-between transition-all duration-300 shadow-lg ${
              loading 
                ? 'bg-slate-900/40 border-slate-800/60 animate-pulse' 
                : 'bg-[#0f1422] border-slate-800/80 hover:border-slate-700/80'
            }`}
          >
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-mono font-medium tracking-wide text-slate-400 uppercase">
                {stat.title}
              </span>
              <div className={`p-2 rounded-lg border ${stat.color}`}>
                <Icon className="w-4 h-4 stroke-[2]" />
              </div>
            </div>
            
            <div>
              <div className="text-3xl font-mono font-bold text-white tracking-tight mb-1">
                {loading ? '...' : stat.value.toLocaleString()}
              </div>
              <p className="text-xs text-slate-400 font-sans leading-tight">
                {stat.desc}
              </p>
            </div>
          </div>
        );
      })}
    </div>
  );
}
