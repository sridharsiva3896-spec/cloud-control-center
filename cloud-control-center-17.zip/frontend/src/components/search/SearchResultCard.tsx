import { SearchResult } from '../../types/search';
import { Server, Database, User, Key, Users, Layers, MapPin } from 'lucide-react';

interface SearchResultCardProps {
  result: SearchResult;
}

export default function SearchResultCard({ result }: SearchResultCardProps) {
  // Select matching icon & color scheme
  const getResourceIcon = () => {
    switch (result.service) {
      case 'EC2':
        return {
          icon: <Server className="w-5 h-5" />,
          bgColor: 'bg-orange-500/10 border-orange-500/15 text-orange-400',
          badgeColor: 'bg-orange-500/10 text-orange-400 border-orange-500/20'
        };
      case 'S3':
        return {
          icon: <Database className="w-5 h-5" />,
          bgColor: 'bg-emerald-500/10 border-emerald-500/15 text-emerald-400',
          badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/20'
        };
      case 'IAM':
        // Match specific resource types for IAM
        let iconElement = <User className="w-5 h-5" />;
        if (result.resource_type === 'Role') {
          iconElement = <Key className="w-5 h-5" />;
        } else if (result.resource_type === 'Group') {
          iconElement = <Users className="w-5 h-5" />;
        }
        return {
          icon: iconElement,
          bgColor: 'bg-purple-500/10 border-purple-500/15 text-purple-400',
          badgeColor: 'bg-purple-500/10 text-purple-400 border-purple-500/20'
        };
      default:
        return {
          icon: <Layers className="w-5 h-5" />,
          bgColor: 'bg-slate-500/10 border-slate-500/15 text-slate-400',
          badgeColor: 'bg-slate-500/10 text-slate-400 border-slate-500/20'
        };
    }
  };

  const scheme = getResourceIcon();

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/80 hover:shadow-2xl transition-all duration-200 flex flex-col justify-between space-y-4">
      
      {/* Top Header Row */}
      <div className="flex items-start justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className={`p-2.5 rounded-xl border ${scheme.bgColor} shrink-0 shadow-sm`}>
            {scheme.icon}
          </div>
          <div className="min-w-0">
            <h4 className="text-sm font-bold text-white font-mono uppercase truncate max-w-[180px]" title={result.name}>
              {result.name}
            </h4>
            <span className="text-[10px] text-slate-500 font-mono tracking-wider uppercase block mt-0.5">
              {result.resource_type}
            </span>
          </div>
        </div>
        
        {/* Service Badge */}
        <span className={`px-2.5 py-1 text-[10px] font-bold font-mono rounded-lg border uppercase tracking-wider ${scheme.badgeColor}`}>
          {result.service}
        </span>
      </div>

      {/* Resource Metadata Details */}
      <div className="space-y-2 pt-2 border-t border-slate-800/50">
        
        {/* Resource ID */}
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-500 uppercase text-[10px]">Resource ID</span>
          <span className="text-slate-300 font-medium truncate max-w-[160px]" title={result.resource_id}>
            {result.resource_id}
          </span>
        </div>

        {/* Region */}
        <div className="flex items-center justify-between text-xs font-mono">
          <span className="text-slate-500 uppercase text-[10px]">Region / Scope</span>
          <span className="text-slate-400 flex items-center gap-1">
            <MapPin className="w-3 h-3 text-slate-500 shrink-0" />
            {result.region}
          </span>
        </div>

      </div>

    </div>
  );
}
