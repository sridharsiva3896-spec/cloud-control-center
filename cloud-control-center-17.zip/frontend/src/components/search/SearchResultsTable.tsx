import { SearchResult } from '../../types/search';
import { Server, Database, User, Key, Users, Layers, MapPin } from 'lucide-react';

interface SearchResultsTableProps {
  results: SearchResult[];
}

export default function SearchResultsTable({ results }: SearchResultsTableProps) {
  
  const getBadgeColors = (service: string) => {
    switch (service) {
      case 'EC2':
        return 'text-orange-400 bg-orange-500/10 border-orange-500/15';
      case 'S3':
        return 'text-emerald-400 bg-emerald-500/10 border-emerald-500/15';
      case 'IAM':
        return 'text-purple-400 bg-purple-500/10 border-purple-500/15';
      default:
        return 'text-slate-400 bg-slate-500/10 border-slate-500/15';
    }
  };

  const getServiceIcon = (service: string, resourceType: string) => {
    switch (service) {
      case 'EC2':
        return <Server className="w-3.5 h-3.5 text-orange-400" />;
      case 'S3':
        return <Database className="w-3.5 h-3.5 text-emerald-400" />;
      case 'IAM':
        if (resourceType === 'Role') return <Key className="w-3.5 h-3.5 text-purple-400" />;
        if (resourceType === 'Group') return <Users className="w-3.5 h-3.5 text-purple-400" />;
        return <User className="w-3.5 h-3.5 text-purple-400" />;
      default:
        return <Layers className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full border-collapse text-left">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/30 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
              <th className="px-6 py-4">Service</th>
              <th className="px-6 py-4">Resource Type</th>
              <th className="px-6 py-4">Resource Name</th>
              <th className="px-6 py-4">Resource ID</th>
              <th className="px-6 py-4">Region / Scope</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50 text-xs text-slate-300 font-mono">
            {results.map((resource, idx) => (
              <tr key={`${resource.resource_id}-${idx}`} className="hover:bg-slate-900/10 transition-colors">
                
                {/* Service Column */}
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 text-[10.5px] font-bold uppercase rounded-lg border ${getBadgeColors(resource.service)}`}>
                    {getServiceIcon(resource.service, resource.resource_type)}
                    {resource.service}
                  </span>
                </td>

                {/* Resource Type Column */}
                <td className="px-6 py-4 whitespace-nowrap text-slate-400 uppercase text-[10px]">
                  {resource.resource_type}
                </td>

                {/* Resource Name Column */}
                <td className="px-6 py-4 whitespace-nowrap font-bold text-white">
                  {resource.name}
                </td>

                {/* Resource ID Column */}
                <td className="px-6 py-4 whitespace-nowrap text-slate-400 text-[11px]">
                  {resource.resource_id}
                </td>

                {/* Region Column */}
                <td className="px-6 py-4 whitespace-nowrap text-slate-500 text-[11px] flex items-center gap-1.5 mt-0.5">
                  <MapPin className="w-3.5 h-3.5 text-slate-600 shrink-0" />
                  {resource.region}
                </td>

              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
