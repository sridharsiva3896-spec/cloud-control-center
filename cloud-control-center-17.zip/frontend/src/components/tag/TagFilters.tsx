import { useMemo } from 'react';
import FilterPanel, { FilterField } from '../common/FilterPanel';
import { TaggedResource } from '../../types/tag';

interface TagFiltersProps {
  resources: TaggedResource[];
  selectedService: string;
  setSelectedService: (val: string) => void;
  selectedTagKey: string;
  setSelectedTagKey: (val: string) => void;
  selectedRegion: string;
  setSelectedRegion: (val: string) => void;
  onReset: () => void;
}

export default function TagFilters({
  resources,
  selectedService,
  setSelectedService,
  selectedTagKey,
  setSelectedTagKey,
  selectedRegion,
  setSelectedRegion,
  onReset
}: TagFiltersProps) {

  // Dynamically extract and sort services
  const serviceOptions = useMemo(() => {
    const services = new Set<string>();
    resources.forEach(r => {
      if (r.service && r.service !== 'N/A') services.add(r.service);
    });
    return ['All', ...Array.from(services).sort()];
  }, [resources]);

  // Dynamically extract and sort regions
  const regionOptions = useMemo(() => {
    const regions = new Set<string>();
    resources.forEach(r => {
      if (r.region && r.region !== 'N/A') regions.add(r.region);
    });
    return ['All', ...Array.from(regions).sort()];
  }, [resources]);

  // Dynamically extract and sort tag keys
  const tagKeyOptions = useMemo(() => {
    const keys = new Set<string>();
    resources.forEach(r => {
      if (r.tag_key && r.tag_key !== 'N/A') keys.add(r.tag_key);
    });
    return ['All', ...Array.from(keys).sort()];
  }, [resources]);

  const fields: FilterField[] = [
    {
      key: 'service',
      label: 'Service',
      value: selectedService,
      options: serviceOptions,
      onChange: setSelectedService
    },
    {
      key: 'region',
      label: 'Region',
      value: selectedRegion,
      options: regionOptions,
      onChange: setSelectedRegion
    },
    {
      key: 'tag_key',
      label: 'Tag Key',
      value: selectedTagKey,
      options: tagKeyOptions,
      onChange: setSelectedTagKey
    }
  ];

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4">
      <FilterPanel fields={fields} onReset={onReset} />
    </div>
  );
}
