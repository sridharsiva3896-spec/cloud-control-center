import { useState, useMemo } from 'react';
import { Copy, Check, Globe, Tag, Box } from 'lucide-react';
import { TaggedResource } from '../../types/tag';
import SearchBar from '../common/SearchBar';
import ExportMenu from '../common/ExportMenu';
import EmptyState from '../common/EmptyState';

interface TagTableProps {
  resources: TaggedResource[];
  loading: boolean;
  selectedService: string;
  selectedTagKey: string;
  selectedRegion: string;
}

export default function TagTable({
  resources,
  loading,
  selectedService,
  selectedTagKey,
  selectedRegion
}: TagTableProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(null), 2000);
  };

  // Perform filtering locally
  const filteredResources = useMemo(() => {
    return resources.filter(res => {
      // 1. Service filter
      if (selectedService !== 'All' && res.service !== selectedService) return false;

      // 2. Region filter
      if (selectedRegion !== 'All' && res.region !== selectedRegion) return false;

      // 3. Tag Key filter
      if (selectedTagKey !== 'All' && res.tag_key !== selectedTagKey) return false;

      // 4. Search query
      if (searchQuery.trim() !== '') {
        const query = searchQuery.toLowerCase();
        const matchesArn = res.arn.toLowerCase().includes(query);
        const matchesKey = res.tag_key.toLowerCase().includes(query);
        const matchesVal = res.tag_value.toLowerCase().includes(query);
        const matchesName = res.resource_name.toLowerCase().includes(query);
        if (!matchesArn && !matchesKey && !matchesVal && !matchesName) return false;
      }

      return true;
    });
  }, [resources, selectedService, selectedTagKey, selectedRegion, searchQuery]);

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying AWS Tag Mapping registry...</span>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Search & Export Action Bar */}
      <div className="flex flex-col md:flex-row gap-4 items-stretch md:items-center justify-between">
        <SearchBar 
          value={searchQuery} 
          onChange={setSearchQuery} 
          placeholder="Search by ARN, Key, or Value..." 
        />
        <div className="flex items-center gap-3 self-end md:self-auto">
          <span className="text-[10px] font-mono font-bold text-slate-500 uppercase tracking-wider">
            {filteredResources.length} Results Listed
          </span>
          <ExportMenu 
            data={filteredResources} 
            filenamePrefix="AWS_Tag_Explorer" 
          />
        </div>
      </div>

      {/* Table container */}
      {filteredResources.length === 0 ? (
        <EmptyState 
          title="No Tagged Resources Listed" 
          description="We couldn't locate any active cloud infrastructure tags matching your current search constraints or filters."
          icon={Tag}
        />
      ) : (
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-2xl">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/20">
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Resource Name / ARN</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Service</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Region</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Resource Type</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Tag Key</th>
                  <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">Tag Value</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
                {filteredResources.map((res, idx) => {
                  const isCopied = copiedText === res.arn;
                  return (
                    <tr key={`${res.arn}-${res.tag_key}-${idx}`} className="hover:bg-slate-800/20 transition-colors">
                      {/* Resource Name & ARN */}
                      <td className="p-4 max-w-sm">
                        <div className="flex flex-col gap-1">
                          <span className="text-slate-100 font-bold truncate block" title={res.resource_name}>
                            {res.resource_name || 'Global AWS Object'}
                          </span>
                          <div className="flex items-center gap-1.5 text-[10px] text-slate-500">
                            <span className="truncate max-w-[280px] select-all font-medium" title={res.arn}>
                              {res.arn}
                            </span>
                            <button
                              onClick={() => copyToClipboard(res.arn)}
                              className="text-slate-600 hover:text-slate-400 transition-colors shrink-0"
                              title="Copy ARN"
                            >
                              {isCopied ? (
                                <Check className="w-3 h-3 text-emerald-400" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </div>
                      </td>

                      {/* Service */}
                      <td className="p-4 whitespace-nowrap">
                        <span className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-blue-500/5 text-blue-400 border border-blue-500/15">
                          <Box className="w-3 h-3" />
                          {res.service}
                        </span>
                      </td>

                      {/* Region */}
                      <td className="p-4 whitespace-nowrap text-slate-400">
                        <div className="flex items-center gap-1 text-[11px]">
                          <Globe className="w-3.5 h-3.5 text-slate-500" />
                          <span>{res.region}</span>
                        </div>
                      </td>

                      {/* Resource Type */}
                      <td className="p-4 whitespace-nowrap text-slate-300 font-semibold">
                        {res.resource_type}
                      </td>

                      {/* Tag Key */}
                      <td className="p-4 whitespace-nowrap">
                        <span className="text-slate-200 font-bold bg-[#121624] border border-slate-800 rounded px-2 py-1">
                          {res.tag_key}
                        </span>
                      </td>

                      {/* Tag Value */}
                      <td className="p-4 whitespace-nowrap">
                        <span className="text-emerald-400 font-medium font-mono">
                          {res.tag_value}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
