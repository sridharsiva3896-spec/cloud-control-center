import { useState } from 'react';
import { Globe, Copy, Check } from 'lucide-react';
import { InternetGatewayInfo } from '../../types/vpc';

interface InternetGatewayTableProps {
  gateways: InternetGatewayInfo[];
  loading: boolean;
}

/**
 * InternetGatewayTable Component - Displays AWS Internet Gateways and their attached VPC status.
 */
export default function InternetGatewayTable({ gateways, loading }: InternetGatewayTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string) => {
    if (!id || id === 'Unattached') return;
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying gateway details...</span>
      </div>
    );
  }

  if (gateways.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Globe className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Internet Gateways Found</p>
          <p className="text-[11px] text-slate-500">
            No active internet gateways detected in this region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Internet Gateway ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Attached VPC ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                Status
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {gateways.map((gw) => {
              const isCopied = copiedId === gw.internet_gateway_id;
              const isVpcCopied = copiedId === gw.attached_vpc;
              const isAttached = gw.attached_vpc && gw.attached_vpc !== 'Unattached';

              return (
                <tr key={gw.internet_gateway_id} className="hover:bg-slate-800/20 transition-colors">
                  {/* Gateway ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-100 font-bold select-all">{gw.internet_gateway_id}</span>
                      <button
                        onClick={() => copyToClipboard(gw.internet_gateway_id)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy IGW ID"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Attached VPC */}
                  <td className="p-4 whitespace-nowrap">
                    {isAttached ? (
                      <div className="flex items-center gap-1.5">
                        <span className="text-slate-300 select-all">{gw.attached_vpc}</span>
                        <button
                          onClick={() => copyToClipboard(gw.attached_vpc)}
                          className="text-slate-600 hover:text-slate-400 transition-colors"
                          title="Copy VPC ID"
                        >
                          {isVpcCopied ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      </div>
                    ) : (
                      <span className="text-slate-600 italic">Unattached</span>
                    )}
                  </td>

                  {/* Attachment state */}
                  <td className="p-4 whitespace-nowrap text-center">
                    <span className={`inline-flex px-2.5 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
                      isAttached
                        ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                        : 'bg-rose-500/5 text-rose-400 border-rose-500/10'
                    }`}>
                      {isAttached ? 'Attached' : 'Detached'}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
