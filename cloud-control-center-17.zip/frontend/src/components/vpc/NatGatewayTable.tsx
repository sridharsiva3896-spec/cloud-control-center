import { useState } from 'react';
import { Cpu, Copy, Check } from 'lucide-react';
import { NatGatewayInfo } from '../../types/vpc';

interface NatGatewayTableProps {
  gateways: NatGatewayInfo[];
  loading: boolean;
}

/**
 * NatGatewayTable Component - Displays AWS NAT Gateways and their status details.
 */
export default function NatGatewayTable({ gateways, loading }: NatGatewayTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string) => {
    if (!id || id === 'N/A') return;
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying NAT Gateway structures...</span>
      </div>
    );
  }

  if (gateways.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Cpu className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No NAT Gateways Found</p>
          <p className="text-[11px] text-slate-500">
            No active Network Address Translation (NAT) gateways detected in this region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                NAT Gateway ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Public Elastic IP
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Subnet ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                VPC ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                State
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {gateways.map((gw) => {
              const isCopied = copiedId === gw.nat_gateway_id;
              const isIpCopied = copiedId === gw.public_ip;
              const isSubCopied = copiedId === gw.subnet_id;
              const isVpcCopied = copiedId === gw.vpc_id;

              return (
                <tr key={gw.nat_gateway_id} className="hover:bg-slate-800/20 transition-colors">
                  {/* NAT Gateway ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-100 font-bold select-all">{gw.nat_gateway_id}</span>
                      <button
                        onClick={() => copyToClipboard(gw.nat_gateway_id)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy NAT GW ID"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Public IP */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-200 font-bold select-all">{gw.public_ip}</span>
                      {gw.public_ip !== 'N/A' && (
                        <button
                          onClick={() => copyToClipboard(gw.public_ip)}
                          className="text-slate-500 hover:text-slate-300 transition-colors"
                          title="Copy Public IP"
                        >
                          {isIpCopied ? (
                            <Check className="w-3 h-3 text-emerald-400" />
                          ) : (
                            <Copy className="w-3 h-3" />
                          )}
                        </button>
                      )}
                    </div>
                  </td>

                  {/* Subnet ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 select-all">{gw.subnet_id}</span>
                      <button
                        onClick={() => copyToClipboard(gw.subnet_id)}
                        className="text-slate-600 hover:text-slate-400 transition-colors"
                        title="Copy Subnet ID"
                      >
                        {isSubCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* VPC ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 select-all">{gw.vpc_id}</span>
                      <button
                        onClick={() => copyToClipboard(gw.vpc_id)}
                        className="text-slate-600 hover:text-slate-400 transition-colors"
                        title="Copy VPC ID"
                      >
                        {isVpcCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* State badge */}
                  <td className="p-4 whitespace-nowrap text-center">
                    <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
                      gw.state === 'available'
                        ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                        : gw.state === 'pending'
                        ? 'bg-amber-500/5 text-amber-400 border-amber-500/10 animate-pulse'
                        : 'bg-rose-500/5 text-rose-400 border-rose-500/10'
                    }`}>
                      {gw.state}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
