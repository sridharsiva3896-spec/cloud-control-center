import { useState } from 'react';
import { ShieldAlert, Copy, Check } from 'lucide-react';
import { NetworkACLInfo } from '../../types/vpc';

interface NetworkACLTableProps {
  networkAcls: NetworkACLInfo[];
  loading: boolean;
}

/**
 * NetworkACLTable Component - Displays AWS Network Access Control Lists (NACLs).
 */
export default function NetworkACLTable({ networkAcls, loading }: NetworkACLTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying Network ACLs...</span>
      </div>
    );
  }

  if (networkAcls.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <ShieldAlert className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Network ACLs Found</p>
          <p className="text-[11px] text-slate-500">
            No access control lists match the active query parameters.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Network ACL ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                VPC ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                Rules Count
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                Type
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {networkAcls.map((nacl) => {
              const isCopied = copiedId === nacl.network_acl_id;
              const isVpcCopied = copiedId === nacl.vpc_id;

              return (
                <tr key={nacl.network_acl_id} className="hover:bg-slate-800/20 transition-colors">
                  {/* NACL ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-100 font-bold select-all">{nacl.network_acl_id}</span>
                      <button
                        onClick={() => copyToClipboard(nacl.network_acl_id)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Network ACL ID"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* VPC ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 select-all">{nacl.vpc_id}</span>
                      <button
                        onClick={() => copyToClipboard(nacl.vpc_id)}
                        className="text-slate-600 hover:text-slate-400 transition-colors"
                        title="Copy VPC ID"
                      >
                        {isVpcCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Rules Count */}
                  <td className="p-4 whitespace-nowrap text-center text-slate-200 font-bold">
                    {nacl.rule_count}
                  </td>

                  {/* Is Default */}
                  <td className="p-4 whitespace-nowrap text-center">
                    {nacl.is_default ? (
                      <span className="inline-flex px-2 py-0.5 rounded-md bg-amber-500/5 text-amber-400 border border-amber-500/10 text-[10px] font-bold uppercase">
                        Default
                      </span>
                    ) : (
                      <span className="inline-flex px-2 py-0.5 rounded-md bg-slate-900 text-slate-400 border border-slate-800 text-[10px] font-bold uppercase">
                        Custom
                      </span>
                    )}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
