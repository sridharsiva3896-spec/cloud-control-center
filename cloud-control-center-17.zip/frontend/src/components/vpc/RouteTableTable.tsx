import { useState } from 'react';
import { Route, Copy, Check } from 'lucide-react';
import { RouteTableInfo } from '../../types/vpc';

interface RouteTableTableProps {
  routeTables: RouteTableInfo[];
  loading: boolean;
}

/**
 * RouteTableTable Component - Displays AWS Route Tables.
 */
export default function RouteTableTable({ routeTables, loading }: RouteTableTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying route configurations...</span>
      </div>
    );
  }

  if (routeTables.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Route className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Route Tables Found</p>
          <p className="text-[11px] text-slate-500">
            No route tables match the selected filters or region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Route Table ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                VPC ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                Routes count
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                Associations count
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {routeTables.map((rt) => {
              const isCopied = copiedId === rt.route_table_id;
              const isVpcCopied = copiedId === rt.vpc_id;

              return (
                <tr key={rt.route_table_id} className="hover:bg-slate-800/20 transition-colors">
                  {/* Route Table ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-100 font-bold select-all">{rt.route_table_id}</span>
                      <button
                        onClick={() => copyToClipboard(rt.route_table_id)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Route Table ID"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* VPC ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 select-all">{rt.vpc_id}</span>
                      <button
                        onClick={() => copyToClipboard(rt.vpc_id)}
                        className="text-slate-600 hover:text-slate-400 transition-colors"
                        title="Copy VPC ID"
                      >
                        {isVpcCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Routes count */}
                  <td className="p-4 whitespace-nowrap text-center text-slate-200 font-bold">
                    {rt.routes_count}
                  </td>

                  {/* Associations count */}
                  <td className="p-4 whitespace-nowrap text-center">
                    <span className="inline-flex px-2 py-0.5 rounded-md bg-sky-500/5 text-sky-400 border border-sky-500/10 text-[10px] font-bold">
                      {rt.associations_count} assoc
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
