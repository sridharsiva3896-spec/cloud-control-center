import { useState } from 'react';
import { Shield, Copy, Check } from 'lucide-react';
import { SecurityGroupInfo } from '../../types/vpc';

interface SecurityGroupTableProps {
  securityGroups: SecurityGroupInfo[];
  loading: boolean;
}

/**
 * SecurityGroupTable Component - Renders Security Groups in a modern list with rule summary.
 */
export default function SecurityGroupTable({ securityGroups, loading }: SecurityGroupTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying security groups...</span>
      </div>
    );
  }

  if (securityGroups.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Shield className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Security Groups Found</p>
          <p className="text-[11px] text-slate-500">
            No firewall configurations matched the query parameters in this region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Group ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Group Name
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Description
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                VPC ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                Rules (In / Out)
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {securityGroups.map((sg) => {
              const isCopied = copiedId === sg.group_id;
              const isVpcCopied = copiedId === sg.vpc_id;

              return (
                <tr key={sg.group_id} className="hover:bg-slate-800/20 transition-colors">
                  {/* Group ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-100 font-bold select-all">{sg.group_id}</span>
                      <button
                        onClick={() => copyToClipboard(sg.group_id)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Security Group ID"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Group Name */}
                  <td className="p-4 whitespace-nowrap">
                    <span className="text-slate-200 font-bold max-w-xs truncate block" title={sg.group_name}>
                      {sg.group_name}
                    </span>
                  </td>

                  {/* Description */}
                  <td className="p-4 max-w-xs truncate text-slate-400 font-sans">
                    {sg.description}
                  </td>

                  {/* VPC ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-500 select-all">{sg.vpc_id}</span>
                      <button
                        onClick={() => copyToClipboard(sg.vpc_id)}
                        className="text-slate-600 hover:text-slate-400 transition-colors"
                        title="Copy VPC ID"
                      >
                        {isVpcCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* Rules Count In / Out */}
                  <td className="p-4 whitespace-nowrap text-center">
                    <div className="flex items-center justify-center gap-1.5">
                      <span className="px-2 py-0.5 rounded bg-emerald-500/5 text-emerald-400 border border-emerald-500/10 text-[10px] font-bold">
                        {sg.ingress_rule_count} Inbound
                      </span>
                      <span className="px-2 py-0.5 rounded bg-rose-500/5 text-rose-400 border border-rose-500/10 text-[10px] font-bold">
                        {sg.egress_rule_count} Outbound
                      </span>
                    </div>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
