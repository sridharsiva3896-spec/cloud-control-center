import { useState } from 'react';
import { Layers, Copy, Check } from 'lucide-react';
import { SubnetInfo } from '../../types/vpc';

interface SubnetTableProps {
  subnets: SubnetInfo[];
  loading: boolean;
}

/**
 * SubnetTable Component - Renders Subnets details with responsive parameters.
 */
export default function SubnetTable({ subnets, loading }: SubnetTableProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying subnet structures...</span>
      </div>
    );
  }

  if (subnets.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Layers className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No Subnets Found</p>
          <p className="text-[11px] text-slate-500">
            No subnets match the active query or filter options in this region.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
      <div className="overflow-x-auto">
        <table className="w-full text-left border-collapse">
          <thead>
            <tr className="border-b border-slate-800 bg-slate-900/20">
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Subnet ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                VPC ID
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                CIDR Block
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                Availability Zone
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-right">
                Available IPs
              </th>
              <th className="p-4 text-xs font-mono font-bold uppercase tracking-wider text-slate-400 text-center">
                State
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/60 font-mono text-xs">
            {subnets.map((sub) => {
              const isCopied = copiedId === sub.subnet_id;
              const isVpcCopied = copiedId === sub.vpc_id;

              return (
                <tr key={sub.subnet_id} className="hover:bg-slate-800/20 transition-colors">
                  {/* Subnet ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-100 font-bold select-all">{sub.subnet_id}</span>
                      <button
                        onClick={() => copyToClipboard(sub.subnet_id)}
                        className="text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Subnet ID"
                      >
                        {isCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* VPC ID */}
                  <td className="p-4 whitespace-nowrap">
                    <div className="flex items-center gap-1.5">
                      <span className="text-slate-400 select-all">{sub.vpc_id}</span>
                      <button
                        onClick={() => copyToClipboard(sub.vpc_id)}
                        className="text-slate-600 hover:text-slate-400 transition-colors"
                        title="Copy VPC ID"
                      >
                        {isVpcCopied ? (
                          <Check className="w-3 h-3 text-emerald-400" />
                        ) : (
                          <Copy className="w-3 h-3" />
                        )}
                      </button>
                    </div>
                  </td>

                  {/* CIDR Block */}
                  <td className="p-4 whitespace-nowrap text-slate-200 font-bold">
                    {sub.cidr_block}
                  </td>

                  {/* Availability Zone */}
                  <td className="p-4 whitespace-nowrap">
                    <span className="text-[10px] bg-slate-900 border border-slate-800 text-slate-300 px-2 py-1 rounded">
                      {sub.availability_zone}
                    </span>
                  </td>

                  {/* Available IP Address Count */}
                  <td className="p-4 whitespace-nowrap text-right text-slate-100 font-bold">
                    {sub.available_ip_count.toLocaleString()}
                  </td>

                  {/* State badge */}
                  <td className="p-4 whitespace-nowrap text-center">
                    <span className={`inline-flex px-2 py-0.5 rounded-md text-[10px] font-bold uppercase border ${
                      sub.state === 'available'
                        ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                        : 'bg-amber-500/5 text-amber-400 border-amber-500/10'
                    }`}>
                      {sub.state}
                    </span>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}
