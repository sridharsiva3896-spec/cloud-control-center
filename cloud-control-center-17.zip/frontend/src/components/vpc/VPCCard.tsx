import { Network, Tag, Copy, Check, ShieldCheck } from 'lucide-react';
import { useState } from 'react';
import { VpcInfo } from '../../types/vpc';

interface VPCCardProps {
  vpcs: VpcInfo[];
  loading: boolean;
}

/**
 * VPCCard Component - Displays a visually rich list of VPCs as responsive cards.
 * Includes quick tag expansion, copyable IDs, and default VPC badges.
 */
export default function VPCCard({ vpcs, loading }: VPCCardProps) {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string) => {
    navigator.clipboard.writeText(id);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const getVpcName = (vpc: VpcInfo) => {
    const nameTag = vpc.tags.find(t => t.Key === 'Name');
    return nameTag ? nameTag.Value : 'Unnamed VPC';
  };

  if (loading) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-8 flex flex-col items-center justify-center gap-3">
        <div className="w-6 h-6 border-2 border-amber-500 border-t-transparent rounded-full animate-spin" />
        <span className="text-xs font-mono text-slate-500">Querying VPC resources...</span>
      </div>
    );
  }

  if (vpcs.length === 0) {
    return (
      <div className="bg-[#0f1422] border border-slate-800 rounded-2xl p-12 text-center flex flex-col items-center justify-center gap-4 text-slate-500">
        <Network className="w-10 h-10 text-slate-600 stroke-[1.5]" />
        <div className="flex flex-col gap-1">
          <p className="text-xs font-mono font-bold text-slate-400">No VPCs Found</p>
          <p className="text-[11px] text-slate-500">
            No virtual private clouds match the current region or active filter parameters.
          </p>
        </div>
      </div>
    );
  }

  return (
    <div id="vpc-cards-grid" className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
      {vpcs.map((vpc) => {
        const vpcName = getVpcName(vpc);
        const isCopied = copiedId === vpc.vpc_id;

        return (
          <div 
            key={vpc.vpc_id}
            className="bg-[#0f1422] border border-slate-800 hover:border-slate-700/80 rounded-2xl p-5 hover:shadow-xl transition-all duration-200 flex flex-col justify-between relative group overflow-hidden"
          >
            {/* Ambient Background Glow on Hover */}
            <div className="absolute top-0 right-0 w-24 h-24 bg-amber-500/5 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

            <div>
              {/* Header with Name & State */}
              <div className="flex items-start justify-between gap-3 mb-4">
                <div className="space-y-1">
                  <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
                    {vpcName}
                  </h3>
                  <div className="flex items-center gap-1.5">
                    <span className="text-[11px] font-mono text-slate-300 select-all">
                      {vpc.vpc_id}
                    </span>
                    <button
                      onClick={() => copyToClipboard(vpc.vpc_id)}
                      className="text-slate-500 hover:text-slate-300 transition-colors"
                      title="Copy VPC ID"
                    >
                      {isCopied ? (
                        <Check className="w-3 h-3 text-emerald-400" />
                      ) : (
                        <Copy className="w-3 h-3" />
                      )}
                    </button>
                  </div>
                </div>

                <div className="flex flex-col items-end gap-1.5">
                  <span className={`px-2 py-0.5 rounded-md text-[10px] font-mono font-bold uppercase border ${
                    vpc.state === 'available'
                      ? 'bg-emerald-500/5 text-emerald-400 border-emerald-500/10'
                      : 'bg-amber-500/5 text-amber-400 border-amber-500/10'
                  }`}>
                    {vpc.state}
                  </span>
                  {vpc.is_default && (
                    <span className="inline-flex items-center gap-1 text-[9px] text-sky-400 bg-sky-500/5 px-2 py-0.5 rounded-md font-mono border border-sky-500/10 uppercase font-bold">
                      <ShieldCheck className="w-2.5 h-2.5" />
                      Default
                    </span>
                  )}
                </div>
              </div>

              {/* Body Parameters */}
              <div className="space-y-3 py-3 border-y border-slate-800/50">
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-500">CIDR Block</span>
                  <span className="font-bold text-slate-200">{vpc.cidr_block}</span>
                </div>
                <div className="flex items-center justify-between text-xs font-mono">
                  <span className="text-slate-500">Owner ID</span>
                  <span className="text-slate-400">{vpc.owner_id}</span>
                </div>
              </div>
            </div>

            {/* VPC Tags Section */}
            {vpc.tags.length > 0 ? (
              <div className="mt-4 pt-3 space-y-2">
                <span className="text-[10px] font-mono uppercase font-bold text-slate-500 flex items-center gap-1">
                  <Tag className="w-3 h-3" />
                  Tags ({vpc.tags.length})
                </span>
                <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto pr-1">
                  {vpc.tags.map((tag, idx) => (
                    <span 
                      key={idx}
                      className="text-[10px] font-mono bg-slate-900 border border-slate-800 text-slate-300 px-2 py-0.5 rounded"
                      title={`${tag.Key}: ${tag.Value}`}
                    >
                      <span className="text-slate-500">{tag.Key}=</span>
                      {tag.Value}
                    </span>
                  ))}
                </div>
              </div>
            ) : (
              <div className="mt-4 pt-3">
                <span className="text-[10px] font-mono uppercase text-slate-600 italic">
                  No custom tags associated
                </span>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
