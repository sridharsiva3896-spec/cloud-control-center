import React, { createContext, useState, useEffect, useCallback, useRef } from 'react';
import { useBackendStatus } from '../api/BackendStatusContext';
import { useRegion } from '../hooks/useRegion';
import { getStoredNotifications, saveNotifications } from '../services/notificationService';

export interface Notification {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'info' | 'warning' | 'error';
  timestamp: string;
  read: boolean;
  source: string;
}

export interface ToastItem {
  id: string;
  title: string;
  message: string;
  type: 'success' | 'error';
}

interface NotificationContextType {
  notifications: Notification[];
  toasts: ToastItem[];
  unreadCount: number;
  addNotification: (title: string, message: string, type: 'success' | 'info' | 'warning' | 'error', source: string) => void;
  markAsRead: (id: string) => void;
  markAllRead: () => void;
  clearAll: () => void;
  addToast: (title: string, message: string, type: 'success' | 'error') => void;
  removeToast: (id: string) => void;
}

export const NotificationContext = createContext<NotificationContextType | undefined>(undefined);

export const NotificationProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [notifications, setNotifications] = useState<Notification[]>(() => getStoredNotifications());
  const [toasts, setToasts] = useState<ToastItem[]>([]);

  const { status, awsState } = useBackendStatus();
  const { selectedRegion } = useRegion();

  // Track previous states to trigger automatic notifications on transitions
  const prevStatusRef = useRef<string | null>(null);
  const prevAWSConnectedRef = useRef<boolean | null>(null);
  const prevAWSErrorRef = useRef<string | null | undefined>(null);
  const prevRegionRef = useRef<string | null>(null);

  // Unread badge count
  const unreadCount = notifications.filter(n => !n.read).length;

  // Persist to local storage whenever notifications change
  useEffect(() => {
    saveNotifications(notifications);
  }, [notifications]);

  // Toast removal helper
  const removeToast = useCallback((id: string) => {
    setToasts(prev => prev.filter(t => t.id !== id));
  }, []);

  // Explicit Toast Trigger
  const addToast = useCallback((title: string, message: string, type: 'success' | 'error') => {
    const id = `${Date.now()}-${Math.random()}`;
    const newToast: ToastItem = { id, title, message, type };
    setToasts(prev => [...prev, newToast]);
    setTimeout(() => {
      removeToast(id);
    }, 5000);
  }, [removeToast]);

  // Main notification builder
  const addNotification = useCallback((
    title: string,
    message: string,
    type: 'success' | 'info' | 'warning' | 'error',
    source: string
  ) => {
    const newNotif: Notification = {
      id: `${Date.now()}-${Math.random().toString(36).substring(2, 9)}`,
      title,
      message,
      type,
      timestamp: new Date().toISOString(),
      read: false,
      source
    };

    setNotifications(prev => {
      // Keep only up to 100 notifications (newest first)
      const filtered = [newNotif, ...prev];
      return filtered.slice(0, 100);
    });

    // Auto-spawn Toast for Success/Error types
    if (type === 'success' || type === 'error') {
      addToast(title, message, type);
    }
  }, [addToast]);

  // --- AUTOMATIC NOTIFICATIONS ENGINE ---

  // 1. Backend Online / Offline
  useEffect(() => {
    if (prevStatusRef.current !== null) {
      if (status === 'connected' && prevStatusRef.current !== 'connected') {
        addNotification(
          'Backend Online',
          'Successfully connected to the Cloud Control Center API gateway.',
          'success',
          'System'
        );
      } else if (status === 'offline' && prevStatusRef.current !== 'offline') {
        addNotification(
          'Backend Offline',
          'Lost connection to the Cloud Control Center API gateway. Retrying...',
          'error',
          'System'
        );
      }
    }
    prevStatusRef.current = status;
  }, [status, addNotification]);

  // 2. AWS Connected / AWS Connection Failed
  useEffect(() => {
    // Connection success transition
    if (prevAWSConnectedRef.current !== null) {
      if (awsState.connected && !prevAWSConnectedRef.current) {
        addNotification(
          'AWS Connected',
          `STS session established successfully${awsState.accountId ? ` for account ${awsState.accountId}` : ''}.`,
          'success',
          'AWS Session'
        );
      }
    }
    prevAWSConnectedRef.current = awsState.connected;
  }, [awsState.connected, awsState.accountId, addNotification]);

  useEffect(() => {
    // AWS Connection Failure detection
    if (awsState.error && awsState.error !== prevAWSErrorRef.current) {
      addNotification(
        'AWS Connection Failed',
        awsState.error || 'Failed to authenticate secure session via AWS STS.',
        'error',
        'AWS Session'
      );
    }
    prevAWSErrorRef.current = awsState.error;
  }, [awsState.error, addNotification]);

  // 3. Region Changed
  useEffect(() => {
    if (prevRegionRef.current !== null && prevRegionRef.current !== selectedRegion) {
      addNotification(
        'Region Changed',
        `Active operations switched to AWS Region: ${selectedRegion}.`,
        'info',
        'Global Switcher'
      );
    }
    prevRegionRef.current = selectedRegion;
  }, [selectedRegion, addNotification]);

  // Context Actions
  const markAsRead = useCallback((id: string) => {
    setNotifications(prev =>
      prev.map(n => (n.id === id ? { ...n, read: true } : n))
    );
  }, []);

  const markAllRead = useCallback(() => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  }, []);

  const clearAll = useCallback(() => {
    setNotifications([]);
  }, []);

  return (
    <NotificationContext.Provider
      value={{
        notifications,
        toasts,
        unreadCount,
        addNotification,
        markAsRead,
        markAllRead,
        clearAll,
        addToast,
        removeToast
      }}
    >
      {children}
    </NotificationContext.Provider>
  );
};
