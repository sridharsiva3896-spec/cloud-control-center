import React, { createContext, useState, useEffect } from 'react';
import { getRegionsCatalog, updateAWSSessionRegion, RegionItem } from '../services/regionService';
import { useBackendStatus } from '../api/BackendStatusContext';

interface RegionContextType {
  selectedRegion: string;
  changeRegion: (region: string) => Promise<void>;
  regions: string[];
  regionDetails: RegionItem[];
  loadingRegions: boolean;
  regionsError: string | null;
  refreshRegions: () => Promise<void>;
}

export const RegionContext = createContext<RegionContextType | undefined>(undefined);

export const RegionProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { awsState, triggerRetry } = useBackendStatus();
  
  const [selectedRegion, setSelectedRegion] = useState<string>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem('selected_aws_region');
      return saved || 'ap-south-1';
    }
    return 'ap-south-1';
  });

  const [regions, setRegions] = useState<string[]>([]);
  const [regionDetails, setRegionDetails] = useState<RegionItem[]>([]);
  const [loadingRegions, setLoadingRegions] = useState<boolean>(true);
  const [regionsError, setRegionsError] = useState<string | null>(null);

  const fetchRegions = async () => {
    setLoadingRegions(true);
    setRegionsError(null);
    try {
      const catalog = await getRegionsCatalog();
      if (catalog && Array.isArray(catalog.regions)) {
        const sortedDetails = [...catalog.regions].sort((a, b) => a.code.localeCompare(b.code));
        const sortedCodes = sortedDetails.map(r => r.code);
        setRegionDetails(sortedDetails);
        setRegions(sortedCodes);

        const hasApSouth = sortedCodes.includes('ap-south-1');
        const defaultReg = hasApSouth ? 'ap-south-1' : (catalog.defaultRegion || 'us-east-1');

        const saved = localStorage.getItem('selected_aws_region');
        if (!saved || !sortedCodes.includes(saved)) {
          setSelectedRegion(defaultReg);
          localStorage.setItem('selected_aws_region', defaultReg);
        } else {
          setSelectedRegion(saved);
        }
      }
    } catch (error: any) {
      console.error('Failed to fetch AWS regions catalog:', error);
      setRegionsError(error.message || 'Failed to load AWS regions.');
    } finally {
      setLoadingRegions(false);
    }
  };

  useEffect(() => {
    fetchRegions();
  }, []);

  const changeRegion = async (region: string) => {
    setSelectedRegion(region);
    localStorage.setItem('selected_aws_region', region);

    if (awsState.connected) {
      try {
        await updateAWSSessionRegion(region);
        await triggerRetry();
        // Dispatch event to force other pages to reload and query updated regional clients
        window.dispatchEvent(new Event('aws-login'));
      } catch (err) {
        console.error('Failed to update active session region context:', err);
      }
    }
  };

  return (
    <RegionContext.Provider value={{ 
      selectedRegion, 
      changeRegion, 
      regions, 
      regionDetails,
      loadingRegions, 
      regionsError,
      refreshRegions: fetchRegions 
    }}>
      {children}
    </RegionContext.Provider>
  );
};
