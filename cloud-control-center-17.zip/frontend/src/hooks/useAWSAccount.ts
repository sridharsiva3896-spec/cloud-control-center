import { useState, useEffect, useCallback } from 'react';
import { getAWSAccountOverview } from '../services/accountService';
import { AWSAccount } from '../types/account';

/**
 * Reusable React Hook to handle loading and refetching of AWS Account Overview information.
 */
export function useAWSAccount() {
  const [account, setAccount] = useState<AWSAccount | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchAccount = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await getAWSAccountOverview();
      setAccount(data);
      if (!data.connected) {
        setError(data.message || 'AWS Account not connected. Please verify your credentials.');
      }
    } catch (err: any) {
      setError(err.message || 'Failed to establish connection to secure API gateway.');
      setAccount({
        connected: false,
        message: 'Network error querying AWS Account overview.'
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAccount();
  }, [fetchAccount]);

  return {
    account,
    loading,
    error,
    refetch: fetchAccount
  };
}
