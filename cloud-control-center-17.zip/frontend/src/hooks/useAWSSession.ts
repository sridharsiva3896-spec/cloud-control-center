import { useState, useEffect, useCallback, useRef } from 'react';
import { getAWSSession } from '../services/sessionService';
import { AWSSession } from '../types/aws';

/**
 * Reusable React Hook to retrieve and manage the active AWS STS session state.
 * Automatically checks connection status on mount and provides manual trigger handlers.
 */
export function useAWSSession() {
  const [session, setSession] = useState<AWSSession | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchingRef = useRef<boolean>(false);

  const checkSession = useCallback(async (force = false) => {
    if (!force && fetchingRef.current) {
      return;
    }
    fetchingRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const data = await getAWSSession();
      setSession(data);
      if (!data.connected) {
        setError(data.message || 'AWS credentials not configured.');
      }
    } catch (err: any) {
      setError(err.message || 'Unable to establish STS connection to the server.');
      setSession({
        connected: false,
        message: 'Network error connecting to API session server.'
      });
    } finally {
      setLoading(false);
      fetchingRef.current = false;
    }
  }, []);

  useEffect(() => {
    checkSession();
  }, [checkSession]);

  return {
    session,
    loading,
    error,
    refetch: checkSession
  };
}
