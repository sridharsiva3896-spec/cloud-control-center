import { useState, useEffect, useCallback, useRef } from 'react';
import { getCloudTrailEvents } from '../services/cloudTrailService';
import { CloudTrailResponse } from '../types/cloudtrail';
import { useRegion } from './useRegion';
import { useNotification } from './useNotification';

/**
 * Custom hook to manage fetching and reactive updates of AWS CloudTrail audit logs.
 */
export function useCloudTrail() {
  const { selectedRegion } = useRegion();
  const { addNotification } = useNotification();
  const [data, setData] = useState<CloudTrailResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const prevHasErrorRef = useRef<boolean>(false);

  const fetchEvents = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getCloudTrailEvents(selectedRegion);
      setData(response);
      
      let errorMsg: string | null = null;
      if (response.enabled === false && response.message) {
        errorMsg = response.message;
      } else if (response.error) {
        errorMsg = response.error;
      }

      if (errorMsg) {
        setError(errorMsg);
        if (!prevHasErrorRef.current) {
          addNotification('CloudTrail Unavailable', errorMsg, 'warning', 'CloudTrail');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
      }
    } catch (err: any) {
      const catchMsg = err.message || 'Failed to establish connection to CloudTrail API gateway.';
      setError(catchMsg);
      if (!prevHasErrorRef.current) {
        addNotification('CloudTrail Unavailable', catchMsg, 'error', 'CloudTrail');
        prevHasErrorRef.current = true;
      }
      setData({
        summary: { total_events: 0, unique_users: 0, event_sources: 0 },
        events: [],
        enabled: false,
        error: 'Network connectivity error.'
      });
    } finally {
      setLoading(false);
    }
  }, [selectedRegion, addNotification]);

  useEffect(() => {
    fetchEvents();
  }, [fetchEvents]);

  return {
    data,
    loading,
    error,
    refetch: fetchEvents
  };
}
