import { useState, useEffect, useCallback } from 'react';
import { getCloudWatchMetrics } from '../services/cloudwatchService';
import { CloudWatchResponse } from '../types/cloudwatch';
import { useRegion } from './useRegion';

/**
 * Custom hook to manage fetching and reactive updates of AWS CloudWatch performance telemetries.
 */
export function useCloudWatch() {
  const { selectedRegion } = useRegion();
  const [data, setData] = useState<CloudWatchResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchMetrics = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getCloudWatchMetrics(selectedRegion);
      setData(response);
      
      if (response.error) {
        setError(response.error);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to establish connection to CloudWatch telemetry gateway.');
      setData({
        summary: { monitored_instances: 0, metrics_collected: 0 },
        instances: [],
        error: 'Network connectivity error.'
      });
    } finally {
      setLoading(false);
    }
  }, [selectedRegion]);

  useEffect(() => {
    fetchMetrics();
  }, [fetchMetrics]);

  return {
    data,
    loading,
    error,
    refetch: fetchMetrics
  };
}
