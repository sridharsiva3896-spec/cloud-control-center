import { useState, useCallback, useRef } from 'react';
import { getCostExplorerData } from '../services/costExplorerService';
import { CostExplorerResponse } from '../types/cost';
import { useNotification } from './useNotification';

/**
 * Custom hook to manage fetching and reactive updates of AWS Cost Explorer analytics.
 */
export function useCostExplorer() {
  const { addNotification } = useNotification();
  const [data, setData] = useState<CostExplorerResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  const prevHasErrorRef = useRef<boolean>(false);
  const fetchingRef = useRef<boolean>(false);

  const fetchCostData = useCallback(async (force = false) => {
    if (!force && fetchingRef.current) {
      return;
    }
    fetchingRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const response = await getCostExplorerData();
      setData(response);
      
      let errorMsg: string | null = null;
      if (response.enabled === false && response.message) {
        errorMsg = response.message;
      } else if (response.error) {
        errorMsg = response.error;
      }

      if (errorMsg) {
        setError(errorMsg);
        if (!prevHasErrorRef.current) {
          addNotification('Cost Explorer Unavailable', errorMsg, 'warning', 'Cost Explorer');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
      }
    } catch (err: any) {
      const catchMsg = err.message || 'Failed to establish connection to Cost Explorer API gateway.';
      setError(catchMsg);
      if (!prevHasErrorRef.current) {
        addNotification('Cost Explorer Unavailable', catchMsg, 'error', 'Cost Explorer');
        prevHasErrorRef.current = true;
      }
      setData({
        summary: { current_month_cost: 0.0, previous_month_cost: 0.0, currency: 'USD' },
        services: [],
        daily_trend: [],
        enabled: false,
        error: 'Network connectivity error.'
      });
    } finally {
      setLoading(false);
      fetchingRef.current = false;
    }
  }, [addNotification]);

  return {
    data,
    loading,
    error,
    refetch: fetchCostData
  };
}
