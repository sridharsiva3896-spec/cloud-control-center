import { useState, useEffect, useCallback, useRef } from 'react';
import { getEC2Instances } from '../services/ec2Service';
import { getS3Buckets } from '../services/s3Service';
import { getIAMOverview } from '../services/iamService';
import { EC2Response } from '../types/ec2';
import { S3Response } from '../types/s3';
import { IAMResponse } from '../types/iam';
import { useRegion } from './useRegion';

export interface DashboardSummaryState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

export function useDashboardSummary() {
  const { selectedRegion } = useRegion();
  
  const [ec2, setEc2] = useState<DashboardSummaryState<EC2Response>>({
    data: null,
    loading: true,
    error: null,
  });

  const [s3, setS3] = useState<DashboardSummaryState<S3Response>>({
    data: null,
    loading: true,
    error: null,
  });

  const [iam, setIam] = useState<DashboardSummaryState<IAMResponse>>({
    data: null,
    loading: true,
    error: null,
  });

  const ec2FetchingRef = useRef<string | null>(null);
  const s3FetchingRef = useRef<boolean>(false);
  const iamFetchingRef = useRef<boolean>(false);

  const fetchEC2 = useCallback(async (force = false) => {
    if (!force && ec2FetchingRef.current === selectedRegion) {
      return;
    }
    ec2FetchingRef.current = selectedRegion;
    setEc2(prev => ({ ...prev, loading: true, error: null }));
    try {
      const data = await getEC2Instances(selectedRegion);
      setEc2({ data, loading: false, error: data.error || null });
    } catch (err: any) {
      setEc2({
        data: null,
        loading: false,
        error: err.message || 'Failed to fetch EC2 virtual machine instances.'
      });
    } finally {
      if (ec2FetchingRef.current === selectedRegion) {
        ec2FetchingRef.current = null;
      }
    }
  }, [selectedRegion]);

  const fetchS3 = useCallback(async (force = false) => {
    if (!force && s3FetchingRef.current) {
      return;
    }
    s3FetchingRef.current = true;
    setS3(prev => ({ ...prev, loading: true, error: null }));
    try {
      const data = await getS3Buckets();
      setS3({ data, loading: false, error: data.error || null });
    } catch (err: any) {
      setS3({
        data: null,
        loading: false,
        error: err.message || 'Failed to fetch S3 storage buckets.'
      });
    } finally {
      s3FetchingRef.current = false;
    }
  }, []);

  const fetchIAM = useCallback(async (force = false) => {
    if (!force && iamFetchingRef.current) {
      return;
    }
    iamFetchingRef.current = true;
    setIam(prev => ({ ...prev, loading: true, error: null }));
    try {
      const data = await getIAMOverview();
      const globalError = data.errors?.global || data.error || null;
      setIam({ data, loading: false, error: globalError });
    } catch (err: any) {
      setIam({
        data: null,
        loading: false,
        error: err.message || 'Failed to fetch IAM security profiles.'
      });
    } finally {
      iamFetchingRef.current = false;
    }
  }, []);

  const refetchAll = useCallback((force = true) => {
    fetchEC2(force);
    fetchS3(force);
    fetchIAM(force);
  }, [fetchEC2, fetchS3, fetchIAM]);

  // Handle automatic reactive fetch of EC2 whenever region changes
  useEffect(() => {
    fetchEC2();
  }, [fetchEC2]);

  // Fetch static global resources on mount
  useEffect(() => {
    fetchS3();
    fetchIAM();
  }, [fetchS3, fetchIAM]);

  return {
    ec2,
    s3,
    iam,
    refetchAll,
    refetchEC2: fetchEC2,
    refetchS3: fetchS3,
    refetchIAM: fetchIAM
  };
}
