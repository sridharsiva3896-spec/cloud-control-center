import { useState, useEffect, useCallback, useRef } from 'react';
import { getEBSMonitoring } from '../services/ebsService';
import { EBSResponse } from '../types/ebs';
import { useRegion } from './useRegion';
import { useNotification } from './useNotification';

/**
 * Custom hook to fetch and synchronize current active AWS EBS storage volume and snapshot telemetry.
 */
export function useEBS() {
  const { selectedRegion } = useRegion();
  const { addNotification } = useNotification();
  const [data, setData] = useState<EBSResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const prevHasErrorRef = useRef<boolean>(false);

  const fetchEBSData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getEBSMonitoring(selectedRegion);
      setData(response);
      
      if (response.error) {
        setError(response.error);
        if (!prevHasErrorRef.current) {
          addNotification('EBS Monitoring Issue', response.error, 'warning', 'EBS');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to establish connection to AWS EBS block storage monitoring endpoint.';
      setError(errorMsg);
      if (!prevHasErrorRef.current) {
        addNotification('EBS Connection Error', errorMsg, 'error', 'EBS');
        prevHasErrorRef.current = true;
      }
    } finally {
      setLoading(false);
    }
  }, [selectedRegion, addNotification]);

  useEffect(() => {
    fetchEBSData();
  }, [fetchEBSData]);

  return {
    data,
    loading,
    error,
    refetch: fetchEBSData
  };
}
