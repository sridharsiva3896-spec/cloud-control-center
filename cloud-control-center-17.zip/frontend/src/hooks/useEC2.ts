import { useState, useEffect, useCallback } from 'react';
import { getEC2Instances } from '../services/ec2Service';
import { EC2Response } from '../types/ec2';
import { useRegion } from './useRegion';

/**
 * Reusable React Hook to handle loading, polling, error catching, and refetching of EC2 Instance summaries.
 */
export function useEC2() {
  const { selectedRegion } = useRegion();
  const [data, setData] = useState<EC2Response | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchEC2 = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getEC2Instances(selectedRegion);
      setData(response);
      if (response.error) {
        setError(response.error);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to establish connection to secure EC2 API gateway.');
      setData({
        summary: { total: 0, running: 0, stopped: 0 },
        instances: [],
        error: 'Network connectivity error.'
      });
    } finally {
      setLoading(false);
    }
  }, [selectedRegion]);

  useEffect(() => {
    fetchEC2();
  }, [fetchEC2]);

  return {
    data,
    loading,
    error,
    refetch: fetchEC2
  };
}
