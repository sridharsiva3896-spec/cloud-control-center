import { useState, useEffect, useCallback } from 'react';
import { getIAMOverview } from '../services/iamService';
import { IAMResponse } from '../types/iam';

/**
 * Custom hook to manage fetching and reactive updates of AWS IAM credentials,
 * roles, groups, and managed policy rules.
 */
export function useIAM() {
  const [data, setData] = useState<IAMResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchIAM = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getIAMOverview();
      setData(response);
      
      // If a global initialization/handshake error is present, set it as the error
      if (response.errors && response.errors.global) {
        setError(response.errors.global);
      } else if (response.error) {
        setError(response.error);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to establish connection to secure IAM API gateway.');
      setData({
        summary: { users: 0, groups: 0, roles: 0, policies: 0 },
        users: [],
        groups: [],
        roles: [],
        policies: [],
        error: 'Network connectivity error.'
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchIAM();
  }, [fetchIAM]);

  return {
    data,
    loading,
    error,
    refetch: fetchIAM
  };
}
