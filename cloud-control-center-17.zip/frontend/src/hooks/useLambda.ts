import { useState, useEffect, useCallback, useRef } from 'react';
import { getLambdaMonitoring } from '../services/lambdaService';
import { LambdaResponse } from '../types/lambda';
import { useRegion } from './useRegion';
import { useNotification } from './useNotification';

/**
 * Custom hook to fetch and synchronize current active AWS Lambda function telemetry.
 */
export function useLambda() {
  const { selectedRegion } = useRegion();
  const { addNotification } = useNotification();
  const [data, setData] = useState<LambdaResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const prevHasErrorRef = useRef<boolean>(false);

  const fetchLambdaData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getLambdaMonitoring(selectedRegion);
      setData(response);
      
      if (response.error) {
        setError(response.error);
        if (!prevHasErrorRef.current) {
          addNotification('Lambda Monitoring Issue', response.error, 'warning', 'Lambda');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to establish connection to AWS Lambda telemetry endpoint.';
      setError(errorMsg);
      if (!prevHasErrorRef.current) {
        addNotification('Lambda Connection Error', errorMsg, 'error', 'Lambda');
        prevHasErrorRef.current = true;
      }
    } finally {
      setLoading(false);
    }
  }, [selectedRegion, addNotification]);

  useEffect(() => {
    fetchLambdaData();
  }, [fetchLambdaData]);

  return {
    data,
    loading,
    error,
    refetch: fetchLambdaData
  };
}
