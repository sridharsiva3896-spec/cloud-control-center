import { useState, useEffect, useCallback, useRef } from 'react';
import { getLoadBalancersMonitoring } from '../services/loadBalancerService';
import { LoadBalancerResponse } from '../types/loadBalancer';
import { useRegion } from './useRegion';
import { useNotification } from './useNotification';

/**
 * Custom hook to fetch and synchronize AWS Load Balancer monitoring telemetry.
 */
export function useLoadBalancers() {
  const { selectedRegion } = useRegion();
  const { addNotification } = useNotification();
  const [data, setData] = useState<LoadBalancerResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const prevHasErrorRef = useRef<boolean>(false);
  const lastFetchedRegion = useRef<string>('');

  const fetchLBData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getLoadBalancersMonitoring(selectedRegion);
      setData(response);
      
      if (response.error) {
        setError(response.error);
        if (!prevHasErrorRef.current || lastFetchedRegion.current !== selectedRegion) {
          const isAccessDenied = response.error.toLowerCase().includes('access denied') || 
                                 response.error.toLowerCase().includes('unauthorized') ||
                                 response.error.toLowerCase().includes('credentials');
          const title = isAccessDenied ? 'API Access Denied' : 'Load Balancer Monitoring Issue';
          addNotification(title, response.error, 'warning', 'ELB');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
        
        // Success notification
        addNotification('Load Balancer Refreshed', `Successfully fetched Load Balancer telemetry for ${selectedRegion}.`, 'info', 'ELB');
        
        if (!response.load_balancers || response.load_balancers.length === 0) {
          addNotification('No Load Balancers Found', `No Load Balancers found in region ${selectedRegion}.`, 'warning', 'ELB');
        }
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to establish connection to Load Balancer telemetry endpoint.';
      setError(errorMsg);
      if (!prevHasErrorRef.current || lastFetchedRegion.current !== selectedRegion) {
        addNotification('Connection Error', errorMsg, 'error', 'ELB');
        prevHasErrorRef.current = true;
      }
    } finally {
      setLoading(false);
      lastFetchedRegion.current = selectedRegion;
    }
  }, [selectedRegion, addNotification]);

  useEffect(() => {
    fetchLBData();
  }, [fetchLBData]);

  return {
    data,
    loading,
    error,
    refetch: fetchLBData
  };
}
