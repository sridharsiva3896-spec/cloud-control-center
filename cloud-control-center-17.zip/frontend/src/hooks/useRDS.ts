import { useState, useEffect, useCallback, useRef } from 'react';
import { getRDSMonitoring } from '../services/rdsService';
import { RDSResponse } from '../types/rds';
import { useRegion } from './useRegion';
import { useNotification } from './useNotification';

/**
 * Custom hook to fetch and synchronize current active AWS RDS database instances and clusters telemetry.
 */
export function useRDS() {
  const { selectedRegion } = useRegion();
  const { addNotification } = useNotification();
  const [data, setData] = useState<RDSResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const prevHasErrorRef = useRef<boolean>(false);

  const fetchRDSData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getRDSMonitoring(selectedRegion);
      setData(response);
      
      if (response.error) {
        setError(response.error);
        if (!prevHasErrorRef.current) {
          addNotification('RDS Monitoring Issue', response.error, 'warning', 'RDS');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to establish connection to AWS RDS database monitoring endpoint.';
      setError(errorMsg);
      if (!prevHasErrorRef.current) {
        addNotification('RDS Connection Error', errorMsg, 'error', 'RDS');
        prevHasErrorRef.current = true;
      }
    } finally {
      setLoading(false);
    }
  }, [selectedRegion, addNotification]);

  useEffect(() => {
    fetchRDSData();
  }, [fetchRDSData]);

  return {
    data,
    loading,
    error,
    refetch: fetchRDSData
  };
}
