import { useContext } from 'react';
import { RegionContext } from '../context/RegionContext';

/**
 * Custom hook to safely consume the RegionContext.
 * Ensures the context is only used within a RegionProvider scope.
 */
export function useRegion() {
  const context = useContext(RegionContext);
  if (context === undefined) {
    throw new Error('useRegion must be used within a RegionProvider');
  }
  return context;
}
