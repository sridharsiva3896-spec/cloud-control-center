import { useState, useEffect, useCallback } from 'react';
import { getS3Buckets } from '../services/s3Service';
import { S3Response } from '../types/s3';

/**
 * Reusable React Hook to handle loading, error trapping, and manual updates of S3 bucket list.
 */
export function useS3() {
  const [data, setData] = useState<S3Response | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const fetchS3 = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getS3Buckets();
      setData(response);
      if (response.error) {
        setError(response.error);
      }
    } catch (err: any) {
      setError(err.message || 'Failed to establish connection to secure S3 API gateway.');
      setData({
        summary: { total_buckets: 0 },
        buckets: [],
        error: 'Network connectivity error.'
      });
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchS3();
  }, [fetchS3]);

  return {
    data,
    loading,
    error,
    refetch: fetchS3
  };
}
