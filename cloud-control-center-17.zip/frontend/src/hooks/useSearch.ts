import { useState, useEffect, useCallback } from 'react';
import { searchAWS } from '../services/searchService';
import { SearchResponse } from '../types/search';
import { useNotification } from './useNotification';

const RECENT_SEARCHES_KEY = 'cloud_control_recent_searches';

export function useSearch(initialQuery: string = '') {
  const { addNotification } = useNotification();
  const [query, setQuery] = useState<string>(initialQuery);
  const [results, setResults] = useState<SearchResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [recentSearches, setRecentSearches] = useState<string[]>([]);

  // Load recent searches from localStorage
  useEffect(() => {
    try {
      const saved = localStorage.getItem(RECENT_SEARCHES_KEY);
      if (saved) {
        setRecentSearches(JSON.parse(saved));
      }
    } catch (e) {
      console.error('Failed to load recent searches', e);
    }
  }, []);

  // Save recent searches to localStorage
  const addRecentSearch = useCallback((searchQuery: string) => {
    const trimmed = searchQuery.trim();
    if (!trimmed) return;

    setRecentSearches((prev) => {
      // Remove if already exists, then prepend, then slice to max 10
      const filtered = prev.filter((s) => s.toLowerCase() !== trimmed.toLowerCase());
      const updated = [trimmed, ...filtered].slice(0, 10);
      try {
        localStorage.setItem(RECENT_SEARCHES_KEY, JSON.stringify(updated));
      } catch (e) {
        console.error('Failed to save recent searches', e);
      }
      return updated;
    });
  }, []);

  const clearRecentSearches = useCallback(() => {
    setRecentSearches([]);
    try {
      localStorage.removeItem(RECENT_SEARCHES_KEY);
    } catch (e) {
      console.error('Failed to clear recent searches', e);
    }
  }, []);

  const performSearch = useCallback(async (searchQuery: string) => {
    const trimmed = searchQuery.trim();
    if (!trimmed) {
      setResults(null);
      setError(null);
      return;
    }

    setLoading(true);
    setError(null);
    try {
      const response = await searchAWS(trimmed);
      setResults(response);
      addNotification(
        'Search Completed',
        `Global search for "${trimmed}" finished successfully. Found ${response.results?.length || 0} matching AWS resources.`,
        'success',
        'Global Search'
      );
    } catch (err: any) {
      const errMsg = err.message || 'An error occurred while scanning AWS resources.';
      setError(errMsg);
      setResults(null);
      addNotification(
        'Search Failed',
        `Global search for "${trimmed}" failed: ${errMsg}`,
        'error',
        'Global Search'
      );
    } finally {
      setLoading(false);
    }
  }, [addNotification]);

  // For instant search page load or explicit search action
  useEffect(() => {
    if (initialQuery) {
      performSearch(initialQuery);
    }
  }, [initialQuery, performSearch]);

  return {
    query,
    setQuery,
    results,
    loading,
    error,
    recentSearches,
    addRecentSearch,
    clearRecentSearches,
    performSearch
  };
}
