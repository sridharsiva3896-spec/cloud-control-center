import { useState, useEffect, useCallback, useRef } from 'react';
import { getSecurityReport } from '../services/securityService';
import { SecurityReportResponse } from '../types/security';
import { useNotification } from './useNotification';
import { useBackendStatus } from '../api/BackendStatusContext';

/**
 * Custom hook to manage retrieving and caching AWS security posture indicators.
 */
export function useSecurity() {
  const { awsState } = useBackendStatus();
  const { connected } = awsState;
  const { addNotification } = useNotification();
  const [data, setData] = useState<SecurityReportResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  const prevHasErrorRef = useRef<boolean>(false);
  const prevHasFindingsRef = useRef<boolean>(false);
  const fetchingRef = useRef<boolean>(false);

  const fetchSecurityData = useCallback(async (force = false) => {
    if (!force && fetchingRef.current) {
      return;
    }
    fetchingRef.current = true;
    setLoading(true);
    setError(null);
    try {
      const response = await getSecurityReport();
      setData(response);
      
      let errorMsg: string | null = null;
      if (response.enabled === false && response.message) {
        errorMsg = response.message;
      } else if (response.error) {
        errorMsg = response.error;
      }

      if (errorMsg) {
        setError(errorMsg);
        if (!prevHasErrorRef.current) {
          addNotification('Security Audit Error', errorMsg, 'error', 'Security');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;

        // Check for security findings
        const findingsCount = (response.summary?.critical || 0) + (response.summary?.warning || 0);
        if (findingsCount > 0) {
          if (!prevHasFindingsRef.current) {
            addNotification(
              'Security Findings Detected',
              `AWS Security Scan detected ${findingsCount} compliance alerts (${response.summary.critical} critical, ${response.summary.warning} warning).`,
              response.summary.critical > 0 ? 'error' : 'warning',
              'Security'
            );
            prevHasFindingsRef.current = true;
          }
        } else {
          prevHasFindingsRef.current = false;
        }
      }
    } catch (err: any) {
      const catchMsg = err.message || 'Failed to establish connection to the Security audit API gateway.';
      setError(catchMsg);
      if (!prevHasErrorRef.current) {
        addNotification('Security Audit Error', catchMsg, 'error', 'Security');
        prevHasErrorRef.current = true;
      }
      setData({
        summary: { security_score: 0, critical: 1, warning: 0, passed: 0 },
        checks: {
          root_account: { status: 'CRITICAL', root_account_used: true, details: 'Network error connecting to API.' },
          mfa: { status: 'WARNING', users_without_mfa: [], total_users: 0 },
          access_keys: { status: 'PASSED', old_keys: [] },
          public_buckets: { status: 'PASSED', public_buckets: [], total_buckets: 0 },
          password_policy: { status: 'PASSED', configured: false, minimum_length: 8, require_symbols: false, require_numbers: false, require_uppercase: false, require_lowercase: false, max_password_age: 0 }
        },
        enabled: false,
        error: 'Network connectivity error.'
      });
    } finally {
      setLoading(false);
      fetchingRef.current = false;
    }
  }, [addNotification]);

  useEffect(() => {
    if (!connected) {
      setData(null);
      setError(null);
      setLoading(false);
      prevHasErrorRef.current = false;
      prevHasFindingsRef.current = false;
      return;
    }
    fetchSecurityData();
  }, [connected, fetchSecurityData]);

  return {
    data,
    loading,
    error,
    refetch: fetchSecurityData
  };
}
