import { useState, useEffect, useCallback, useRef } from 'react';
import { getTagExplorer } from '../services/tagService';
import { TagResponse } from '../types/tag';
import { useRegion } from './useRegion';
import { useNotification } from './useNotification';

/**
 * Custom hook to interact with AWS Resource Tag Explorer telemetry.
 */
export function useTags() {
  const { selectedRegion } = useRegion();
  const { addNotification } = useNotification();
  const [data, setData] = useState<TagResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const prevHasErrorRef = useRef<boolean>(false);

  // Allow filter parameters
  const [filters, setFilters] = useState({
    service: '',
    tag_key: '',
    tag_value: ''
  });

  const fetchTags = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getTagExplorer({
        region: selectedRegion,
        service: filters.service,
        tag_key: filters.tag_key,
        tag_value: filters.tag_value
      });
      setData(response);

      if (response.error) {
        setError(response.error);
        if (!prevHasErrorRef.current) {
          addNotification('Tag Explorer Warning', response.error, 'warning', 'Tags');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to establish connection to AWS Tag API service.';
      setError(errorMsg);
      if (!prevHasErrorRef.current) {
        addNotification('Tag Explorer Connection Error', errorMsg, 'error', 'Tags');
        prevHasErrorRef.current = true;
      }
    } finally {
      setLoading(false);
    }
  }, [selectedRegion, filters, addNotification]);

  useEffect(() => {
    fetchTags();
  }, [fetchTags]);

  return {
    data,
    loading,
    error,
    filters,
    setFilters,
    refetch: fetchTags
  };
}
