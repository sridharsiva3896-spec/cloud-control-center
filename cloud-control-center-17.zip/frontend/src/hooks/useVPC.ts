import { useState, useEffect, useCallback, useRef } from 'react';
import { getVpcMonitoring } from '../services/vpcService';
import { VpcResponse } from '../types/vpc';
import { useRegion } from './useRegion';
import { useNotification } from './useNotification';

/**
 * Custom hook to fetch and synchronize current active AWS VPC structures and status elements.
 */
export function useVPC() {
  const { selectedRegion } = useRegion();
  const { addNotification } = useNotification();
  const [data, setData] = useState<VpcResponse | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const prevHasErrorRef = useRef<boolean>(false);

  const fetchVpcData = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await getVpcMonitoring(selectedRegion);
      setData(response);
      
      if (response.error) {
        setError(response.error);
        if (!prevHasErrorRef.current) {
          addNotification('VPC Monitoring Issue', response.error, 'warning', 'VPC');
          prevHasErrorRef.current = true;
        }
      } else {
        prevHasErrorRef.current = false;
      }
    } catch (err: any) {
      const errorMsg = err.message || 'Failed to establish connection to VPC telemetry endpoint.';
      setError(errorMsg);
      if (!prevHasErrorRef.current) {
        addNotification('VPC Connection Error', errorMsg, 'error', 'VPC');
        prevHasErrorRef.current = true;
      }
    } finally {
      setLoading(false);
    }
  }, [selectedRegion, addNotification]);

  useEffect(() => {
    fetchVpcData();
  }, [fetchVpcData]);

  return {
    data,
    loading,
    error,
    refetch: fetchVpcData
  };
}
