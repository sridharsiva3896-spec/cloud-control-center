import { useState, useEffect, ReactNode } from 'react';
import Sidebar from '../components/common/Sidebar';
import TopNavbar from '../components/common/TopNavbar';
import { useBackendStatus } from '../api/BackendStatusContext';
import { ToastNotification } from '../components/ToastNotification';
import { 
  Info, 
  CheckCircle, 
  FileCode2, 
  Lock,
  AlertTriangle,
  Loader2
} from 'lucide-react';
import { useRegion } from '../hooks/useRegion';

interface MainLayoutProps {
  children: ReactNode;
}

/**
 * MainLayout provides the structural backbone of the Cloud Control Center.
 * Arranges the Sidebar, TopNavbar, and the scrollable content view.
 */
export default function MainLayout({ children }: MainLayoutProps) {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const [showConnectModal, setShowConnectModal] = useState(false);
  const [isDarkTheme, setIsDarkTheme] = useState(true);
  const { awsState, triggerConnectAWS } = useBackendStatus();

  const { 
    selectedRegion, 
    changeRegion, 
    regionDetails, 
    loadingRegions, 
    regionsError, 
    refreshRegions 
  } = useRegion();

  // Form states for explicit AWS connection
  const [accessKeyId, setAccessKeyId] = useState('');
  const [secretAccessKey, setSecretAccessKey] = useState('');
  const [sessionToken, setSessionToken] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitError, setSubmitError] = useState<string | null>(null);

  const handleMenuToggle = () => {
    setIsSidebarOpen(!isSidebarOpen);
  };

  const handleConnectClick = () => {
    // Reset any previous form values on open
    setAccessKeyId('');
    setSecretAccessKey('');
    setSessionToken('');
    setSubmitError(null);
    setShowConnectModal(true);
  };

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!accessKeyId.trim() || !secretAccessKey.trim()) {
      setSubmitError('Access Key ID and Secret Access Key are required.');
      return;
    }
    setIsSubmitting(true);
    setSubmitError(null);
    try {
      const res = await triggerConnectAWS({
        aws_access_key_id: accessKeyId.trim(),
        aws_secret_access_key: secretAccessKey.trim(),
        aws_session_token: sessionToken.trim() || undefined,
        region_name: selectedRegion.trim() || 'us-east-1'
      });
      if (res.connected) {
        setShowConnectModal(false);
      } else {
        setSubmitError(res.message || 'AWS credentials verification failed. Check credentials and retry.');
      }
    } catch (err: any) {
      setSubmitError(err.message || 'An unexpected error occurred during connection.');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleThemeToggle = () => {
    setIsDarkTheme(!isDarkTheme);
  };

  useEffect(() => {
    const handleOpenModal = () => handleConnectClick();
    window.addEventListener('open-connect-modal', handleOpenModal);
    return () => {
      window.removeEventListener('open-connect-modal', handleOpenModal);
    };
  }, []);

  return (
    <div className={`h-screen flex flex-col font-sans overflow-hidden transition-colors duration-200 ${
      isDarkTheme ? 'bg-[#0b0f19] text-slate-100' : 'bg-slate-50 text-slate-900'
    }`}>
      
      {/* Decorative background vectors in Dark Mode */}
      {isDarkTheme && (
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_0%,#000_70%,transparent_100%)] opacity-20 pointer-events-none"></div>
      )}

      {/* High-level environment bar */}
      <div className={`border-b ${
        isDarkTheme ? 'bg-slate-900/60 border-slate-800/80 text-slate-400' : 'bg-slate-200/80 border-slate-300/80 text-slate-600'
      } px-4 md:px-6 py-2.5 backdrop-blur z-20`}>
        <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-2 text-xs">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
            <span className="font-mono font-medium">Local Scaffolding Operational</span>
          </div>
          <div className="flex items-center gap-4 font-mono text-[11px] opacity-75">
            <span>Vite • FastAPI • Python 3.11</span>
            <span className="hidden sm:inline">|</span>
            <span>No AWS Charges Incurred</span>
          </div>
        </div>
      </div>

      {/* Main Structural Layout Grid */}
      <div className="flex-1 flex overflow-hidden">
        
        {/* Responsive Sidebar */}
        <Sidebar 
          isOpen={isSidebarOpen} 
          onClose={() => setIsSidebarOpen(false)} 
        />

        {/* Viewport Frame */}
        <div className="flex-1 flex flex-col min-w-0 overflow-hidden h-full">
          
          <TopNavbar 
            onMenuToggle={handleMenuToggle} 
            onConnectClick={handleConnectClick}
            isDarkTheme={isDarkTheme}
            onThemeToggle={handleThemeToggle}
          />

          {/* Scrollable container for Content + Footer */}
          <div className="flex-1 overflow-y-auto flex flex-col justify-between custom-scrollbar">
            {/* Core Content Area */}
            <main className="flex-1 px-4 py-8 md:px-8 max-w-7xl mx-auto w-full">
              {children}
            </main>

            {/* Footer Bar */}
            <footer className={`border-t py-6 px-4 md:px-8 ${
              isDarkTheme ? 'bg-slate-950/40 border-slate-900/80 text-slate-500' : 'bg-slate-100 border-slate-200 text-slate-500'
            }`}>
              <div className="max-w-7xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
                <div>
                  © 2026 Cloud Control Center • Designed for Senior Portfolio Showcases.
                </div>
                <div className="flex items-center gap-1.5 font-mono text-[11px]">
                  <FileCode2 className="w-3.5 h-3.5" /> Clean Architecture Verified
                </div>
              </div>
            </footer>
          </div>

        </div>
      </div>

      {/* Universal AWS Connection Dialog */}
      {showConnectModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50 animate-fade-in">
          <div className="bg-[#0f1422] border border-slate-800 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl relative">
            
            {/* Modal Header */}
            <div className="bg-slate-900/80 px-6 py-4 border-b border-slate-800 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Lock className="w-4 h-4 text-amber-500" />
                <span className="text-xs font-bold uppercase tracking-wider text-slate-300 font-mono">
                  AWS IAM Configuration Drawer
                </span>
              </div>
              <button 
                onClick={() => setShowConnectModal(false)}
                className="text-slate-400 hover:text-white text-sm font-mono p-1"
                aria-label="Close credentials drawer"
              >
                ✕
              </button>
            </div>

            {/* Modal Body with Form */}
            <form onSubmit={handleFormSubmit}>
              <div className="p-6 space-y-4">
                {submitError && (
                  <div className="flex items-start gap-2.5 bg-rose-500/10 p-3.5 rounded-xl border border-rose-500/20 text-rose-400 text-xs font-mono">
                    <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
                    <span>{submitError}</span>
                  </div>
                )}

                <div className="space-y-3.5">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1.5">
                      AWS Access Key ID *
                    </label>
                    <input
                      type="text"
                      required
                      placeholder="AKIA..."
                      value={accessKeyId}
                      onChange={(e) => setAccessKeyId(e.target.value)}
                      disabled={isSubmitting}
                      className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500/50 rounded-xl text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1.5">
                      AWS Secret Access Key *
                    </label>
                    <input
                      type="password"
                      required
                      placeholder="Enter your secret access key"
                      value={secretAccessKey}
                      onChange={(e) => setSecretAccessKey(e.target.value)}
                      disabled={isSubmitting}
                      className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500/50 rounded-xl text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1.5">
                      AWS Session Token (Optional)
                    </label>
                    <input
                      type="password"
                      placeholder="Enter session token if using temporary credentials"
                      value={sessionToken}
                      onChange={(e) => setSessionToken(e.target.value)}
                      disabled={isSubmitting}
                      className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500/50 rounded-xl text-xs font-mono text-slate-200 placeholder-slate-600 focus:outline-none transition-all"
                    />
                  </div>

                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-wider text-slate-400 font-mono mb-1.5">
                      Default Region
                    </label>
                    <select
                      value={selectedRegion}
                      onChange={(e) => changeRegion(e.target.value)}
                      disabled={isSubmitting || loadingRegions || regionDetails.length === 0}
                      className="w-full px-3.5 py-2 bg-slate-950 border border-slate-800 focus:border-amber-500/50 rounded-xl text-xs font-mono text-slate-200 focus:outline-none transition-all appearance-none"
                    >
                      {loadingRegions ? (
                        <option value="">Loading regions...</option>
                      ) : regionsError ? (
                        <option value="">Error loading regions</option>
                      ) : regionDetails.length === 0 ? (
                        <option value="">No regions available</option>
                      ) : (
                        regionDetails.map((item) => (
                          <option key={item.code} value={item.code}>
                            {item.code} ({item.name})
                          </option>
                        ))
                      )}
                    </select>
                    {regionsError && (
                      <div className="mt-1 flex items-center justify-between">
                        <span className="text-[10px] text-rose-400 font-mono">Failed to load AWS regions</span>
                        <button
                          type="button"
                          onClick={() => refreshRegions()}
                          className="text-amber-500 hover:text-amber-400 text-[10px] font-mono font-bold hover:underline transition"
                        >
                          Retry
                        </button>
                      </div>
                    )}
                  </div>
                </div>

                <div className="bg-slate-900/40 p-3.5 rounded-xl border border-slate-800/60 flex items-start gap-2.5 text-xs text-slate-500">
                  <Info className="w-4 h-4 text-slate-600 shrink-0 mt-0.5" />
                  <p className="leading-relaxed font-mono text-[10px]">
                    Credentials are submitted securely via POST and are never stored on the client. Active validation is performed using AWS STS.
                  </p>
                </div>
              </div>

              {/* Modal Footer */}
              <div className="bg-slate-900/60 px-6 py-4 border-t border-slate-800 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setShowConnectModal(false)}
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-slate-800 hover:bg-slate-700 disabled:opacity-50 text-slate-300 font-semibold text-xs rounded-lg transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="px-4 py-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-lg transition-all duration-150 shadow-md shadow-amber-500/5 flex items-center gap-1.5"
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      Connecting...
                    </>
                  ) : (
                    'Verify & Connect'
                  )}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

      {/* Universal feedback notifications on AWS status */}
      {awsState.connected && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm w-full bg-[#0d1f14] border-2 border-emerald-500/20 text-emerald-100 rounded-xl p-4 shadow-2xl shadow-emerald-950/20 flex gap-3 animate-slide-in items-start">
          <CheckCircle className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="flex-1 space-y-1">
            <h5 className="text-xs font-bold font-mono uppercase tracking-wider text-emerald-400">AWS Session Established</h5>
            <p className="text-[11px] text-emerald-200/90 leading-relaxed">
              ✅ AWS Connected. Caller identity verified successfully with Account ID: <span className="font-mono font-bold text-white">{awsState.accountId}</span>
            </p>
          </div>
        </div>
      )}

      {!awsState.connected && awsState.error && (
        <div className="fixed bottom-6 right-6 z-50 max-w-sm w-full bg-[#1e1112] border-2 border-rose-500/20 text-rose-100 rounded-xl p-4 shadow-2xl shadow-rose-950/20 flex gap-3 animate-slide-in items-start">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1 space-y-1">
            <h5 className="text-xs font-bold font-mono uppercase tracking-wider text-rose-400">AWS Connection Failed</h5>
            <p className="text-[11px] text-rose-200/90 leading-relaxed">
              Unable to connect to AWS. Please configure AWS CLI credentials using <code className="text-rose-300 font-mono bg-rose-950/60 px-1 py-0.5 rounded">aws configure</code>, then restart the backend.
            </p>
          </div>
        </div>
      )}

      {/* Global toasts component */}
      <ToastNotification />

    </div>
  );
}
