import { useState } from 'react';
import { useAWSAccount } from '../hooks/useAWSAccount';
import PageHeader from '../components/common/PageHeader';
import { 
  Cloud, 
  ShieldCheck, 
  ShieldAlert, 
  User, 
  Globe, 
  Cpu, 
  KeyRound, 
  RefreshCw, 
  Copy, 
  Check, 
  Tag, 
  Layers, 
  AlertCircle,
  Terminal
} from 'lucide-react';

/**
 * AWSAccountPage
 * Highly polished, production-ready corporate dashboard presenting critical
 * AWS Account profile metadata, STS identity bounds, and active region availability.
 */
export default function AWSAccountPage() {
  const { account, loading, refetch } = useAWSAccount();
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, fieldName: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(fieldName);
    setTimeout(() => setCopiedField(null), 1500);
  };

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="AWS Account Overview" 
        description="Comprehensive real-time directory audit of the connected AWS organization, secure IAM identities, and regional scopes."
      >
        <button 
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Account</span>
        </button>
      </PageHeader>

      {/* Main Connection Status Banner */}
      {!loading && (
        <div className={`p-5 rounded-2xl border flex flex-col md:flex-row items-start md:items-center justify-between gap-4 transition-all duration-300 ${
          account?.connected 
            ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-300' 
            : 'bg-rose-500/10 border-rose-500/20 text-rose-300'
        }`}>
          <div className="flex gap-3.5 items-start">
            <div className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 border ${
              account?.connected 
                ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                : 'bg-rose-500/10 border-rose-500/20 text-rose-400'
            }`}>
              {account?.connected ? (
                <ShieldCheck className="w-5 h-5 animate-pulse" />
              ) : (
                <ShieldAlert className="w-5 h-5" />
              )}
            </div>
            <div>
              <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                {account?.connected ? '✔ AWS Connected' : 'AWS Connection Offline'}
              </h4>
              <p className="text-xs text-slate-400 mt-1 leading-relaxed max-w-2xl">
                {account?.connected 
                  ? 'Your active session profile credentials have been successfully authenticated with AWS Security Token Service (STS). This server acts as a secure reverse proxy.'
                  : 'Unable to establish standard STS caller handshake. Please make sure that your local terminal credentials file is configured with the active AWS IAM User keys.'
                }
              </p>
            </div>
          </div>
          <div className="shrink-0 font-mono text-[11px] font-bold uppercase tracking-widest px-3 py-1 bg-slate-900/50 rounded-lg border border-slate-800">
            Status: {account?.connected ? 'Active Secure' : 'Disconnected'}
          </div>
        </div>
      )}

      {/* Loading Skeleton Loader */}
      {loading && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="lg:col-span-2 space-y-6">
            <div className="h-64 bg-[#0f1422]/60 rounded-2xl border border-slate-800/60 animate-pulse"></div>
          </div>
          <div className="space-y-6">
            <div className="h-64 bg-[#0f1422]/60 rounded-2xl border border-slate-800/60 animate-pulse"></div>
          </div>
        </div>
      )}

      {/* Main Account Details Content Layout */}
      {!loading && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          
          {/* Left Column: Account Profile Information */}
          <div className="lg:col-span-2 space-y-8">
            
            <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
              <div className="h-1.5 w-full bg-gradient-to-r from-amber-500 to-amber-600"></div>
              
              <div className="p-6 md:p-8 space-y-6">
                <div className="flex items-center gap-2.5 border-b border-slate-800/60 pb-4">
                  <Cloud className="w-5 h-5 text-amber-500" />
                  <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                    STS Identity Audit Logs
                  </h3>
                </div>

                {account?.connected ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    
                    {/* Account Alias Info */}
                    <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-5 relative group/card flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Tag className="w-4 h-4 text-amber-500" />
                          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                            Account Alias
                          </span>
                        </div>
                        <div className="space-y-1">
                          <span className={`text-sm font-mono font-bold block ${
                            account.account_alias === 'Account Alias unavailable' 
                              ? 'text-slate-500 italic' 
                              : 'text-slate-200'
                          }`}>
                            {account.account_alias}
                          </span>
                        </div>
                      </div>
                      
                      {account.account_alias !== 'Account Alias unavailable' && (
                        <button
                          onClick={() => handleCopy(account.account_alias || '', 'alias')}
                          className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors"
                          title="Copy Account Alias"
                        >
                          {copiedField === 'alias' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                        </button>
                      )}
                    </div>

                    {/* Account ID Info */}
                    <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-5 relative group/card flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Cpu className="w-4 h-4 text-sky-500" />
                          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                            AWS Account ID
                          </span>
                        </div>
                        <div className="space-y-1">
                          <span className="text-sm font-mono font-bold text-slate-200 block select-all">
                            {account.account_id}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleCopy(account.account_id || '', 'accountId')}
                        className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Account ID"
                      >
                        {copiedField === 'accountId' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    {/* IAM User Name Info */}
                    <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-5 relative group/card flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-teal-400" />
                          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                            IAM Username / Profile
                          </span>
                        </div>
                        <div className="space-y-1">
                          <span className="text-sm font-mono font-bold text-slate-200 block">
                            {account.user_name}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleCopy(account.user_name || '', 'userName')}
                        className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Username"
                      >
                        {copiedField === 'userName' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    {/* Current Region Info */}
                    <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-5 relative group/card flex flex-col justify-between">
                      <div className="space-y-3">
                        <div className="flex items-center gap-2">
                          <Globe className="w-4 h-4 text-purple-400" />
                          <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                            Current AWS Region
                          </span>
                        </div>
                        <div className="space-y-1">
                          <span className="text-sm font-mono font-bold text-slate-200 block">
                            {account.region}
                          </span>
                        </div>
                      </div>
                      <button
                        onClick={() => handleCopy(account.region || '', 'region')}
                        className="absolute top-4 right-4 p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors"
                        title="Copy Region"
                      >
                        {copiedField === 'region' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>

                    {/* Caller ARN Block */}
                    <div className="bg-slate-950/40 border border-slate-800/50 rounded-xl p-5 md:col-span-2 relative group/card">
                      <div className="space-y-3">
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-2">
                            <KeyRound className="w-4 h-4 text-emerald-400" />
                            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                              Caller Identity ARN (Amazon Resource Name)
                            </span>
                          </div>
                          <button
                            onClick={() => handleCopy(account.arn || '', 'arn')}
                            className="p-1.5 rounded-lg text-slate-500 hover:text-slate-300 transition-colors"
                            title="Copy ARN"
                          >
                            {copiedField === 'arn' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                          </button>
                        </div>
                        <div className="bg-slate-950 p-3.5 rounded-lg border border-slate-900 overflow-x-auto">
                          <code className="text-xs font-mono text-slate-300 select-all whitespace-nowrap block">
                            {account.arn}
                          </code>
                        </div>
                      </div>
                    </div>

                  </div>
                ) : (
                  <div className="text-center py-12 space-y-4">
                    <div className="w-12 h-12 rounded-xl bg-slate-900 border border-slate-800/80 flex items-center justify-center mx-auto text-slate-500">
                      <AlertCircle className="w-6 h-6" />
                    </div>
                    <div className="space-y-1 max-w-sm mx-auto">
                      <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                        No active AWS metadata retrieved
                      </h4>
                      <p className="text-xs text-slate-500 leading-relaxed">
                        To view your AWS Account profile parameters and check configured regions, please complete credential configuration on your hosting sandbox workspace.
                      </p>
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* AWS Configuration Guidelines card - shown only when offline */}
            {!account?.connected && (
              <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden p-6 md:p-8 space-y-6">
                <div className="flex items-center gap-2 text-slate-300">
                  <Terminal className="w-5 h-5 text-slate-400" />
                  <h3 className="text-sm font-bold font-mono uppercase tracking-wider text-white">
                    Step-by-Step Security Setup Checklist
                  </h3>
                </div>

                <div className="space-y-4 text-xs text-slate-400 leading-relaxed">
                  <p>
                    The Cloud Control Center connects using the secure Python AWS SDK (<code className="text-teal-400 px-1 bg-slate-950 rounded">boto3</code>). Follow these steps on your development environment terminal:
                  </p>
                  
                  <div className="space-y-3">
                    <div className="flex gap-3">
                      <span className="w-5 h-5 rounded bg-slate-800/80 border border-slate-700/60 text-slate-300 font-bold flex items-center justify-center text-[10px] shrink-0 font-mono">1</span>
                      <div>
                        <p className="font-bold text-slate-300">Run AWS Configuration Wizard</p>
                        <p className="text-[11px] text-slate-500 mt-1">Configure your IAM access keys, default session region, and standard JSON formats.</p>
                        <div className="bg-slate-950 px-3.5 py-2 rounded-lg border border-slate-900 mt-2 font-mono text-teal-400 text-[11px] flex items-center justify-between">
                          <span>$ aws configure</span>
                          <button onClick={() => handleCopy('aws configure', 'awsConf')} className="text-slate-600 hover:text-slate-400">
                            {copiedField === 'awsConf' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <span className="w-5 h-5 rounded bg-slate-800/80 border border-slate-700/60 text-slate-300 font-bold flex items-center justify-center text-[10px] shrink-0 font-mono">2</span>
                      <div>
                        <p className="font-bold text-slate-300">Verify AWS Identity Locally</p>
                        <p className="text-[11px] text-slate-500 mt-1">Execute the standard STS lookup to confirm access key resolution.</p>
                        <div className="bg-slate-950 px-3.5 py-2 rounded-lg border border-slate-900 mt-2 font-mono text-teal-400 text-[11px] flex items-center justify-between">
                          <span>$ aws sts get-caller-identity</span>
                          <button onClick={() => handleCopy('aws sts get-caller-identity', 'awsSts')} className="text-slate-600 hover:text-slate-400">
                            {copiedField === 'awsSts' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                          </button>
                        </div>
                      </div>
                    </div>

                    <div className="flex gap-3">
                      <span className="w-5 h-5 rounded bg-slate-800/80 border border-slate-700/60 text-slate-300 font-bold flex items-center justify-center text-[10px] shrink-0 font-mono">3</span>
                      <div>
                        <p className="font-bold text-slate-300">Restart the Backend Application Server</p>
                        <p className="text-[11px] text-slate-500 mt-1">Restart the backend uvicorn service to clear credential caching contexts.</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            )}

          </div>

          {/* Right Column: Available Regions */}
          <div className="space-y-8">
            
            <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
              <div className="h-1.5 w-full bg-gradient-to-r from-sky-500 to-sky-600"></div>

              <div className="p-6 space-y-5">
                <div className="flex items-center gap-2 border-b border-slate-800/60 pb-4">
                  <Layers className="w-5 h-5 text-sky-400" />
                  <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider">
                    Available AWS Regions
                  </h3>
                </div>

                <p className="text-xs text-slate-400 leading-relaxed">
                  These geographical locations can be targeted for deployment and administrative workloads on the Cloud Control Center platform.
                </p>

                {account?.connected && account?.available_regions && account.available_regions.length > 0 ? (
                  <div className="flex flex-wrap gap-2 pt-2">
                    {account.available_regions.map((reg) => {
                      const isCurrent = reg === account.region;
                      return (
                        <div
                          key={reg}
                          className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-mono font-bold transition-all border ${
                            isCurrent
                              ? 'bg-sky-500/10 border-sky-500/30 text-sky-400 ring-1 ring-sky-500/20'
                              : 'bg-slate-900/60 border-slate-800/80 text-slate-400 hover:text-slate-300 hover:border-slate-700'
                          }`}
                        >
                          <span className={`w-1.5 h-1.5 rounded-full ${isCurrent ? 'bg-sky-400 animate-pulse' : 'bg-slate-600'}`}></span>
                          {reg}
                          {isCurrent && <span className="text-[9px] uppercase tracking-wider font-sans font-extrabold text-sky-500 ml-1">(active)</span>}
                        </div>
                      );
                    })}
                  </div>
                ) : (
                  <div className="bg-slate-950/40 p-4 rounded-xl text-center border border-slate-800/40">
                    <span className="text-xs text-slate-500 font-mono italic">
                      {account?.connected ? 'No regions resolved.' : 'Regions list offline.'}
                    </span>
                  </div>
                )}
              </div>
            </div>

          </div>

        </div>
      )}

    </div>
  );
}
