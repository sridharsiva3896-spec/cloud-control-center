import { useState, useMemo } from 'react';
import { useCloudTrail } from '../hooks/useCloudTrail';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { useNotification } from '../hooks/useNotification';
import { useRegion } from '../hooks/useRegion';
import { 
  History, 
  Users, 
  Share2, 
  RefreshCw, 
  Search, 
  Filter, 
  Clock, 
  User, 
  MapPin, 
  ShieldAlert, 
  AlertTriangle,
  Info,
  CheckCircle2,
  XCircle,
  Download
} from 'lucide-react';

/**
 * CloudTrailPage Component
 * Executive audit console presenting recently triggered management plane API operations,
 * read/write scopes, and actor profiles retrieved from AWS CloudTrail.
 */
export default function CloudTrailPage() {
  const { data, loading, error, refetch } = useCloudTrail();
  const { addNotification } = useNotification();
  const { selectedRegion } = useRegion();
  
  // Client-side state filters
  const [eventNameSearch, setEventNameSearch] = useState('');
  const [usernameSearch, setUsernameSearch] = useState('');
  const [selectedSource, setSelectedSource] = useState('all');

  const events = data?.events || [];
  const summary = data?.summary || { total_events: 0, unique_users: 0, event_sources: 0 };
  const isEnabled = data?.enabled ?? true;

  // Derive unique event sources dynamically to populate the Filter by Event Source dropdown
  const uniqueSources = useMemo(() => {
    const sources = new Set<string>();
    events.forEach(e => {
      if (e.event_source && e.event_source !== 'N/A') {
        sources.add(e.event_source);
      }
    });
    return Array.from(sources).sort();
  }, [events]);

  // Combined client-side filtering
  const filteredEvents = useMemo(() => {
    return events.filter(event => {
      const matchEventName = event.event_name.toLowerCase().includes(eventNameSearch.toLowerCase());
      const matchUsername = event.username.toLowerCase().includes(usernameSearch.toLowerCase());
      const matchSource = selectedSource === 'all' || event.event_source === selectedSource;
      return matchEventName && matchUsername && matchSource;
    });
  }, [events, eventNameSearch, usernameSearch, selectedSource]);

  const handleExport = () => {
    if (filteredEvents.length === 0) return;
    try {
      const headers = ['Event ID', 'Event Name', 'Username', 'Event Time', 'Event Source', 'ReadOnly', 'AWS Region', 'Resource Name'];
      const rows = filteredEvents.map(e => [
        e.event_id,
        e.event_name,
        e.username,
        e.event_time,
        e.event_source,
        e.read_only ? 'TRUE' : 'FALSE',
        e.aws_region,
        e.resource_name
      ]);
      const csvContent = "data:text/csv;charset=utf-8," 
        + [headers.join(','), ...rows.map(r => r.map(val => `"${val}"`).join(','))].join('\n');
      
      const encodedUri = encodeURI(csvContent);
      const link = document.createElement("a");
      link.setAttribute("href", encodedUri);
      link.setAttribute("download", `cloudtrail_audit_export_${selectedRegion}.csv`);
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

      addNotification(
        'Export Completed',
        `Exported ${filteredEvents.length} CloudTrail audit events to CSV format.`,
        'success',
        'CloudTrail'
      );
    } catch (err: any) {
      addNotification(
        'Export Failed',
        `Failed to export audit logs: ${err.message}`,
        'error',
        'CloudTrail'
      );
    }
  };

  // Compute stats of filtered view
  const writeEventsCount = useMemo(() => {
    return filteredEvents.filter(e => !e.read_only).length;
  }, [filteredEvents]);

  const showEmptyState = !loading && (events.length === 0);

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Executive Header */}
      <PageHeader 
        title="CloudTrail Audit Logs" 
        description="Verify recent management operations, analyze user action parameters, audit deployment records, and isolate write activity signatures."
      >
        <div className="flex flex-wrap gap-3">
          <button 
            onClick={handleExport}
            disabled={loading || filteredEvents.length === 0}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 border border-amber-500/20 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50 shadow-sm"
            title="Export filtered CloudTrail audit log to CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Log</span>
          </button>
          
          <button 
            onClick={refetch}
            disabled={loading}
            className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50 shadow-sm"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>Refresh Audit</span>
          </button>
        </div>
      </PageHeader>

      {/* CloudTrail disabled or access-denied banner warning */}
      {(!isEnabled || error) && (
        <div className="p-4.5 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3.5">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
              Audit Service Interruption
            </h4>
            <p className="text-xs text-rose-200/80 leading-relaxed">
              {error || data?.message || 'Access Denied. Please ensure active AWS credentials have permission to read CloudTrail events (cloudtrail:LookupEvents).'}
            </p>
          </div>
        </div>
      )}

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        
        {/* Total Events */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Total Logged Events
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.total_events}
              </span>
              <span className="text-xs text-slate-400 font-medium">audited actions</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-slate-400">
            <History className="w-5 h-5" />
          </div>
        </div>

        {/* Unique Users */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Unique Actors
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none text-sky-400">
                {loading ? '...' : summary.unique_users}
              </span>
              <span className="text-xs text-slate-400 font-medium">IAM profiles</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-sky-400">
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Event Sources */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Integrated AWS Services
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none text-teal-400">
                {loading ? '...' : summary.event_sources}
              </span>
              <span className="text-xs text-slate-400 font-medium">boto3 scopes</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-teal-400">
            <Share2 className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Main Filter and Audit Table Workspace */}
      {showEmptyState ? (
        <div className="p-16 text-center space-y-4 bg-[#0f1422] border border-slate-800/80 rounded-2xl shadow-xl">
          <div className="w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500 mx-auto">
            <History className="w-6 h-6 text-amber-500 animate-pulse" />
          </div>
          <div className="space-y-1.5 max-w-md mx-auto">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              No CloudTrail events found
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed">
              We couldn't fetch any audit events for this region. Verify that CloudTrail log streaming is active in your AWS environment.
            </p>
          </div>
        </div>
      ) : (
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl space-y-px">
          
          {/* Advanced Multi-parameter filter panel */}
          <div className="p-5 border-b border-slate-800/80 bg-slate-900/10 space-y-4">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 text-rose-500" />
                  Management Plane Telemetry
                </h3>
                <p className="text-xs text-slate-500">
                  Audit events filter directory. Sort and search by action, user or namespaces.
                </p>
              </div>

              {/* Status indicators about active subset */}
              {!loading && (
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
                  <div className="flex items-center gap-3 text-[10px] font-mono font-bold bg-slate-950/60 border border-slate-800 px-3 py-1.5 rounded-xl">
                    <span className="text-slate-400">Filtered View:</span>
                    <span className="text-white">{filteredEvents.length} Events</span>
                    <span className="w-1 h-1 rounded-full bg-slate-700"></span>
                    <span className="text-orange-400">{writeEventsCount} Mutation Operations</span>
                  </div>
                  <ExportMenu data={filteredEvents} filenamePrefix="AWS_CloudTrail_Events" />
                </div>
              )}
            </div>

            {/* Filter controls row */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              
              {/* Event Name Search */}
              <div className="relative">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={eventNameSearch}
                  onChange={(e) => setEventNameSearch(e.target.value)}
                  placeholder="Search by Event Name (e.g. RunInstances)..."
                  className="pl-9 pr-3.5 py-2 bg-slate-950 border border-slate-800/80 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-rose-500/40 focus:ring-1 focus:ring-rose-500/20 placeholder-slate-600 w-full transition"
                />
              </div>

              {/* Username Search */}
              <div className="relative">
                <User className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={usernameSearch}
                  onChange={(e) => setUsernameSearch(e.target.value)}
                  placeholder="Search by Actor Username..."
                  className="pl-9 pr-3.5 py-2 bg-slate-950 border border-slate-800/80 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-rose-500/40 focus:ring-1 focus:ring-rose-500/20 placeholder-slate-600 w-full transition"
                />
              </div>

              {/* Event Source Dropdown Selector */}
              <div className="relative">
                <Filter className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <select
                  value={selectedSource}
                  onChange={(e) => setSelectedSource(e.target.value)}
                  className="pl-9 pr-3.5 py-2 bg-slate-950 border border-slate-800/80 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-rose-500/40 focus:ring-1 focus:ring-rose-500/20 w-full appearance-none transition"
                >
                  <option value="all">Filter by Event Source (All namespaces)</option>
                  {uniqueSources.map(source => (
                    <option key={source} value={source}>{source}</option>
                  ))}
                </select>
              </div>

            </div>
          </div>

          {/* Table list view */}
          {loading ? (
            <div className="p-8 space-y-4">
              <div className="h-8 bg-slate-900 rounded-xl animate-pulse"></div>
              <div className="h-48 bg-slate-900 rounded-xl animate-pulse"></div>
            </div>
          ) : filteredEvents.length === 0 ? (
            <div className="p-16 text-center text-xs text-slate-500 font-mono space-y-1.5">
              <Info className="w-5 h-5 text-slate-600 mx-auto mb-2" />
              <p className="font-bold text-slate-400">No matching audit events</p>
              <p className="text-[11px] text-slate-600">Try modifying your text search filters or namespace selectors above.</p>
            </div>
          ) : (
            <div className="overflow-x-auto">
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/30 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                    <th className="px-6 py-4">Event Time</th>
                    <th className="px-6 py-4">Event Name</th>
                    <th className="px-6 py-4">Event Source</th>
                    <th className="px-6 py-4">Actor (Username)</th>
                    <th className="px-6 py-4">Region</th>
                    <th className="px-6 py-4">Target Resource</th>
                    <th className="px-6 py-4 text-center">Operation Scope</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/50 text-xs text-slate-300">
                  {filteredEvents.map((item) => (
                    <tr key={item.event_id} className="hover:bg-slate-900/10 transition-colors group">
                      
                      {/* Event Time */}
                      <td className="px-6 py-4 font-mono">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                          <span className="text-[11px] font-semibold text-slate-400 group-hover:text-slate-300 transition">
                            {item.event_time !== 'N/A'
                              ? new Date(item.event_time).toLocaleString('en-US', {
                                  month: 'short',
                                  day: '2-digit',
                                  hour: '2-digit',
                                  minute: '2-digit',
                                  second: '2-digit',
                                  hour12: false
                                })
                              : 'N/A'}
                          </span>
                        </div>
                      </td>

                      {/* Event Name */}
                      <td className="px-6 py-4">
                        <span className="font-mono font-bold text-white bg-slate-950 px-2 py-1 rounded border border-slate-800/80 text-[11px] select-all">
                          {item.event_name}
                        </span>
                      </td>

                      {/* Event Source */}
                      <td className="px-6 py-4 font-mono text-slate-400 text-[11px]">
                        {item.event_source}
                      </td>

                      {/* Actor (Username) */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5">
                          <span className="w-2 h-2 rounded-full bg-slate-700"></span>
                          <span className="font-mono font-semibold text-slate-300">{item.username}</span>
                        </div>
                      </td>

                      {/* Region */}
                      <td className="px-6 py-4 font-mono">
                        <div className="flex items-center gap-1.5 text-slate-400">
                          <MapPin className="w-3.5 h-3.5 text-slate-500" />
                          <span>{item.aws_region}</span>
                        </div>
                      </td>

                      {/* Target Resource */}
                      <td className="px-6 py-4 font-mono max-w-[200px] truncate" title={item.resource_name}>
                        {item.resource_name !== 'N/A' ? (
                          <div className="space-y-0.5">
                            <span className="font-bold text-white text-[11px] select-all">{item.resource_name}</span>
                            <div className="text-[9px] text-slate-500 uppercase tracking-wider">{item.resource_type.split('::').pop()}</div>
                          </div>
                        ) : (
                          <span className="text-slate-600 font-semibold italic text-[11px]">No resource bounds</span>
                        )}
                      </td>

                      {/* Operation Scope - Read Only Badge */}
                      <td className="px-6 py-4 text-center">
                        {item.read_only ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 border border-sky-500/20 bg-sky-500/10 text-sky-400 rounded-xl text-[10px] font-mono font-bold leading-none">
                            <CheckCircle2 className="w-3 h-3 text-sky-400" />
                            Read Only
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 border border-orange-500/20 bg-orange-500/10 text-orange-400 rounded-xl text-[10px] font-mono font-bold leading-none">
                            <XCircle className="w-3 h-3 text-orange-400" />
                            Mutation Write
                          </span>
                        )}
                      </td>

                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}

          {/* Audit Notice Disclaimer Footer block */}
          <div className="p-4 bg-slate-950/60 border-t border-slate-800 text-slate-400 text-xs font-mono flex items-start gap-2.5">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
            <div className="space-y-1">
              <p className="font-bold uppercase tracking-wider text-white text-[10px]">
                AWS CloudTrail Operations Policy
              </p>
              <p className="text-[11px] text-slate-500 leading-relaxed">
                Management plane events are retrieved as read-only telemetry summaries directly via secure programmatic CloudTrail lookups. Writing metrics, altering audit tracks, disabling event logs, or changing target trail destinations is strictly restricted.
              </p>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
