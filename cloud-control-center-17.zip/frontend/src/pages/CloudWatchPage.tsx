import { useState } from 'react';
import { useCloudWatch } from '../hooks/useCloudWatch';
import PageHeader from '../components/common/PageHeader';
import { 
  Activity, 
  Cpu, 
  RefreshCw, 
  ArrowDown, 
  ArrowUp, 
  HardDrive, 
  Clock, 
  AlertTriangle, 
  Layers,
  Info
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Legend, 
  AreaChart, 
  Area 
} from 'recharts';

/**
 * Custom styled tooltip component for Recharts visual telemetry rendering.
 */
const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-950/95 border border-slate-800 p-3.5 rounded-xl font-mono text-[11px] text-slate-300 shadow-xl space-y-1">
        <p className="font-extrabold text-white uppercase tracking-wider text-[10px] border-b border-slate-800 pb-1 mb-1.5">
          Instance ID: {data.instanceId}
        </p>
        {payload.map((p: any) => (
          <p key={p.name} className="flex justify-between gap-4 font-semibold">
            <span style={{ color: p.color }}>{p.name}:</span>
            <span className="text-white font-extrabold">{p.value}</span>
          </p>
        ))}
      </div>
    );
  }
  return null;
};

/**
 * CloudWatchPage Component
 * Executive performance and operations telemetry view reporting live system performance
 * logs across virtual machines using real-time CloudWatch API metrics.
 */
export default function CloudWatchPage() {
  const { data, loading, error, refetch } = useCloudWatch();
  const [searchTerm, setSearchTerm] = useState('');

  // Accessors
  const instances = data?.instances || [];
  const summary = data?.summary || { monitored_instances: 0, metrics_collected: 0 };
  const partialErrors = data?.errors || {};

  // Formatter helpers
  const formatBytes = (val: number | null) => {
    if (val === null) return 'N/A';
    if (val < 1024) return `${val.toFixed(0)} B`;
    const kb = val / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;
    const mb = kb / 1024;
    if (mb < 1024) return `${mb.toFixed(1)} MB`;
    const gb = mb / 1024;
    return `${gb.toFixed(1)} GB`;
  };

  const getCPUBadge = (val: number | null) => {
    if (val === null) return <span className="text-slate-500 font-semibold font-mono">N/A</span>;
    if (val <= 50) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 border border-emerald-500/20 bg-emerald-500/10 text-emerald-400 rounded-xl text-[10px] font-mono font-bold">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
          {val.toFixed(1)}%
        </span>
      );
    } else if (val <= 80) {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 border border-amber-500/20 bg-amber-500/10 text-amber-400 rounded-xl text-[10px] font-mono font-bold">
          <span className="w-1.5 h-1.5 rounded-full bg-amber-500 animate-pulse"></span>
          {val.toFixed(1)}%
        </span>
      );
    } else {
      return (
        <span className="inline-flex items-center gap-1 px-2.5 py-1 border border-rose-500/20 bg-rose-500/10 text-rose-400 rounded-xl text-[10px] font-mono font-bold">
          <span className="w-1.5 h-1.5 rounded-full bg-rose-500 animate-pulse"></span>
          {val.toFixed(1)}%
        </span>
      );
    }
  };

  // Filter instances by ID search
  const filteredInstances = instances.filter(inst => 
    inst.instance_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Stats Computations (skipping null values)
  const validCPUs = instances.filter(i => i.metrics.cpu_utilization !== null);
  const avgCPU = validCPUs.length > 0 
    ? validCPUs.reduce((sum, i) => sum + (i.metrics.cpu_utilization ?? 0), 0) / validCPUs.length 
    : 0;

  const validNetIn = instances.filter(i => i.metrics.network_in !== null);
  const avgNetIn = validNetIn.length > 0 
    ? validNetIn.reduce((sum, i) => sum + (i.metrics.network_in ?? 0), 0) / validNetIn.length 
    : 0;

  // Chart telemetry formatting
  const chartData = filteredInstances.map(inst => ({
    name: inst.instance_id.length > 12 ? `${inst.instance_id.slice(0, 10)}...` : inst.instance_id,
    instanceId: inst.instance_id,
    'CPU Utilization (%)': inst.metrics.cpu_utilization !== null ? Number(inst.metrics.cpu_utilization.toFixed(2)) : 0,
    'Network In (KB)': inst.metrics.network_in !== null ? Number((inst.metrics.network_in / 1024).toFixed(2)) : 0,
    'Network Out (KB)': inst.metrics.network_out !== null ? Number((inst.metrics.network_out / 1024).toFixed(2)) : 0,
    'Disk Read (KB)': inst.metrics.disk_read_bytes !== null ? Number((inst.metrics.disk_read_bytes / 1024).toFixed(2)) : 0,
    'Disk Write (KB)': inst.metrics.disk_write_bytes !== null ? Number((inst.metrics.disk_write_bytes / 1024).toFixed(2)) : 0,
  }));

  const showEmptyState = !loading && (instances.length === 0 || summary.metrics_collected === 0);

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="CloudWatch Performance Monitor" 
        description="Audit virtual machine compute metrics, monitor disk IOPS thresholds, track bandwidth constraints, and identify CPU bottlenecks."
      >
        <button 
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Metrics</span>
        </button>
      </PageHeader>

      {/* Global connection error warning banner */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
              CloudWatch Integration Interrupted
            </h4>
            <p className="text-xs text-rose-200/80 leading-relaxed">
              {error}. Please check your AWS IAM account permissions bounds for access to standard CloudWatch APIs (`cloudwatch:GetMetricStatistics`).
            </p>
          </div>
        </div>
      )}

      {/* KPI Stats Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Monitored Instances */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Monitored Instances
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.monitored_instances}
              </span>
              <span className="text-xs text-slate-400 font-medium">VM nodes</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-slate-400">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        {/* Metrics Collected */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Metrics Collected
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.metrics_collected}
              </span>
              <span className="text-xs text-slate-400 font-medium">telemetries</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-slate-400">
            <Activity className="w-5 h-5" />
          </div>
        </div>

        {/* Average CPU % */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Average CPU
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : `${avgCPU.toFixed(1)}%`}
              </span>
              <span className="text-xs text-slate-400 font-medium">utilization</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-slate-400">
            <Cpu className="w-5 h-5" />
          </div>
        </div>

        {/* Average Network In */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Avg Network In
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none text-sky-400">
                {loading ? '...' : formatBytes(avgNetIn)}
              </span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-slate-400">
            <ArrowDown className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Empty State vs Content Render */}
      {showEmptyState ? (
        <div className="p-16 text-center space-y-4 bg-[#0f1422] border border-slate-800/80 rounded-2xl shadow-xl">
          <div className="w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500 mx-auto">
            <Activity className="w-6 h-6 text-rose-500 animate-pulse" />
          </div>
          <div className="space-y-1.5 max-w-md mx-auto">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              No CloudWatch metrics available
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed font-sans">
              We couldn't aggregate active metric datapoints. Ensure you have active EC2 instances running inside your connected AWS profile.
            </p>
          </div>
        </div>
      ) : (
        <>
          {/* Charts Visualization Section */}
          {!loading && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
              
              {/* CPU Utilization Line Chart */}
              <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider flex items-center gap-1.5">
                      <Cpu className="w-4 h-4 text-amber-500" />
                      CPU Utilization Index
                    </h3>
                    <p className="text-xs text-slate-500">
                      Compute utilization trends across active VM nodes.
                    </p>
                  </div>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b/40" />
                      <XAxis dataKey="name" stroke="#64748b" fontSize={10} fontStyle="italic" />
                      <YAxis stroke="#64748b" fontSize={10} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 10, fontFamily: 'monospace' }} />
                      <Line 
                        type="monotone" 
                        dataKey="CPU Utilization (%)" 
                        stroke="#f59e0b" 
                        strokeWidth={2.5} 
                        activeDot={{ r: 6 }} 
                      />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Network Traffic Area Chart */}
              <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-4">
                <div className="flex items-center justify-between">
                  <div className="space-y-1">
                    <h3 className="text-sm font-bold text-white font-mono uppercase tracking-wider flex items-center gap-1.5">
                      <Activity className="w-4 h-4 text-sky-500" />
                      Network Bandwidth Traffic
                    </h3>
                    <p className="text-xs text-slate-500">
                      Aggregated egress and ingress bytes (KB) telemetry.
                    </p>
                  </div>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b/40" />
                      <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                      <YAxis stroke="#64748b" fontSize={10} />
                      <Tooltip content={<CustomTooltip />} />
                      <Legend wrapperStyle={{ fontSize: 10, fontFamily: 'monospace' }} />
                      <Area 
                        type="monotone" 
                        dataKey="Network In (KB)" 
                        stroke="#0ea5e9" 
                        fill="rgba(14, 165, 233, 0.05)" 
                        strokeWidth={1.5} 
                      />
                      <Area 
                        type="monotone" 
                        dataKey="Network Out (KB)" 
                        stroke="#ec4899" 
                        fill="rgba(236, 72, 153, 0.05)" 
                        strokeWidth={1.5} 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

            </div>
          )}

          {/* Table Audit List View */}
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
            
            {/* Header / Search Controls */}
            <div className="p-5 border-b border-slate-800/80 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                  CloudWatch Node Directory
                </h3>
                <p className="text-xs text-slate-500">
                  Granular performance state inspection for active instances.
                </p>
              </div>

              <input
                type="text"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search instance ID..."
                className="px-3.5 py-1.5 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-rose-500/40 focus:ring-1 focus:ring-rose-500/20 placeholder-slate-600 w-full sm:max-w-xs transition"
              />
            </div>

            {loading ? (
              <div className="p-8 space-y-4">
                <div className="h-8 bg-slate-900 rounded-xl animate-pulse"></div>
                <div className="h-40 bg-slate-900 rounded-xl animate-pulse"></div>
              </div>
            ) : filteredInstances.length === 0 ? (
              <div className="p-12 text-center text-xs text-slate-500 font-mono">
                No instances found matching "{searchTerm}".
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                      <th className="px-6 py-4">Instance ID</th>
                      <th className="px-6 py-4">CPU Utilization</th>
                      <th className="px-6 py-4">Network In</th>
                      <th className="px-6 py-4">Network Out</th>
                      <th className="px-6 py-4">Disk Read</th>
                      <th className="px-6 py-4">Disk Write</th>
                      <th className="px-6 py-4">Last Updated</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                    {filteredInstances.map((item) => (
                      <tr key={item.instance_id} className="hover:bg-slate-900/20 transition-colors">
                        <td className="px-6 py-4 font-mono font-bold text-white select-all">
                          {item.instance_id}
                        </td>
                        <td className="px-6 py-4">
                          {getCPUBadge(item.metrics.cpu_utilization)}
                        </td>
                        <td className="px-6 py-4 font-mono font-semibold">
                          <div className="flex items-center gap-1.5">
                            <ArrowDown className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span>{formatBytes(item.metrics.network_in)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 font-mono font-semibold">
                          <div className="flex items-center gap-1.5">
                            <ArrowUp className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span>{formatBytes(item.metrics.network_out)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 font-mono">
                          <div className="flex items-center gap-1.5">
                            <HardDrive className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span>{formatBytes(item.metrics.disk_read_bytes)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4 font-mono">
                          <div className="flex items-center gap-1.5">
                            <HardDrive className="w-3.5 h-3.5 text-slate-500 shrink-0" />
                            <span>{formatBytes(item.metrics.disk_write_bytes)}</span>
                          </div>
                        </td>
                        <td className="px-6 py-4">
                          <div className="flex items-center gap-1.5">
                            <Clock className="w-3.5 h-3.5 text-slate-500" />
                            <span className="text-[10px] font-mono font-semibold text-slate-400">
                              {item.last_updated !== 'N/A'
                                ? new Date(item.last_updated).toLocaleTimeString('en-US', {
                                    hour: '2-digit',
                                    minute: '2-digit',
                                    second: '2-digit'
                                  })
                                : 'N/A'}
                            </span>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Error Indicators Footer block if any keys failed */}
            {Object.keys(partialErrors).length > 0 && (
              <div className="p-4 bg-amber-500/5 border-t border-slate-800 text-amber-400 text-xs font-mono flex items-start gap-2.5">
                <Info className="w-4 h-4 shrink-0 mt-0.5" />
                <div className="space-y-1">
                  <p className="font-bold uppercase tracking-wider text-amber-200 text-[10px]">
                    Partial Data Auditing Limits Detected
                  </p>
                  <p className="text-[11px] text-amber-300/80 leading-relaxed">
                    Some performance metrics returned incomplete values or parameters. This is common if the instances haven't generated metrics during the last 1 hour time window.
                  </p>
                </div>
              </div>
            )}

          </div>
        </>
      )}

    </div>
  );
}
