import { useState, useMemo } from 'react';
import { useCostExplorer } from '../hooks/useCostExplorer';
import PageHeader from '../components/common/PageHeader';
import { 
  DollarSign, 
  TrendingUp, 
  TrendingDown, 
  RefreshCw, 
  BarChart3, 
  PieChart, 
  Calendar, 
  AlertTriangle, 
  CreditCard,
  Sparkles,
  Layers,
  Search
} from 'lucide-react';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  BarChart, 
  Bar, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  Cell
} from 'recharts';

/**
 * Custom styled tooltip component for Recharts Cost data.
 */
const CostTooltip = ({ active, payload, label }: any) => {
  if (active && payload && payload.length) {
    const value = payload[0].value;
    const name = payload[0].name;
    return (
      <div className="bg-slate-950/95 border border-slate-800 p-3 rounded-xl font-mono text-[11px] text-slate-300 shadow-xl space-y-1">
        <p className="font-extrabold text-white uppercase tracking-wider text-[10px] border-b border-slate-800 pb-1 mb-1.5">
          {label}
        </p>
        <p className="flex justify-between gap-4 font-semibold">
          <span className="text-rose-400">{name}:</span>
          <span className="text-white font-extrabold">${value.toFixed(2)}</span>
        </p>
      </div>
    );
  }
  return null;
};

/**
 * AWS Cost Explorer Dashboard
 * Executive billing, optimization, and budget tracking console visualizing resource consumption.
 */
export default function CostExplorerPage() {
  const { data, loading, error, refetch } = useCostExplorer();
  const [searchTerm, setSearchTerm] = useState('');

  const services = data?.services || [];
  const dailyTrend = data?.daily_trend || [];
  const summary = data?.summary || { current_month_cost: 0.0, previous_month_cost: 0.0, currency: 'USD' };
  const isEnabled = data?.enabled ?? true;

  // Compute stats and percentages
  const totalServicesCount = services.length;
  const currentCost = summary.current_month_cost;
  const previousCost = summary.previous_month_cost;
  const currency = summary.currency || 'USD';

  // Difference percentage month-over-month
  const { percentageDiff, isIncrease } = useMemo(() => {
    if (previousCost <= 0) {
      return { percentageDiff: 0, isIncrease: false };
    }
    const diff = currentCost - previousCost;
    const pct = (diff / previousCost) * 100;
    return {
      percentageDiff: Math.abs(pct),
      isIncrease: pct > 0
    };
  }, [currentCost, previousCost]);

  // Total computed from the services list for verification / percentage math
  const calculatedTotalServicesCost = useMemo(() => {
    return services.reduce((acc, item) => acc + item.cost, 0) || 1; // avoid 0 division
  }, [services]);

  // Filter services search
  const filteredServices = useMemo(() => {
    return services.filter(item => 
      item.service.toLowerCase().includes(searchTerm.toLowerCase())
    );
  }, [services, searchTerm]);

  // Pre-selected color palette for service chart bars to give it a rich dashboard feel
  const COLORS = ['#f43f5e', '#ec4899', '#d946ef', '#a855f7', '#8b5cf6', '#6366f1', '#3b82f6', '#0ea5e9', '#06b6d4', '#14b8a6'];

  const showEmptyState = !loading && isEnabled && (services.length === 0 && dailyTrend.length === 0);

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="AWS Cost Explorer" 
        description="Monitor billing metrics, explore monthly cost distributions, visualize daily trends, and audit pricing metrics dynamically."
      >
        <button 
          onClick={() => refetch(true)}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50 shadow-sm"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Cost Data</span>
        </button>
      </PageHeader>

      {/* Warning Alert if Cost Explorer disabled */}
      {(!isEnabled || error) && (
        <div className="p-4.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 flex items-start gap-3.5">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
              Cost Analytics Service Warning
            </h4>
            <p className="text-xs text-amber-200/80 leading-relaxed font-mono">
              {error || 'AWS Cost Explorer data is not available. Please ensure active credentials have ce:GetCostAndUsage authorization, or check if Cost Explorer is enabled in your AWS Billing Console.'}
            </p>
          </div>
        </div>
      )}

      {!data && !loading ? (
        <div className="p-16 text-center space-y-4 bg-[#0f1422] border border-slate-800/80 rounded-2xl shadow-xl flex flex-col items-center justify-center">
          <div className="w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500">
            <DollarSign className="w-6 h-6 text-emerald-500" />
          </div>
          <div className="space-y-1.5 max-w-md mx-auto">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              AWS Cost Data On-Demand
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed font-mono">
              To minimize billable AWS Cost Explorer API requests, billing data is only queried on-demand. Click the button below to retrieve live cost metrics.
            </p>
            <div className="pt-3">
              <button 
                onClick={() => refetch(true)}
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-500 hover:bg-emerald-400 text-slate-950 rounded-xl text-xs font-mono font-bold uppercase transition"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Refresh Cost Data</span>
              </button>
            </div>
          </div>
        </div>
      ) : (
        <>
          {/* KPI Stats Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
        
        {/* Current Month Spend */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Current Month Cost
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                ${loading ? '...' : currentCost.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400 font-mono font-bold uppercase">{currency}</span>
            </div>
            {!loading && previousCost > 0 && (
              <div className="flex items-center gap-1 text-[11px] font-mono">
                {isIncrease ? (
                  <>
                    <TrendingUp className="w-3.5 h-3.5 text-rose-500" />
                    <span className="text-rose-500 font-bold">+{percentageDiff.toFixed(1)}%</span>
                  </>
                ) : (
                  <>
                    <TrendingDown className="w-3.5 h-3.5 text-emerald-500" />
                    <span className="text-emerald-500 font-bold">-{percentageDiff.toFixed(1)}%</span>
                  </>
                )}
                <span className="text-slate-500">vs last month</span>
              </div>
            )}
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-rose-500">
            <DollarSign className="w-5 h-5" />
          </div>
        </div>

        {/* Previous Month Spend */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Previous Month Cost
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-extrabold text-white font-mono leading-none text-slate-300">
                ${loading ? '...' : previousCost.toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400 font-mono font-bold uppercase">{currency}</span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              <span>Full previous calendar month</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-slate-400">
            <Calendar className="w-5 h-5" />
          </div>
        </div>

        {/* Active Billings count */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Total Services Charged
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-extrabold text-sky-400 font-mono leading-none">
                {loading ? '...' : totalServicesCount}
              </span>
              <span className="text-xs text-slate-400 font-medium">AWS namespaces</span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              <span>Cost centers in active billing</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-sky-400">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        {/* Average Daily Spend Estimate */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Est. Daily Burn Rate
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-extrabold text-teal-400 font-mono leading-none">
                ${loading ? '...' : (currentCost / (new Date().getDate() || 1)).toFixed(2)}
              </span>
              <span className="text-[10px] text-slate-400 font-mono font-bold uppercase">USD/day</span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              <span>Estimated from current month run</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-teal-400">
            <CreditCard className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Main Charts area */}
      {showEmptyState ? (
        <div className="p-16 text-center space-y-4 bg-[#0f1422] border border-slate-800/80 rounded-2xl shadow-xl">
          <div className="w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500 mx-auto">
            <BarChart3 className="w-6 h-6 text-rose-500 animate-pulse" />
          </div>
          <div className="space-y-1.5 max-w-md mx-auto">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
              No billing data available.
            </h3>
            <p className="text-xs text-slate-500 leading-relaxed font-mono">
              We couldn't query any active billing metrics for this period. Confirm your account is active and cost allocation tags are configured in AWS billing.
            </p>
          </div>
        </div>
      ) : (
        <div className="space-y-8">
          
          {/* Two Columns for Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            
            {/* 1. Daily Trend Area Chart */}
            <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-rose-500" />
                    Daily Cost Trend
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Burn rate track for the current billing cycle.
                  </p>
                </div>
              </div>

              {loading ? (
                <div className="h-72 bg-slate-900/40 rounded-xl animate-pulse"></div>
              ) : dailyTrend.length === 0 ? (
                <div className="h-72 flex items-center justify-center text-xs font-mono text-slate-600">
                  No trend metrics recorded for the current month.
                </div>
              ) : (
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={dailyTrend} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorCost" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f43f5e" stopOpacity={0.2}/>
                          <stop offset="95%" stopColor="#f43f5e" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b/40" vertical={false} />
                      <XAxis 
                        dataKey="date" 
                        stroke="#475569" 
                        fontSize={10} 
                        fontFamily="JetBrains Mono"
                        tickFormatter={(val) => val.split('-').slice(1).join('/')}
                      />
                      <YAxis 
                        stroke="#475569" 
                        fontSize={10} 
                        fontFamily="JetBrains Mono"
                        tickFormatter={(val) => `$${val}`}
                      />
                      <Tooltip content={<CostTooltip />} />
                      <Area 
                        type="monotone" 
                        dataKey="cost" 
                        name="Daily Spend"
                        stroke="#f43f5e" 
                        strokeWidth={2}
                        fillOpacity={1} 
                        fill="url(#colorCost)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* 2. Service Breakdown Horizontal Bar Chart */}
            <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-1">
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                    <PieChart className="w-4 h-4 text-sky-400" />
                    Service Spend Distribution
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Top cloud resource cost drivers in real-time.
                  </p>
                </div>
              </div>

              {loading ? (
                <div className="h-72 bg-slate-900/40 rounded-xl animate-pulse"></div>
              ) : services.length === 0 ? (
                <div className="h-72 flex items-center justify-center text-xs font-mono text-slate-600">
                  No active service allocations registered.
                </div>
              ) : (
                <div className="h-72 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart 
                      data={services.slice(0, 8)} 
                      layout="vertical"
                      margin={{ top: 10, right: 10, left: -10, bottom: 5 }}
                    >
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b/40" horizontal={false} />
                      <XAxis 
                        type="number" 
                        stroke="#475569" 
                        fontSize={10} 
                        fontFamily="JetBrains Mono"
                        tickFormatter={(val) => `$${val}`}
                      />
                      <YAxis 
                        dataKey="service" 
                        type="category" 
                        stroke="#475569" 
                        fontSize={9} 
                        fontFamily="JetBrains Mono"
                        width={130}
                        tickFormatter={(val) => val.length > 20 ? `${val.substring(0, 18)}...` : val}
                      />
                      <Tooltip content={<CostTooltip />} />
                      <Bar dataKey="cost" name="Service Cost" radius={[0, 4, 4, 0]}>
                        {services.slice(0, 8).map((_, index) => (
                          <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

          </div>

          {/* Table Breakdown */}
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
            
            <div className="p-5 border-b border-slate-800/80 bg-slate-900/10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
                  <CreditCard className="w-4 h-4 text-emerald-400" />
                  Service Billing Breakdown
                </h3>
                <p className="text-xs text-slate-500 font-mono">
                  Detailed audit table of services contributing to the {summary.currency} calculation.
                </p>
              </div>

              {/* Service Search bar */}
              <div className="relative w-full sm:w-64">
                <Search className="w-3.5 h-3.5 text-slate-500 absolute left-3 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search service billing..."
                  className="pl-9 pr-3.5 py-1.5 bg-slate-950 border border-slate-800/80 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-rose-500/40 focus:ring-1 focus:ring-rose-500/20 placeholder-slate-600 w-full transition"
                />
              </div>
            </div>

            {loading ? (
              <div className="p-8 space-y-4">
                <div className="h-8 bg-slate-900 rounded-xl animate-pulse"></div>
                <div className="h-32 bg-slate-900 rounded-xl animate-pulse"></div>
              </div>
            ) : filteredServices.length === 0 ? (
              <div className="p-16 text-center text-xs text-slate-500 font-mono">
                No services found matching search bounds.
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full border-collapse text-left">
                  <thead>
                    <tr className="border-b border-slate-800 bg-slate-900/30 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                      <th className="px-6 py-4">AWS Service</th>
                      <th className="px-6 py-4">Allocated Spend</th>
                      <th className="px-6 py-4">Currency</th>
                      <th className="px-6 py-4">Percentage of Total Cycle Cost</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-800/50 text-xs text-slate-300">
                    {filteredServices.map((item, index) => {
                      const sharePct = ((item.cost / calculatedTotalServicesCost) * 100);
                      return (
                        <tr key={item.service} className="hover:bg-slate-900/10 transition-colors group">
                          
                          {/* Service Name */}
                          <td className="px-6 py-4 font-mono font-bold text-white group-hover:text-rose-400 transition">
                            {item.service}
                          </td>

                          {/* Spend */}
                          <td className="px-6 py-4 font-mono font-semibold text-slate-200">
                            ${item.cost.toFixed(2)}
                          </td>

                          {/* Currency */}
                          <td className="px-6 py-4 font-mono text-slate-500 uppercase font-bold">
                            {currency}
                          </td>

                          {/* Percentage Share */}
                          <td className="px-6 py-4 font-mono">
                            <div className="flex items-center gap-3">
                              <span className="font-bold text-white w-12">{sharePct.toFixed(1)}%</span>
                              <div className="h-1.5 bg-slate-950 rounded-full flex-1 max-w-[120px] overflow-hidden border border-slate-800/40">
                                <div 
                                  className="h-full rounded-full" 
                                  style={{ 
                                    width: `${sharePct}%`,
                                    backgroundColor: COLORS[index % COLORS.length]
                                  }}
                                ></div>
                              </div>
                            </div>
                          </td>

                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}

            {/* Billing Advisory Footer Disclaimer */}
            <div className="p-4 bg-slate-950/60 border-t border-slate-800 text-slate-400 text-xs font-mono flex items-start gap-2.5">
              <Sparkles className="w-4 h-4 shrink-0 mt-0.5 text-rose-500" />
              <div className="space-y-1">
                <p className="font-bold uppercase tracking-wider text-white text-[10px]">
                  AWS Billing Integration Information
                </p>
                <p className="text-[11px] text-slate-500 leading-relaxed">
                  Costs are queried dynamically using AWS Cost Explorer <code className="text-slate-300">get_cost_and_usage()</code> APIs. UnblendedCost aggregates reflect active infrastructure allocations for the designated billing calendar. Creating budgets, altering configurations, purchasing reservations, or making modifications is strictly locked in monitoring mode.
                </p>
              </div>
            </div>

          </div>

        </div>
      )}
        </>
      )}

    </div>
  );
}
