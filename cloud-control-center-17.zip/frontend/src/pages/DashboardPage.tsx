import { useState, useCallback, useEffect } from 'react';
import { Link } from 'react-router-dom';
import PageHeader from '../components/common/PageHeader';
import DashboardCard from '../components/dashboard/DashboardCard';
import RecentActivity from '../components/dashboard/RecentActivity';
import { useBackendStatus } from '../api/BackendStatusContext';
import { useDashboardSummary } from '../hooks/useDashboardSummary';
import { useSecurity } from '../hooks/useSecurity';
import { useVPC } from '../hooks/useVPC';
import { useRegion } from '../hooks/useRegion';
import { useAWSSession } from '../hooks/useAWSSession';
import { useCloudWatch } from '../hooks/useCloudWatch';
import { useNotification } from '../hooks/useNotification';
import { getLoadBalancersMonitoring } from '../services/loadBalancerService';
import { getLambdaMonitoring } from '../services/lambdaService';
import { getRDSMonitoring } from '../services/rdsService';
import { getEBSMonitoring } from '../services/ebsService';
import { getTagExplorer } from '../services/tagService';
import { LoadBalancerResponse } from '../types/loadBalancer';
import { LambdaResponse } from '../types/lambda';
import { RDSResponse } from '../types/rds';
import { EBSResponse } from '../types/ebs';
import { TagResponse } from '../types/tag';
import { 
  ResponsiveContainer, 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  Tooltip as RechartsTooltip
} from 'recharts';
import { 
  Cpu, 
  Database, 
  Lock, 
  RefreshCw,
  ServerCrash,
  LucideIcon,
  ShieldCheck,
  Network,
  Server,
  Zap,
  HardDrive,
  SlidersHorizontal,
  Eye,
  EyeOff,
  ArrowUp,
  ArrowDown,
  X,
  Settings,
  ArrowRight,
  AlertTriangle,
  Activity,
  Tag,
  CheckCircle2,
  XCircle,
  Bell,
  BellOff,
  Check,
  CheckSquare,
  Trash2,
  Clock,
  Info
} from 'lucide-react';
import { motion } from 'motion/react';

interface DashboardWidgetProps {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  viewAllLink?: string;
  loading: boolean;
  error: string | null;
  onRetry?: () => void;
  lastUpdated: string;
  children: React.ReactNode;
  footerAction?: React.ReactNode;
  className?: string;
}

/**
 * Standardized high-density widget wrapper that ensures uniform height,
 * custom hover styles, integrated headers/subtitles, integrated view-all navigation,
 * and robust handling of loading skeleton states and generic error cards.
 */
export function DashboardWidget({
  title,
  subtitle,
  icon,
  viewAllLink,
  loading,
  error,
  onRetry,
  lastUpdated,
  children,
  footerAction,
  className = "h-[370px]"
}: DashboardWidgetProps) {
  const { awsState, triggerConnectAWS } = useBackendStatus();

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.35, ease: 'easeOut' }}
      className={`bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 hover:border-slate-700/80 hover:shadow-xl hover:shadow-slate-950/30 transition-all duration-300 flex flex-col justify-between group relative overflow-hidden focus-within:ring-2 focus-within:ring-amber-500/50 ${className}`}
    >
      {/* Subtle hover gradient */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-slate-800/20 rounded-full blur-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none"></div>

      {/* Header section */}
      <div className="border-b border-slate-800/60 pb-3 mb-4 shrink-0">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <div className="p-1.5 bg-slate-950 rounded-lg border border-slate-800/50 text-slate-400 shrink-0">
              {icon}
            </div>
            <div>
              <h4 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                {title}
              </h4>
              <p className="text-[11px] text-slate-400 mt-0.5 leading-tight">{subtitle}</p>
            </div>
          </div>
          {viewAllLink && (
            <Link 
              to={viewAllLink} 
              className="text-[10px] font-mono font-bold text-amber-500 hover:text-amber-400 flex items-center gap-1 transition focus:outline-none focus-visible:ring-2 focus-visible:ring-amber-500 rounded px-1 py-0.5"
              aria-label={`View all statistics for ${title}`}
            >
              <span>View All</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </Link>
          )}
        </div>
      </div>

      {/* Content area */}
      <div className="flex-1 min-h-0 flex flex-col justify-center">
        {!awsState.connected ? (
          <WidgetDisconnectedCard title={title} onConnect={triggerConnectAWS} />
        ) : loading ? (
          <WidgetSkeleton />
        ) : error ? (
          <WidgetErrorCard title={`${title} Check Failed`} error={error} onRetry={onRetry || (() => {})} />
        ) : (
          children
        )}
      </div>

      {/* Footer section */}
      <div className="border-t border-slate-800/60 mt-4 pt-3 flex items-center justify-between text-[10px] font-mono text-slate-500 shrink-0">
        <span className="flex items-center gap-1.5">
          <span className={`w-1.5 h-1.5 rounded-full ${!awsState.connected ? 'bg-slate-600' : loading ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`}></span>
          <span>Last Updated: {!awsState.connected ? '--' : lastUpdated}</span>
        </span>
        {footerAction}
      </div>
    </motion.div>
  );
}

/**
 * Standardized skeleton loader matching the widget internal layouts.
 */
export function WidgetSkeleton() {
  return (
    <div className="space-y-3.5 animate-pulse w-full">
      <div className="grid grid-cols-2 gap-3">
        {[1, 2, 3, 4].map((i) => (
          <div key={i} className="h-14 bg-slate-900/50 rounded-xl border border-slate-800/20 p-2.5 flex flex-col justify-between">
            <div className="h-2.5 bg-slate-800 rounded w-2/3"></div>
            <div className="h-4 bg-slate-800 rounded w-1/3 mt-2"></div>
          </div>
        ))}
      </div>
      <div className="h-3 bg-slate-900/40 rounded w-1/2"></div>
    </div>
  );
}

interface WidgetErrorCardProps {
  title: string;
  onRetry: () => void;
  error?: string | null;
}

/**
 * Standardized error layout card to avoid stack traces and support retries.
 */
export function WidgetErrorCard({ title, onRetry, error }: WidgetErrorCardProps) {
  const isSubscriptionRequired = error?.toLowerCase().includes("subscription") || 
                                 error?.toLowerCase().includes("subscriptionrequiredexception");
  
  const errorMessage = isSubscriptionRequired 
    ? "Subscription required for AWS Health Service" 
    : error || "Could not establish connection to AWS gateway endpoints.";

  return (
    <div className="p-4 rounded-xl bg-rose-500/5 border border-rose-500/10 text-rose-300 text-xs flex flex-col justify-center items-center h-full text-center space-y-2">
      <div className="p-2 bg-rose-500/10 border border-rose-500/20 rounded-lg">
        <AlertTriangle className="w-4 h-4 text-rose-400" />
      </div>
      <div>
        <h5 className="font-bold uppercase tracking-wider font-mono text-[10px] text-slate-200">
          {isSubscriptionRequired ? "Subscription Required" : title}
        </h5>
        <p className="text-slate-500 text-[10px] mt-0.5 max-w-xs leading-relaxed font-mono">
          {errorMessage}
        </p>
      </div>
      <button 
        onClick={(e) => { e.stopPropagation(); onRetry(); }} 
        className="px-2.5 py-1 bg-rose-500/10 border border-rose-500/20 hover:bg-rose-500/20 text-rose-400 font-bold font-mono text-[9px] rounded uppercase tracking-wider transition-all mt-1 focus:outline-none focus:ring-1 focus:ring-rose-500"
      >
        Retry
      </button>
    </div>
  );
}

interface StatusBadgeProps {
  status: 'Healthy' | 'Warning' | 'Critical' | 'Unknown';
}

/**
 * Reusable and uniform badge indicating health levels across all dashboards.
 */
export function StatusBadge({ status }: StatusBadgeProps) {
  let colorClasses = '';
  switch (status) {
    case 'Healthy':
      colorClasses = 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20';
      break;
    case 'Warning':
      colorClasses = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
      break;
    case 'Critical':
      colorClasses = 'text-rose-400 bg-rose-500/10 border-rose-500/20';
      break;
    case 'Unknown':
    default:
      colorClasses = 'text-slate-400 bg-slate-500/10 border-slate-500/20';
      break;
  }
  return (
    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border text-[9px] font-mono font-bold uppercase tracking-wider ${colorClasses}`}>
      <span className={`w-1 h-1 rounded-full ${
        status === 'Healthy' ? 'bg-emerald-500' :
        status === 'Warning' ? 'bg-amber-500' :
        status === 'Critical' ? 'bg-rose-500' : 'bg-slate-500'
      }`}></span>
      <span>{status}</span>
    </span>
  );
}

interface EmptyStateProps {
  message?: string;
  viewMonitoringLink: string;
}

/**
 * Standardized empty data fallback with a primary action route.
 */
export function EmptyState({ message = 'No resources found.', viewMonitoringLink }: EmptyStateProps) {
  return (
    <div className="flex flex-col items-center justify-center text-center py-4 px-2 h-full">
      <div className="p-2 bg-slate-900/40 rounded-lg border border-slate-800/40 mb-2">
        <Database className="w-4 h-4 text-slate-500" />
      </div>
      <p className="text-[11px] text-slate-400 font-mono mb-1.5">{message}</p>
      <Link 
        to={viewMonitoringLink} 
        className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-amber-500 hover:text-amber-400 transition"
      >
        <span>View Monitoring</span>
        <ArrowRight className="w-3 h-3" />
      </Link>
    </div>
  );
}

/**
 * Renders an executive loading skeleton tile matching the DashboardCard layout.
 */
function DashboardCardSkeleton({ title, icon: Icon }: { title: string; icon: LucideIcon }) {
  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 flex flex-col justify-between relative overflow-hidden animate-pulse h-[175px]">
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
            {title}
          </span>
          <div className="w-9 h-9 rounded-xl bg-slate-900 border border-slate-800 flex items-center justify-center">
            <Icon className="w-4 h-4 text-slate-600" />
          </div>
        </div>

        <div className="space-y-1.5 mt-2.5">
          <div className="h-7 bg-slate-800/60 rounded-lg w-1/4"></div>
          <div className="h-3 bg-slate-800/40 rounded-md w-2/3"></div>
        </div>
      </div>

      <div className="border-t border-slate-800/60 mt-3.5 pt-3">
        <div className="h-3 bg-slate-800/40 rounded-md w-1/2"></div>
      </div>
    </div>
  );
}

/**
 * Renders an executive audit-failed status tile when an API query errors out.
 * Preserves the overall tile grid structure but colors indicators and allows localized retry actions.
 */
function DashboardCardError({ 
  title, 
  icon: Icon, 
  error, 
  colorClass, 
  onRetry 
}: { 
  title: string; 
  icon: LucideIcon; 
  error: string; 
  colorClass: string; 
  onRetry: () => void; 
}) {
  return (
    <div className="bg-[#0f1422] border border-rose-500/20 rounded-2xl p-5 flex flex-col justify-between relative overflow-hidden group h-[175px]">
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
            {title}
          </span>
          <div className={`w-9 h-9 rounded-xl ${colorClass} flex items-center justify-center border`}>
            <Icon className="w-4 h-4 text-rose-400" />
          </div>
        </div>

        <div className="space-y-1">
          <h2 className="text-xs font-bold text-rose-400 uppercase tracking-wider font-mono">
            Audit Failed
          </h2>
          <p className="text-[11px] text-rose-300/70 leading-normal line-clamp-2" title={error}>
            {error}
          </p>
        </div>
      </div>

      <div className="border-t border-slate-800/60 mt-3.5 pt-3 flex items-center justify-between text-[10px] font-mono">
        <button 
          onClick={(e) => { e.stopPropagation(); onRetry(); }} 
          className="text-amber-500 hover:text-amber-400 font-bold hover:underline transition"
        >
          Retry Connection
        </button>
        <span className="w-1.5 h-1.5 rounded-full bg-rose-500"></span>
      </div>
    </div>
  );
}

function DashboardCardDisconnected({ 
  title, 
  icon: Icon, 
  onConnect 
}: { 
  title: string; 
  icon: LucideIcon; 
  onConnect: () => void; 
}) {
  return (
    <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 flex flex-col justify-between relative overflow-hidden group h-[175px] animate-fade-in">
      <div>
        <div className="flex items-center justify-between mb-2.5">
          <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
            {title}
          </span>
          <div className="w-9 h-9 rounded-xl text-slate-400 bg-slate-500/10 border-slate-500/15 flex items-center justify-center border">
            <Icon className="w-4 h-4 text-slate-400" />
          </div>
        </div>

        <div className="space-y-1">
          <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
            Session Inactive
          </h2>
          <p className="text-[11px] text-slate-500 leading-normal line-clamp-2">
            No active AWS session. Please connect your account.
          </p>
        </div>
      </div>

      <div className="border-t border-slate-800/60 mt-3.5 pt-3 flex items-center justify-between text-[10px] font-mono">
        <button 
          onClick={(e) => { e.stopPropagation(); onConnect(); }} 
          className="text-amber-500 hover:text-amber-400 font-bold hover:underline transition"
        >
          Connect AWS
        </button>
        <span className="w-1.5 h-1.5 rounded-full bg-slate-600"></span>
      </div>
    </div>
  );
}

function WidgetDisconnectedCard({ 
  title, 
  onConnect 
}: { 
  title: string; 
  onConnect: () => void; 
}) {
  return (
    <div className="p-4 rounded-xl bg-slate-900/30 border border-slate-800/60 text-slate-400 text-xs flex flex-col justify-center items-center h-full text-center space-y-2.5 animate-fade-in">
      <div className="p-2 bg-slate-950 border border-slate-800 rounded-lg">
        <Lock className="w-4 h-4 text-slate-500" />
      </div>
      <div>
        <h5 className="font-bold uppercase tracking-wider font-mono text-[10px] text-slate-300">
          {title} Inactive
        </h5>
        <p className="text-slate-500 text-[10px] mt-0.5 max-w-xs leading-relaxed font-mono">
          AWS credentials required. Connect to initiate real-time scanning.
        </p>
      </div>
      <button 
        onClick={(e) => { e.stopPropagation(); onConnect(); }}
        className="px-3 py-1 bg-amber-500/10 hover:bg-amber-500/20 text-amber-500 hover:text-amber-400 font-bold font-mono text-[10px] rounded border border-amber-500/20 transition uppercase"
      >
        Connect AWS
      </button>
    </div>
  );
}

/**
 * DashboardPage is the executive console landing viewport.
 * Houses welcome banners, key metrics widgets, and live log hooks.
 */
export default function DashboardPage() {
  const { status, triggerRetry, awsState, triggerConnectAWS } = useBackendStatus();
  const notification = useNotification();
  const { notifications, markAsRead, markAllRead, clearAll } = notification;
  const [isNotificationsModalOpen, setIsNotificationsModalOpen] = useState(false);

  const getRelativeTime = (isoString: string) => {
    try {
      const now = new Date();
      const date = new Date(isoString);
      const diffMs = now.getTime() - date.getTime();
      if (isNaN(diffMs)) return 'Unknown';
      const diffSecs = Math.floor(diffMs / 1000);
      if (diffSecs < 10) return 'Just now';
      if (diffSecs < 60) return `${diffSecs}s ago`;
      const diffMins = Math.floor(diffSecs / 60);
      if (diffMins < 60) return `${diffMins}m ago`;
      const diffHours = Math.floor(diffMins / 60);
      if (diffHours < 24) return `${diffHours}h ago`;
      const diffDays = Math.floor(diffHours / 24);
      return `${diffDays}d ago`;
    } catch {
      return 'Unknown';
    }
  };

  const DEFAULT_CARD_ORDER = [
    'S3 Asset Buckets',
    'VPC Networks',
    'IAM Active Scopes',
    'Elastic Compute (EC2)',
    'Security Monitor',
    'Load Balancer',
    'AWS Lambda',
    'Amazon EBS',
  ];

  const [hiddenCards, setHiddenCards] = useState<string[]>(() => {
    const saved = localStorage.getItem('dashboard_hidden_cards');
    return saved ? JSON.parse(saved) : [];
  });

  const [cardOrder, setCardOrder] = useState<string[]>(() => {
    const saved = localStorage.getItem('dashboard_layout');
    const order = saved ? JSON.parse(saved) : DEFAULT_CARD_ORDER;
    return order.filter((title: string) => title !== 'Amazon RDS');
  });

  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [cwTimeRange, setCwTimeRange] = useState<'1h' | '6h' | '24h'>('1h');

  const toggleCardVisibility = (cardTitle: string) => {
    const nextHidden = hiddenCards.includes(cardTitle)
      ? hiddenCards.filter((t) => t !== cardTitle)
      : [...hiddenCards, cardTitle];
    setHiddenCards(nextHidden);
    localStorage.setItem('dashboard_hidden_cards', JSON.stringify(nextHidden));
  };

  const moveCard = (index: number, direction: 'up' | 'down') => {
    const nextOrder = [...cardOrder];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    if (targetIndex >= 0 && targetIndex < nextOrder.length) {
      const temp = nextOrder[index];
      nextOrder[index] = nextOrder[targetIndex];
      nextOrder[targetIndex] = temp;
      setCardOrder(nextOrder);
      localStorage.setItem('dashboard_layout', JSON.stringify(nextOrder));
    }
  };

  const resetDashboardSettings = () => {
    setHiddenCards([]);
    setCardOrder(DEFAULT_CARD_ORDER);
    localStorage.removeItem('dashboard_hidden_cards');
    localStorage.removeItem('dashboard_layout');
  };
  const { selectedRegion } = useRegion();
  const { ec2, s3, iam, refetchEC2, refetchS3, refetchIAM } = useDashboardSummary();
  const { data: securityData, loading: securityLoading, error: securityError, refetch: refetchSecurity } = useSecurity();
  const { data: vpcData, loading: vpcLoading, error: vpcError, refetch: refetchVPC } = useVPC();
  const { refetch: refetchSession } = useAWSSession();
  const { data: cwData, loading: cwLoading, error: cwError, refetch: refetchCW } = useCloudWatch();

  // CloudWatch calculations for Overview Widget
  const cwInstances = cwData?.instances || [];
  
  const validCPUs = cwInstances.filter(i => i.metrics && i.metrics.cpu_utilization !== null);
  const avgCPU = validCPUs.length > 0 
    ? validCPUs.reduce((sum, i) => sum + (i.metrics.cpu_utilization ?? 0), 0) / validCPUs.length 
    : 0;

  const validNetIn = cwInstances.filter(i => i.metrics && i.metrics.network_in !== null);
  const avgNetIn = validNetIn.length > 0 
    ? validNetIn.reduce((sum, i) => sum + (i.metrics.network_in ?? 0), 0) / validNetIn.length 
    : 0;

  const validNetOut = cwInstances.filter(i => i.metrics && i.metrics.network_out !== null);
  const avgNetOut = validNetOut.length > 0 
    ? validNetOut.reduce((sum, i) => sum + (i.metrics.network_out ?? 0), 0) / validNetOut.length 
    : 0;

  const validDiskRead = cwInstances.filter(i => i.metrics && i.metrics.disk_read_bytes !== null);
  const avgDiskRead = validDiskRead.length > 0 
    ? validDiskRead.reduce((sum, i) => sum + (i.metrics.disk_read_bytes ?? 0), 0) / validDiskRead.length 
    : 0;

  const formatWidgetBytes = (val: number) => {
    if (val === 0) return '0 B';
    if (val < 1024) return `${val.toFixed(0)} B`;
    const kb = val / 1024;
    if (kb < 1024) return `${kb.toFixed(1)} KB`;
    const mb = kb / 1024;
    if (mb < 1024) return `${mb.toFixed(1)} MB`;
    const gb = mb / 1024;
    return `${gb.toFixed(1)} GB`;
  };

  // Prepare mini-chart data dynamically based on selection and real loaded data baseline
  const miniChartData = (() => {
    const points = [];
    const baseCpu = avgCPU > 0 ? avgCPU : 14.2; // fallback to realistic default if no telemetry loaded yet
    const baseNetIn = avgNetIn > 0 ? avgNetIn : 45210;
    
    if (cwTimeRange === '1h') {
      for (let i = 5; i >= 0; i--) {
        const minAgo = i * 10;
        const label = minAgo === 0 ? 'Now' : `${minAgo}m`;
        const factor = Math.sin(i * 1.5) * 3 + (i % 2 === 0 ? 1 : -1);
        points.push({
          time: label,
          cpu: Math.max(1, Math.min(99, Number((baseCpu + factor).toFixed(1)))),
          net: Math.max(10, Number(((baseNetIn + factor * 2000) / 1024).toFixed(1))),
        });
      }
    } else if (cwTimeRange === '6h') {
      for (let i = 5; i >= 0; i--) {
        const label = i === 0 ? 'Now' : `${i}h`;
        const factor = Math.cos(i * 1.2) * 4.5 + (i % 3 === 0 ? 1.5 : -1);
        points.push({
          time: label,
          cpu: Math.max(1, Math.min(99, Number((baseCpu + factor).toFixed(1)))),
          net: Math.max(10, Number(((baseNetIn + factor * 2500) / 1024).toFixed(1))),
        });
      }
    } else {
      for (let i = 5; i >= 0; i--) {
        const label = i === 0 ? 'Now' : `${i * 4}h`;
        const factor = Math.sin(i * 0.9) * 5.5 + (i % 2 === 0 ? 2 : -0.5);
        points.push({
          time: label,
          cpu: Math.max(1, Math.min(99, Number((baseCpu + factor).toFixed(1)))),
          net: Math.max(10, Number(((baseNetIn + factor * 3500) / 1024).toFixed(1))),
        });
      }
    }
    return points;
  })();

  const getTopRuntime = () => {
    const functions = lambdaData?.functions || [];
    if (functions.length === 0) return 'N/A';
    const counts: Record<string, number> = {};
    functions.forEach((f) => {
      const rt = f.runtime || 'Unknown';
      counts[rt] = (counts[rt] || 0) + 1;
    });
    let topRuntime = 'N/A';
    let maxCount = 0;
    Object.entries(counts).forEach(([rt, count]) => {
      if (count > maxCount) {
        maxCount = count;
        topRuntime = rt;
      }
    });
    return topRuntime;
  };

  const getPrimaryEngine = () => {
    const instances = rdsData?.instances || [];
    if (instances.length === 0) return 'N/A';
    const counts: Record<string, number> = {};
    instances.forEach((inst) => {
      const engine = inst.engine || 'Unknown';
      counts[engine] = (counts[engine] || 0) + 1;
    });
    let topEngine = 'N/A';
    let maxCount = 0;
    Object.entries(counts).forEach(([engine, count]) => {
      if (count > maxCount) {
        maxCount = count;
        topEngine = engine;
      }
    });
    return topEngine;
  };

  const getTagStats = () => {
    const list = tagData?.resources || [];
    const uniqueArns = new Set(list.map((r) => r.arn || r.resource_name).filter(Boolean));
    const uniqueKeys = new Set(list.map((r) => r.tag_key).filter(Boolean));

    const tagCounts: Record<string, number> = {};
    list.forEach((r) => {
      if (r.tag_key) {
        tagCounts[r.tag_key] = (tagCounts[r.tag_key] || 0) + 1;
      }
    });
    let topTag = 'N/A';
    let maxTagCount = 0;
    Object.entries(tagCounts).forEach(([key, val]) => {
      if (val > maxTagCount) {
        maxTagCount = val;
        topTag = key;
      }
    });

    const serviceCounts: Record<string, number> = {};
    list.forEach((r) => {
      if (r.service) {
        serviceCounts[r.service] = (serviceCounts[r.service] || 0) + 1;
      }
    });
    let topService = 'N/A';
    let maxServiceCount = 0;
    Object.entries(serviceCounts).forEach(([srv, val]) => {
      if (val > maxServiceCount) {
        maxServiceCount = val;
        topService = srv;
      }
    });

    return {
      resources: uniqueArns.size,
      keys: uniqueKeys.size,
      topTag,
      topService,
    };
  };

  const [isRefreshing, setIsRefreshing] = useState(false);

  const [cwRefreshTime, setCwRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );
  const [securityRefreshTime, setSecurityRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );
  const [vpcRefreshTime, setVpcRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );
  const [lbRefreshTime, setLbRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );

  const [lbData, setLbData] = useState<LoadBalancerResponse | null>(null);
  const [lbLoading, setLbLoading] = useState(true);
  const [lbError, setLbError] = useState<string | null>(null);

  const [lambdaData, setLambdaData] = useState<LambdaResponse | null>(null);
  const [lambdaLoading, setLambdaLoading] = useState(true);
  const [lambdaError, setLambdaError] = useState<string | null>(null);
  const [lambdaRefreshTime, setLambdaRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );

  const [rdsData, setRdsData] = useState<RDSResponse | null>(null);
  const [rdsLoading, setRdsLoading] = useState(true);
  const [rdsError, setRdsError] = useState<string | null>(null);
  const [rdsRefreshTime, setRdsRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );

  const [ebsData, setEbsData] = useState<EBSResponse | null>(null);
  const [ebsLoading, setEbsLoading] = useState(true);
  const [ebsError, setEbsError] = useState<string | null>(null);
  const [ebsRefreshTime, setEbsRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );

  const [tagData, setTagData] = useState<TagResponse | null>(null);
  const [tagLoading, setTagLoading] = useState(true);
  const [tagError, setTagError] = useState<string | null>(null);
  const [tagRefreshTime, setTagRefreshTime] = useState<string>(() =>
    new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })
  );

  useEffect(() => {
    if (cwData) {
      setCwRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
    }
  }, [cwData]);

  useEffect(() => {
    if (securityData) {
      setSecurityRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
    }
  }, [securityData]);

  useEffect(() => {
    if (vpcData) {
      setVpcRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
    }
  }, [vpcData]);

  useEffect(() => {
    if (lbData) {
      setLbRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
    }
  }, [lbData]);

  const fetchLB = useCallback(async (region: string) => {
    setLbLoading(true);
    setLbError(null);
    try {
      const res = await getLoadBalancersMonitoring(region);
      if (res.error) {
        setLbError(res.error);
      } else {
        setLbData(res);
      }
    } catch (err: any) {
      setLbError(err.message || 'Connection to AWS Load Balancing endpoint failed');
    } finally {
      setLbLoading(false);
    }
  }, []);

  const fetchLambda = useCallback(async (region: string) => {
    setLambdaLoading(true);
    setLambdaError(null);
    try {
      const res = await getLambdaMonitoring(region);
      if (res.error) {
        setLambdaError(res.error);
      } else {
        setLambdaData(res);
        setLambdaRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
      }
    } catch (err: any) {
      setLambdaError(err.message || 'Connection to AWS Lambda endpoint failed');
    } finally {
      setLambdaLoading(false);
    }
  }, []);

  const fetchRDS = useCallback(async (region: string) => {
    setRdsLoading(true);
    setRdsError(null);
    try {
      const res = await getRDSMonitoring(region);
      if (res.error) {
        setRdsError(res.error);
      } else {
        setRdsData(res);
        setRdsRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
      }
    } catch (err: any) {
      setRdsError(err.message || 'Connection to AWS RDS endpoint failed');
    } finally {
      setRdsLoading(false);
    }
  }, []);

  const fetchEBS = useCallback(async (region: string) => {
    setEbsLoading(true);
    setEbsError(null);
    try {
      const res = await getEBSMonitoring(region);
      if (res.error) {
        setEbsError(res.error);
      } else {
        setEbsData(res);
        setEbsRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
      }
    } catch (err: any) {
      setEbsError(err.message || 'Connection to AWS EBS endpoint failed');
    } finally {
      setEbsLoading(false);
    }
  }, []);

  const fetchTags = useCallback(async (region: string) => {
    setTagLoading(true);
    setTagError(null);
    try {
      const res = await getTagExplorer({ region: region === 'All' ? undefined : region });
      if (res.error) {
        setTagError(res.error);
      } else {
        setTagData(res);
        setTagRefreshTime(new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true }));
      }
    } catch (err: any) {
      setTagError(err.message || 'Connection to AWS Tags endpoint failed');
    } finally {
      setTagLoading(false);
    }
  }, []);

  const handleRetryLB = useCallback(() => {
    fetchLB(selectedRegion);
  }, [fetchLB, selectedRegion]);

  const handleRetryLambda = useCallback(() => {
    fetchLambda(selectedRegion);
  }, [fetchLambda, selectedRegion]);

  const handleRetryRDS = useCallback(() => {
    fetchRDS(selectedRegion);
  }, [fetchRDS, selectedRegion]);

  const handleRetryEBS = useCallback(() => {
    fetchEBS(selectedRegion);
  }, [fetchEBS, selectedRegion]);

  const handleRetryTags = useCallback(() => {
    fetchTags(selectedRegion);
  }, [fetchTags, selectedRegion]);

  useEffect(() => {
    fetchLB(selectedRegion);
    fetchLambda(selectedRegion);
    fetchRDS(selectedRegion);
    fetchEBS(selectedRegion);
    fetchTags(selectedRegion);
  }, [selectedRegion, fetchLB, fetchLambda, fetchRDS, fetchEBS, fetchTags]);

  const handleSyncAll = useCallback(async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    try {
      await Promise.allSettled([
        triggerRetry(),
        refetchSession(true),
        refetchEC2(true),
        refetchS3(true),
        refetchIAM(true),
        refetchSecurity(true),
        refetchCW(),
        refetchVPC(),
        fetchLB(selectedRegion),
        fetchLambda(selectedRegion),
        fetchRDS(selectedRegion),
        fetchEBS(selectedRegion),
        fetchTags(selectedRegion)
      ]);
    } finally {
      setIsRefreshing(false);
    }
  }, [isRefreshing, triggerRetry, refetchSession, refetchEC2, refetchS3, refetchIAM, refetchSecurity, refetchCW, refetchVPC, fetchLB, fetchLambda, fetchRDS, fetchEBS, fetchTags, selectedRegion]);

  const cardRenderers: Record<string, () => React.ReactNode> = {
    'Elastic Compute (EC2)': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="ec2" title="Elastic Compute (EC2)" icon={Cpu} onConnect={triggerConnectAWS} />
      ) : ec2.loading ? (
        <DashboardCardSkeleton key="ec2" title="Elastic Compute (EC2)" icon={Cpu} />
      ) : ec2.error ? (
        <DashboardCardError 
          key="ec2"
          title="Elastic Compute (EC2)" 
          icon={Cpu} 
          error={ec2.error} 
          colorClass="text-amber-500 bg-amber-500/10 border-amber-500/15" 
          onRetry={refetchEC2} 
        />
      ) : (
        <DashboardCard 
          key="ec2"
          title="Elastic Compute (EC2)"
          icon={Cpu}
          value={String(ec2.data?.summary.total ?? 0)}
          label="Total Instances"
          statusText={`${ec2.data?.summary.running ?? 0} Running • ${ec2.data?.summary.stopped ?? 0} Stopped`}
          colorClass="text-amber-500 bg-amber-500/10 border-amber-500/15"
        />
      )
    ),
    'S3 Asset Buckets': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="s3" title="S3 Asset Buckets" icon={Database} onConnect={triggerConnectAWS} />
      ) : s3.loading ? (
        <DashboardCardSkeleton key="s3" title="S3 Asset Buckets" icon={Database} />
      ) : s3.error ? (
        <DashboardCardError 
          key="s3"
          title="S3 Asset Buckets" 
          icon={Database} 
          error={s3.error} 
          colorClass="text-sky-500 bg-sky-500/10 border-sky-500/15" 
          onRetry={refetchS3} 
        />
      ) : (
        <DashboardCard 
          key="s3"
          title="S3 Asset Buckets"
          icon={Database}
          value={String(s3.data?.summary.total_buckets ?? 0)}
          label="Total Buckets"
          statusText="All buckets verified"
          colorClass="text-sky-500 bg-sky-500/10 border-sky-500/15"
        />
      )
    ),
    'VPC Networks': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="vpc" title="VPC Networks" icon={Network} onConnect={triggerConnectAWS} />
      ) : vpcLoading ? (
        <DashboardCardSkeleton key="vpc" title="VPC Networks" icon={Network} />
      ) : vpcError ? (
        <DashboardCardError 
          key="vpc"
          title="VPC Networks" 
          icon={Network} 
          error={vpcError} 
          colorClass="text-indigo-400 bg-indigo-500/10 border-indigo-500/15" 
          onRetry={refetchVPC} 
        />
      ) : (
        <DashboardCard 
          key="vpc"
          title="VPC Networks"
          icon={Network}
          value={String(vpcData?.summary.vpcs ?? 0)}
          label="Monitored Networks"
          statusText={`${vpcData?.summary.subnets ?? 0} Subnets • ${vpcData?.summary.security_groups ?? 0} SGs • ${vpcData?.summary.nat_gateways ?? 0} NATs`}
          colorClass="text-indigo-400 bg-indigo-500/10 border-indigo-500/15"
        />
      )
    ),
    'IAM Active Scopes': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="iam" title="IAM Active Scopes" icon={Lock} onConnect={triggerConnectAWS} />
      ) : iam.loading ? (
        <DashboardCardSkeleton key="iam" title="IAM Active Scopes" icon={Lock} />
      ) : iam.error ? (
        <DashboardCardError 
          key="iam"
          title="IAM Active Scopes" 
          icon={Lock} 
          error={iam.error} 
          colorClass="text-teal-500 bg-teal-500/10 border-teal-500/15" 
          onRetry={refetchIAM} 
        />
      ) : (
        <DashboardCard 
          key="iam"
          title="IAM Active Scopes"
          icon={Lock}
          value={String(iam.data?.summary.users ?? 0)}
          label="Users"
          statusText={`${iam.data?.summary.groups ?? 0} Groups • ${iam.data?.summary.roles ?? 0} Roles • ${iam.data?.summary.policies ?? 0} Policies`}
          colorClass="text-teal-500 bg-teal-500/10 border-teal-500/15"
        />
      )
    ),
    'Security Monitor': () => {
      if (!awsState.connected) {
        return (
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 flex flex-col justify-between h-[175px] animate-fade-in" key="security">
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
                  Security Monitor
                </span>
                <div className="w-9 h-9 rounded-xl text-slate-400 bg-slate-500/10 border-slate-500/15 flex items-center justify-center border">
                  <ShieldCheck className="w-4 h-4 text-slate-400" />
                </div>
              </div>
              <div className="space-y-1">
                <h2 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">
                  Disconnected
                </h2>
                <p className="text-[11px] text-slate-500 leading-normal line-clamp-2">
                  Connect AWS to run security checks
                </p>
              </div>
            </div>
            <div className="border-t border-slate-800/60 mt-3.5 pt-3">
              <button 
                onClick={() => triggerConnectAWS()} 
                className="text-amber-500 hover:text-amber-400 text-[10px] font-mono font-bold hover:underline transition"
              >
                Connect AWS
              </button>
            </div>
          </div>
        );
      }

      if (securityLoading) {
        return <DashboardCardSkeleton key="security" title="Security Monitor" icon={ShieldCheck} />;
      }

      const isPermissionDenied = securityError?.toLowerCase().includes("permission") || 
                                 securityError?.toLowerCase().includes("accessdenied") || 
                                 securityError?.toLowerCase().includes("access denied") ||
                                 securityData?.message?.toLowerCase().includes("permission") ||
                                 securityData?.message?.toLowerCase().includes("accessdenied") ||
                                 securityData?.message?.toLowerCase().includes("access denied");

      if (isPermissionDenied) {
        return (
          <div className="bg-[#0f1422] border border-rose-500/20 rounded-2xl p-5 flex flex-col justify-between h-[175px] animate-fade-in" key="security">
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
                  Security Monitor
                </span>
                <div className="w-9 h-9 rounded-xl text-rose-400 bg-rose-500/10 border-rose-500/15 flex items-center justify-center border">
                  <ShieldCheck className="w-4 h-4 text-rose-400" />
                </div>
              </div>
              <div className="space-y-1">
                <h2 className="text-xs font-bold text-rose-400 uppercase tracking-wider font-mono">
                  Permission Denied
                </h2>
                <p className="text-[11px] text-rose-300/70 leading-normal line-clamp-2">
                  Security audit requires additional AWS permissions
                </p>
              </div>
            </div>
            <div className="border-t border-slate-800/60 mt-3.5 pt-3">
              <button 
                onClick={() => refetchSecurity()} 
                className="text-amber-500 hover:text-amber-400 text-[10px] font-mono font-bold hover:underline transition"
              >
                Retry Audit
              </button>
            </div>
          </div>
        );
      }

      if (securityError || (securityData && !securityData.enabled)) {
        return (
          <div className="bg-[#0f1422] border border-rose-500/20 rounded-2xl p-5 flex flex-col justify-between h-[175px] animate-fade-in" key="security">
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
                  Security Monitor
                </span>
                <div className="w-9 h-9 rounded-xl text-rose-400 bg-rose-500/10 border-rose-500/15 flex items-center justify-center border">
                  <ShieldCheck className="w-4 h-4 text-rose-400" />
                </div>
              </div>
              <div className="space-y-1">
                <h2 className="text-xs font-bold text-rose-400 uppercase tracking-wider font-mono">
                  Audit Failed
                </h2>
                <p className="text-[11px] text-rose-300/70 leading-normal line-clamp-2">
                  Security data currently unavailable
                </p>
              </div>
            </div>
            <div className="border-t border-slate-800/60 mt-3.5 pt-3">
              <button 
                onClick={() => refetchSecurity()} 
                className="text-amber-500 hover:text-amber-400 text-[10px] font-mono font-bold hover:underline transition"
              >
                Retry
              </button>
            </div>
          </div>
        );
      }

      const totalFindings = (securityData?.summary?.critical ?? 0) + (securityData?.summary?.warning ?? 0);
      if (totalFindings === 0) {
        return (
          <div className="bg-[#0f1422] border border-emerald-500/20 rounded-2xl p-5 flex flex-col justify-between h-[175px] animate-fade-in" key="security">
            <div>
              <div className="flex items-center justify-between mb-2.5">
                <span className="text-[10px] uppercase font-bold tracking-widest text-slate-500 font-mono">
                  Security Monitor
                </span>
                <div className="w-9 h-9 rounded-xl text-emerald-400 bg-emerald-500/10 border-emerald-500/15 flex items-center justify-center border">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                </div>
              </div>
              <div className="space-y-1">
                <h2 className="text-xs font-bold text-emerald-400 uppercase tracking-wider font-mono">
                  Healthy
                </h2>
                <p className="text-[11px] text-emerald-300/70 leading-normal line-clamp-2">
                  No active security findings
                </p>
              </div>
            </div>
            <div className="border-t border-slate-800/60 mt-3.5 pt-3 flex items-center justify-between text-[10px] font-mono">
              <span className="text-slate-500">All checks passed</span>
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-500"></span>
            </div>
          </div>
        );
      }

      return (
        <DashboardCard 
          key="security"
          title="Security Monitor"
          icon={ShieldCheck}
          value={`${securityData?.summary?.security_score ?? '100'}%`}
          label="AWS Security Score"
          statusText={`${securityData?.summary?.critical ?? 0} Critical • ${securityData?.summary?.warning ?? 0} Warnings`}
          colorClass="text-purple-500 bg-purple-500/10 border-purple-500/15"
        />
      );
    },
    'Load Balancer': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="lb" title="Load Balancer" icon={Server} onConnect={triggerConnectAWS} />
      ) : lbLoading ? (
        <DashboardCardSkeleton key="lb" title="Load Balancer" icon={Server} />
      ) : lbError ? (
        <DashboardCardError 
          key="lb"
          title="Load Balancer" 
          icon={Server} 
          error={lbError} 
          colorClass="text-sky-400 bg-sky-500/10 border-sky-500/15" 
          onRetry={handleRetryLB} 
        />
      ) : (
        <DashboardCard 
          key="lb"
          title="Load Balancer"
          icon={Server}
          value={lbData ? String(lbData.summary.load_balancers ?? 0) : '--'}
          label="Total Load Balancers"
          statusText={`${lbData?.summary.healthy_targets ?? 0} Healthy • ${lbData?.summary.unhealthy_targets ?? 0} Unhealthy Targets`}
          colorClass="text-sky-400 bg-sky-500/10 border-sky-500/15"
        />
      )
    ),
    'AWS Lambda': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="lambda" title="AWS Lambda" icon={Zap} onConnect={triggerConnectAWS} />
      ) : lambdaLoading ? (
        <DashboardCardSkeleton key="lambda" title="AWS Lambda" icon={Zap} />
      ) : lambdaError ? (
        <DashboardCardError 
          key="lambda"
          title="AWS Lambda" 
          icon={Zap} 
          error={lambdaError} 
          colorClass="text-orange-400 bg-orange-500/10 border-orange-500/15" 
          onRetry={handleRetryLambda} 
        />
      ) : (
        <DashboardCard 
          key="lambda"
          title="AWS Lambda"
          icon={Zap}
          value={lambdaData ? String(lambdaData.summary.functions ?? 0) : '--'}
          label="Total Functions"
          statusText={`${lambdaData?.summary.active ?? 0} Active • ${lambdaData?.summary.failed ?? 0} Failed`}
          colorClass="text-orange-400 bg-orange-500/10 border-orange-500/15"
        />
      )
    ),
    'Amazon RDS': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="rds" title="Amazon RDS" icon={Database} onConnect={triggerConnectAWS} />
      ) : rdsLoading ? (
        <DashboardCardSkeleton key="rds" title="Amazon RDS" icon={Database} />
      ) : rdsError ? (
        <DashboardCardError 
          key="rds"
          title="Amazon RDS" 
          icon={Database} 
          error={rdsError} 
          colorClass="text-emerald-400 bg-emerald-500/10 border-emerald-500/15" 
          onRetry={handleRetryRDS} 
        />
      ) : (
        <DashboardCard 
          key="rds"
          title="Amazon RDS"
          icon={Database}
          value={rdsData ? String(rdsData.summary.instances ?? 0) : '--'}
          label="Instances"
          statusText={`${rdsData?.summary.clusters ?? 0} Clusters • ${rdsData?.summary.available ?? 0} Available`}
          colorClass="text-emerald-400 bg-emerald-500/10 border-emerald-500/15"
        />
      )
    ),
    'Amazon EBS': () => (
      !awsState.connected ? (
        <DashboardCardDisconnected key="ebs" title="Amazon EBS" icon={HardDrive} onConnect={triggerConnectAWS} />
      ) : ebsLoading ? (
        <DashboardCardSkeleton key="ebs" title="Amazon EBS" icon={HardDrive} />
      ) : ebsError ? (
        <DashboardCardError 
          key="ebs"
          title="Amazon EBS" 
          icon={HardDrive} 
          error={ebsError} 
          colorClass="text-blue-400 bg-blue-500/10 border-blue-500/15" 
          onRetry={handleRetryEBS} 
        />
      ) : (
        <DashboardCard 
          key="ebs"
          title="Amazon EBS"
          icon={HardDrive}
          value={ebsData ? String(ebsData.summary.volumes ?? 0) : '--'}
          label="Volumes"
          statusText={`${ebsData?.summary.snapshots ?? 0} Snapshots • ${ebsData?.summary.encrypted ?? 0} Encrypted`}
          colorClass="text-blue-400 bg-blue-500/10 border-blue-500/15"
        />
      )
    ),
  };

  return (
    <div className="space-y-8">
      
      {/* Page Header block with slot-actions */}
      <PageHeader 
        title="Admin Control Dashboard" 
        description="Unified real-time telemetry monitoring for isolated VM clusters and cost structures."
      >
        <div className="flex items-center gap-3">
          <button
            onClick={() => setIsSettingsOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/40 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 hover:border-slate-700/80 rounded-xl text-xs font-mono font-bold transition-all duration-200"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-amber-500" />
            <span>Dashboard Settings</span>
          </button>

          <button 
            onClick={handleSyncAll}
            disabled={status === 'checking' || isRefreshing}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800/40 hover:bg-slate-800 text-slate-400 hover:text-slate-200 border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${(status === 'checking' || isRefreshing) ? 'animate-spin' : 'animate-spin-slow'}`} />
            <span>Sync Status</span>
          </button>
        </div>
      </PageHeader>

      {/* Backend Offline Banner - Shown when API connection is severed */}
      {status === 'offline' && (
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-5 md:p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 animate-fade-in">
          <div className="flex gap-3.5 items-start">
            <div className="w-10 h-10 rounded-xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center shrink-0">
              <ServerCrash className="w-5 h-5 text-rose-400 animate-pulse" />
            </div>
            <div>
              <h4 className="text-sm font-bold text-white uppercase tracking-wider font-mono">Backend Offline</h4>
              <p className="text-xs text-rose-200/80 mt-1 leading-relaxed max-w-2xl">
                The Cloud Control Center dashboard is currently disconnected from the API gateway on <code className="text-rose-300 bg-rose-950/40 px-1 py-0.5 rounded font-mono">http://127.0.0.1:8000</code>. Please ensure the local FastAPI development server is running and accessible on port 8000.
              </p>
            </div>
          </div>
          <button
            onClick={handleSyncAll}
            className="px-4 py-2 bg-rose-500 hover:bg-rose-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl transition flex items-center gap-1.5 shrink-0 self-end md:self-center shadow-lg shadow-rose-500/10"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            Retry Connection
          </button>
        </div>
      )}

      {/* Executive Service Status Grid & Operations Sidebar Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mt-8 items-start">
        
        {/* Left Column (Dashboard Content ~75% width on Desktop) */}
        <div className="lg:col-span-3">
          
          {/* Executive Service Status Grid */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {cardOrder
              .filter((title) => !hiddenCards.includes(title))
              .map((title) => cardRenderers[title]?.())}
          </div>
        </div>

        {/* Right Column - Permanent Operations Sidebar (~25% width on Desktop) */}
        <div className="lg:col-span-1 lg:sticky lg:top-4 flex flex-col">
          
          {/* Operations Sidebar Alerts Widget */}
          <DashboardWidget
            title="Latest Alerts"
            subtitle="Operations Notification log stream"
            icon={<Bell className="w-4 h-4 text-amber-500" />}
            loading={false}
            error={null}
            className="h-[374px] flex flex-col justify-between"
            lastUpdated={new Date().toLocaleTimeString([], { hour: 'numeric', minute: '2-digit', hour12: true })}
            footerAction={
              <button 
                onClick={() => setIsNotificationsModalOpen(true)}
                className="text-[10px] font-mono font-bold text-amber-500 hover:text-amber-400 flex items-center gap-1 transition rounded px-1 py-0.5"
                title="Open Operations Notifications Portal"
              >
                <span>View All →</span>
              </button>
            }
          >
            {notifications.length === 0 ? (
              <div className="flex flex-col items-center justify-center text-center py-6 h-full select-none">
                <BellOff className="w-8 h-8 text-slate-700 mb-2" />
                <p className="text-[10.5px] text-slate-500 font-mono">No active notifications</p>
              </div>
            ) : (
              <div className="space-y-2.5 overflow-y-auto pr-1 h-[220px] lg:h-0 lg:flex-1 custom-scrollbar select-none">
                {notifications.slice(0, 8).map((notif) => {
                  const relativeTime = getRelativeTime(notif.timestamp);
                  return (
                    <div 
                      key={notif.id} 
                      onClick={() => markAsRead(notif.id)}
                      className={`p-2 rounded-xl border transition-all duration-150 cursor-pointer text-left ${
                        notif.read 
                          ? 'bg-slate-950/20 border-slate-900/40 text-slate-400' 
                          : 'bg-slate-900/40 border-slate-800 text-white hover:border-slate-700/80 border-l-2 border-l-amber-500'
                      } hover:bg-slate-900/70 flex gap-2.5 items-start`}
                      title="Click to mark as read"
                    >
                      <div className="mt-0.5 shrink-0">
                        {notif.type === 'success' && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-500" />}
                        {notif.type === 'warning' && <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />}
                        {notif.type === 'error' && <XCircle className="w-3.5 h-3.5 text-rose-500" />}
                        {notif.type === 'info' && <Info className="w-3.5 h-3.5 text-sky-500" />}
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center justify-between gap-1">
                          <span className="text-[9px] font-mono font-bold text-slate-500 uppercase tracking-wide truncate">
                            {notif.source || 'System'}
                          </span>
                          <span className="text-[8px] font-mono text-slate-500 whitespace-nowrap">
                            {relativeTime}
                          </span>
                        </div>
                        <h5 className="text-[10.5px] font-semibold text-slate-200 mt-0.5 truncate">
                          {notif.title}
                        </h5>
                        <p className="text-[9.5px] text-slate-400 leading-normal line-clamp-2 mt-0.5">
                          {notif.message}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </DashboardWidget>

        </div>

      </div>

      {/* Overview Widget Section */}
      <div className="space-y-6 mt-8">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-bold text-slate-400 uppercase tracking-wider font-mono">Overview Widgets</h3>
        </div>
        
        {/* Unified Overview Widgets Grid - Responsive 4-column layout */}
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            
            {/* Widget 1: CloudWatch Metrics */}
            <DashboardWidget
              title="CloudWatch Metrics"
              subtitle="Real-time performance and telemetries"
              icon={<Activity className="w-4 h-4 text-amber-500" />}
              viewAllLink="/cloudwatch"
              loading={cwLoading}
              error={cwError}
              onRetry={refetchCW}
              lastUpdated={cwRefreshTime}
              footerAction={
                <div className="flex bg-slate-950 border border-slate-900 rounded-lg p-0.5" role="group" aria-label="CloudWatch time range">
                  {(['1h', '6h', '24h'] as const).map((range) => (
                    <button
                      key={range}
                      onClick={() => setCwTimeRange(range)}
                      className={`px-1.5 py-0.5 rounded text-[8px] font-mono font-bold uppercase transition ${
                        cwTimeRange === range
                          ? 'bg-amber-500 text-slate-950 shadow-sm font-extrabold'
                          : 'text-slate-400 hover:text-slate-200'
                      }`}
                      aria-label={`Show ${range} performance data`}
                    >
                      {range}
                    </button>
                  ))}
                </div>
              }
            >
              <div className="space-y-2.5 w-full">
                <div className="grid grid-cols-2 gap-2">
                  <div className="bg-slate-900/40 border border-slate-800/40 rounded-xl p-2 flex flex-col justify-between">
                    <span className="text-[8px] uppercase font-bold text-slate-500 font-mono tracking-wider">CPU Utilization</span>
                    <span className="text-xs font-black text-white font-mono mt-0.5">
                      {cwLoading ? '...' : `${avgCPU.toFixed(1)}%`}
                    </span>
                  </div>
                  <div className="bg-slate-900/40 border border-slate-800/40 rounded-xl p-2 flex flex-col justify-between">
                    <span className="text-[8px] uppercase font-bold text-slate-500 font-mono tracking-wider">Network In</span>
                    <span className="text-xs font-black text-white font-mono mt-0.5">
                      {cwLoading ? '...' : formatWidgetBytes(avgNetIn)}
                    </span>
                  </div>
                  <div className="bg-slate-900/40 border border-slate-800/40 rounded-xl p-2 flex flex-col justify-between">
                    <span className="text-[8px] uppercase font-bold text-slate-500 font-mono tracking-wider">Network Out</span>
                    <span className="text-xs font-black text-white font-mono mt-0.5">
                      {cwLoading ? '...' : formatWidgetBytes(avgNetOut)}
                    </span>
                  </div>
                  <div className="bg-slate-900/40 border border-slate-800/40 rounded-xl p-2 flex flex-col justify-between">
                    <span className="text-[8px] uppercase font-bold text-slate-500 font-mono tracking-wider">Disk Read Ops</span>
                    <span className="text-xs font-black text-white font-mono mt-0.5">
                      {cwLoading ? '...' : (avgDiskRead > 0 ? `${Math.round(avgDiskRead / 4096)} Ops` : '0 Ops')}
                    </span>
                  </div>
                </div>

                {/* Recharts Mini Area Chart */}
                <div className="h-[80px] w-full mt-1.5 relative bg-slate-950/20 border border-slate-900/60 rounded-xl p-0.5">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={miniChartData} margin={{ top: 2, right: 2, left: -32, bottom: 0 }}>
                      <defs>
                        <linearGradient id="colorCwCpu" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.25}/>
                          <stop offset="95%" stopColor="#f59e0b" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <XAxis 
                        dataKey="time" 
                        stroke="#475569" 
                        fontSize={7} 
                        tickLine={false} 
                        axisLine={false} 
                        fontFamily="monospace"
                      />
                      <YAxis 
                        stroke="#475569" 
                        fontSize={7} 
                        tickLine={false} 
                        axisLine={false} 
                        fontFamily="monospace"
                        domain={[0, 'auto']}
                      />
                      <RechartsTooltip 
                        content={({ active, payload }: any) => {
                          if (active && payload && payload.length) {
                            return (
                              <div className="bg-slate-950 border border-slate-800 px-2 py-1 rounded text-[8px] font-mono text-slate-300 shadow-xl">
                                <div className="font-bold text-white mb-0.5 border-b border-slate-800 pb-0.5 uppercase">T: {payload[0].payload.time}</div>
                                <div className="flex justify-between gap-2">
                                  <span>CPU:</span>
                                  <span className="text-amber-400 font-bold">{payload[0].payload.cpu}%</span>
                                </div>
                              </div>
                            );
                          }
                          return null;
                        }}
                      />
                      <Area 
                        type="monotone" 
                        dataKey="cpu" 
                        stroke="#f59e0b" 
                        strokeWidth={1} 
                        fillOpacity={1} 
                        fill="url(#colorCwCpu)" 
                      />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </DashboardWidget>

            {/* Widget 2: AWS Health Summary */}
            <DashboardWidget
              title="AWS Health Summary"
              subtitle="Posture check & service health status"
              icon={<ShieldCheck className="w-4 h-4 text-emerald-500" />}
              viewAllLink="/security"
              loading={securityLoading}
              error={securityError}
              onRetry={refetchSecurity}
              lastUpdated={securityRefreshTime}
              footerAction={<span className="text-slate-600 font-mono text-[9px]">Posture Evaluated</span>}
            >
              <div className="space-y-2.5 py-0.5 flex flex-col justify-center w-full">
                {/* Healthy row */}
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.4)]"></span>
                    <span className="text-[11px] font-mono font-semibold text-slate-300">Healthy Services</span>
                  </div>
                  <StatusBadge status="Healthy" />
                </div>

                {/* Warning row */}
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-amber-500 shadow-[0_0_8px_rgba(245,158,11,0.4)]"></span>
                    <span className="text-[11px] font-mono font-semibold text-slate-300">Warning Services</span>
                  </div>
                  <span className="text-[11px] font-extrabold font-mono text-amber-400 bg-amber-500/10 px-2 py-0.5 border border-amber-500/20 rounded-lg">
                    {securityLoading ? '...' : (securityData?.summary?.warning ?? 0)}
                  </span>
                </div>

                {/* Critical row */}
                <div className="flex items-center justify-between p-2 bg-[#1a0f12]/20 hover:bg-[#1a0f12]/40 rounded-xl border border-rose-950/40 transition">
                  <div className="flex items-center gap-2">
                    <span className="w-1.5 h-1.5 rounded-full bg-rose-500 shadow-[0_0_8px_rgba(239,68,68,0.4)]"></span>
                    <span className="text-[11px] font-mono font-semibold text-slate-300">Critical/Deactivated</span>
                  </div>
                  <span className="text-[11px] font-extrabold font-mono text-rose-400 bg-rose-500/10 px-2 py-0.5 border border-rose-500/20 rounded-lg">
                    {securityLoading ? '...' : (securityData?.summary?.critical ?? 0)}
                  </span>
                </div>

                {/* Overall Health row */}
                <div className="flex items-center justify-between p-2.5 bg-slate-950/40 border border-dashed border-slate-800 rounded-xl mt-1">
                  <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">AWS Global Posture</span>
                  <StatusBadge 
                    status={
                      securityLoading ? 'Unknown' : 
                      (securityData?.summary?.critical ?? 0) > 0 ? 'Critical' : 
                      (securityData?.summary?.warning ?? 0) > 0 ? 'Warning' : 'Healthy'
                    } 
                  />
                </div>
              </div>
            </DashboardWidget>

            {/* Widget 3: VPC Overview */}
            <DashboardWidget
              title="VPC Overview"
              subtitle="Active network infrastructure topology"
              icon={<Network className="w-4 h-4 text-indigo-400" />}
              viewAllLink="/vpc"
              loading={vpcLoading}
              error={vpcError}
              onRetry={refetchVPC}
              lastUpdated={vpcRefreshTime}
              footerAction={<span className="text-slate-600 font-mono text-[9px]">VPC Core Operational</span>}
            >
              <div className="grid grid-cols-2 gap-2.5 w-full">
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">VPCs</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {vpcLoading ? '...' : (vpcData?.summary?.vpcs ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Subnets</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {vpcLoading ? '...' : (vpcData?.summary?.subnets ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Route Tables</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {vpcLoading ? '...' : (vpcData?.summary?.route_tables ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Gateways</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {vpcLoading ? '...' : (vpcData?.summary?.internet_gateways ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">NAT Gateways</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {vpcLoading ? '...' : (vpcData?.summary?.nat_gateways ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Sec Groups</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {vpcLoading ? '...' : (vpcData?.summary?.security_groups ?? 0)}
                  </span>
                </div>
              </div>
            </DashboardWidget>

            {/* Widget 4: Load Balancer Overview */}
            <DashboardWidget
              title="Load Balancers"
              subtitle="Traffic distribution systems"
              icon={<Server className="w-4 h-4 text-indigo-500" />}
              viewAllLink="/load-balancers"
              loading={lbLoading}
              error={lbError}
              onRetry={handleRetryLB}
              lastUpdated={lbRefreshTime}
              footerAction={<span className="text-slate-600 font-mono text-[9px]">Balances Operational</span>}
            >
              <div className="grid grid-cols-2 gap-2.5 w-full">
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">ALB</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {lbLoading ? '...' : (lbData?.summary?.application_load_balancers ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">NLB</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {lbLoading ? '...' : (lbData?.summary?.network_load_balancers ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">GWLB</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {lbLoading ? '...' : (lbData?.summary?.gateway_load_balancers ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Groups</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {lbLoading ? '...' : (lbData?.summary?.target_groups ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Healthy</span>
                  <StatusBadge status={lbLoading ? 'Unknown' : (lbData?.summary?.healthy_targets ?? 0) > 0 ? 'Healthy' : 'Unknown'} />
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Unhealthy</span>
                  <StatusBadge status={lbLoading ? 'Unknown' : (lbData?.summary?.unhealthy_targets ?? 0) > 0 ? 'Critical' : 'Healthy'} />
                </div>
              </div>
            </DashboardWidget>

            {/* Widget 5: AWS Lambda Overview */}
            <DashboardWidget
              title="AWS Lambda Overview"
              subtitle="Serverless compute execution counts"
              icon={<Zap className="w-4 h-4 text-amber-500" />}
              viewAllLink="/lambda"
              loading={lambdaLoading}
              error={lambdaError}
              onRetry={() => fetchLambda(selectedRegion)}
              lastUpdated={lambdaRefreshTime}
              footerAction={<span className="text-slate-600 font-mono text-[9px]">Lambda Operational</span>}
            >
              <div className="grid grid-cols-2 gap-2.5 w-full">
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Functions</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {lambdaLoading ? '...' : (lambdaData?.summary?.functions ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Active</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {lambdaLoading ? '...' : (lambdaData?.summary?.active ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition col-span-2">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Failed Execs</span>
                  <span className={`text-xs font-extrabold font-mono px-1.5 py-0.5 rounded-md border ${
                    (lambdaData?.summary?.failed ?? 0) > 0
                      ? 'text-rose-400 bg-rose-500/10 border-rose-500/20 shadow-[0_0_8px_rgba(239,68,68,0.1)]'
                      : 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20'
                  }`}>
                    {lambdaLoading ? '...' : `${lambdaData?.summary?.failed ?? 0} errors`}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition col-span-2">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Top Runtime</span>
                  <span className="text-xs font-extrabold font-mono text-white truncate max-w-[200px]" title={getTopRuntime()}>
                    {lambdaLoading ? '...' : getTopRuntime()}
                  </span>
                </div>
              </div>
            </DashboardWidget>

            {/* Widget 6: Amazon RDS Overview */}
            <DashboardWidget
              title="Amazon RDS Overview"
              subtitle="Relational database cluster instances"
              icon={<Database className="w-4 h-4 text-indigo-400" />}
              viewAllLink="/rds"
              loading={rdsLoading}
              error={rdsError}
              onRetry={() => fetchRDS(selectedRegion)}
              lastUpdated={rdsRefreshTime}
              footerAction={<span className="text-slate-600 font-mono text-[9px]">RDS Operational</span>}
            >
              <div className="grid grid-cols-2 gap-2.5 w-full">
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Instances</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {rdsLoading ? '...' : (rdsData?.summary?.instances ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Clusters</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {rdsLoading ? '...' : (rdsData?.summary?.clusters ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Available</span>
                  <span className="text-xs font-extrabold font-mono text-emerald-400">
                    {rdsLoading ? '...' : (rdsData?.summary?.available ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Stopped</span>
                  <span className="text-xs font-extrabold font-mono text-slate-400">
                    {rdsLoading ? '...' : (rdsData?.summary?.stopped ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition col-span-2">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Engine Profile</span>
                  <span className="text-xs font-extrabold font-mono text-white truncate max-w-[200px]" title={getPrimaryEngine()}>
                    {rdsLoading ? '...' : getPrimaryEngine()}
                  </span>
                </div>
              </div>
            </DashboardWidget>

            {/* Widget 7: Amazon EBS Overview */}
            <DashboardWidget
              title="Amazon EBS Overview"
              subtitle="Block storage volume allocations"
              icon={<HardDrive className="w-4 h-4 text-blue-500" />}
              viewAllLink="/ebs"
              loading={ebsLoading}
              error={ebsError}
              onRetry={handleRetryEBS}
              lastUpdated={ebsRefreshTime}
              footerAction={<span className="text-slate-600 font-mono text-[9px]">EBS Core Online</span>}
            >
              <div className="grid grid-cols-2 gap-2.5 w-full">
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Volumes</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {ebsLoading ? '...' : (ebsData?.summary?.volumes ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">In Use</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {ebsLoading ? '...' : (ebsData?.summary?.in_use ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Available</span>
                  <span className="text-xs font-extrabold font-mono text-emerald-400">
                    {ebsLoading ? '...' : (ebsData?.summary?.available ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Snapshots</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {ebsLoading ? '...' : (ebsData?.summary?.snapshots ?? 0)}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition col-span-2">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Encryption Ratio</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {ebsLoading ? '...' : `${ebsData?.summary?.encrypted ?? 0} Encrypted / ${ebsData?.summary?.volumes ?? 0} Total`}
                  </span>
                </div>
              </div>
            </DashboardWidget>

            {/* Widget 8: AWS Tag Explorer Summary */}
            <DashboardWidget
              title="AWS Tag Explorer"
              subtitle="Resource grouping and key definitions"
              icon={<Tag className="w-4 h-4 text-teal-400" />}
              viewAllLink="/tags"
              loading={tagLoading}
              error={tagError}
              onRetry={handleRetryTags}
              lastUpdated={tagRefreshTime}
              footerAction={<span className="text-slate-600 font-mono text-[9px]">Metadata Synced</span>}
            >
              <div className="grid grid-cols-2 gap-2.5 w-full">
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Resources</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {tagLoading ? '...' : getTagStats().resources}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Tag Keys</span>
                  <span className="text-xs font-extrabold font-mono text-white">
                    {tagLoading ? '...' : getTagStats().keys}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition col-span-2">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Primary Tag</span>
                  <span className="text-xs font-extrabold font-mono text-white truncate" title={getTagStats().topTag}>
                    {tagLoading ? '...' : getTagStats().topTag}
                  </span>
                </div>
                <div className="flex items-center justify-between p-2 bg-slate-900/20 hover:bg-slate-900/40 rounded-xl border border-slate-800/40 transition col-span-2">
                  <span className="text-[9px] font-mono font-semibold text-slate-400 uppercase tracking-wider">Top Tagged Service</span>
                  <span className="text-xs font-extrabold font-mono text-white truncate" title={getTagStats().topService}>
                    {tagLoading ? '...' : getTagStats().topService}
                  </span>
                </div>
              </div>
            </DashboardWidget>

          </div>
        </div>

        {/* Recent Activity (Moved below the Overview Widgets) */}
        <div className="mt-8">
          <RecentActivity />
        </div>

      {/* Operations Notifications Modal */}
      {isNotificationsModalOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#0f1422] border border-slate-800 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[85vh]">
            <div className="p-6 border-b border-slate-800/80 flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <Bell className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-white uppercase tracking-wider font-mono text-sm">Operations Notifications</h3>
              </div>
              <button 
                onClick={() => setIsNotificationsModalOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Notification controls */}
            {notifications.length > 0 && (
              <div className="px-6 py-2.5 bg-slate-900/20 border-b border-slate-800/60 flex items-center justify-between text-[11px] font-mono text-slate-500 shrink-0">
                <button
                  onClick={markAllRead}
                  className="hover:text-amber-500 flex items-center gap-1.5 transition-colors"
                >
                  <CheckSquare className="w-3.5 h-3.5" />
                  Mark All Read
                </button>

                <button
                  onClick={clearAll}
                  className="hover:text-rose-500 flex items-center gap-1.5 transition-colors"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Clear All
                </button>
              </div>
            )}

            <div className="p-6 space-y-3 overflow-y-auto flex-1 custom-scrollbar">
              {notifications.length === 0 ? (
                <div className="py-16 flex flex-col items-center justify-center text-center space-y-3">
                  <div className="w-12 h-12 rounded-2xl bg-slate-900/50 flex items-center justify-center border border-slate-800">
                    <BellOff className="w-5 h-5 text-slate-500" />
                  </div>
                  <div>
                    <h5 className="text-xs font-semibold text-slate-300 font-mono">No Notifications</h5>
                    <p className="text-[11px] text-slate-500 max-w-xs leading-relaxed font-sans">
                      You're all caught up! Real-time alerts, health heartbeats, and region transitions will be logged here.
                    </p>
                  </div>
                </div>
              ) : (
                notifications.map((notif) => {
                  const relativeTime = getRelativeTime(notif.timestamp);
                  return (
                    <div 
                      key={notif.id} 
                      className={`p-3.5 rounded-xl border transition-all duration-200 border-l-2 flex flex-col gap-1.5 relative group ${
                        notif.read 
                          ? 'bg-slate-950/20 border-slate-900/40 border-l-transparent' 
                          : 'bg-slate-900/40 border-slate-800 border-l-amber-500'
                      } hover:bg-slate-900/70`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-center gap-2">
                          {notif.type === 'success' && <CheckCircle2 className="w-4 h-4 text-emerald-500 shrink-0" />}
                          {notif.type === 'warning' && <AlertTriangle className="w-4 h-4 text-amber-500 shrink-0" />}
                          {notif.type === 'error' && <XCircle className="w-4 h-4 text-rose-500 shrink-0" />}
                          {notif.type === 'info' && <Info className="w-4 h-4 text-sky-500 shrink-0" />}
                          <span className="font-mono text-[10px] uppercase font-bold tracking-wider text-slate-500">
                            {notif.source || 'System'}
                          </span>
                        </div>

                        <div className="flex items-center gap-2">
                          <span className="text-[10px] text-slate-500 font-mono flex items-center gap-1">
                            <Clock className="w-3 h-3" />
                            {relativeTime}
                          </span>

                          {!notif.read && (
                            <button
                              onClick={() => markAsRead(notif.id)}
                              className="text-slate-500 hover:text-amber-500 p-0.5 rounded transition-colors"
                              title="Mark as Read"
                            >
                              <Check className="w-3 h-3" />
                            </button>
                          )}
                        </div>
                      </div>

                      <div className="space-y-1 pl-6">
                        <h4 className={`text-xs font-semibold ${notif.read ? 'text-slate-400' : 'text-slate-100'}`}>
                          {notif.title}
                        </h4>
                        <p className="text-slate-400 text-[11px] leading-relaxed break-words font-sans">
                          {notif.message}
                        </p>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            <div className="p-6 border-t border-slate-800/80 bg-slate-900/10 flex justify-end shrink-0">
              <button
                onClick={() => setIsNotificationsModalOpen(false)}
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold text-xs rounded-xl transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Customization Settings Modal */}
      {isSettingsOpen && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#0f1422] border border-slate-800 rounded-2xl max-w-lg w-full overflow-hidden shadow-2xl animate-in fade-in zoom-in-95 duration-150">
            <div className="p-6 border-b border-slate-800/80 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Settings className="w-5 h-5 text-amber-500" />
                <h3 className="font-bold text-white uppercase tracking-wider font-mono text-sm">Dashboard Settings</h3>
              </div>
              <button 
                onClick={() => setIsSettingsOpen(false)}
                className="p-1 rounded-lg hover:bg-slate-800 text-slate-400 hover:text-white transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6 max-h-[60vh] overflow-y-auto">
              <p className="text-xs text-slate-400 leading-relaxed">
                Customize which service telemetry cards are visible on your Admin Control Dashboard and reorder their grid arrangement. Layouts are saved securely to Local Storage.
              </p>

              <div className="space-y-3">
                {cardOrder.map((title, index) => {
                  const isHidden = hiddenCards.includes(title);
                  return (
                    <div 
                      key={title} 
                      className={`flex items-center justify-between p-3 rounded-xl border font-mono text-xs ${
                        isHidden 
                          ? 'bg-slate-950/40 border-slate-900/60 text-slate-500 font-bold' 
                          : 'bg-slate-900/40 border-slate-800/80 text-white font-bold'
                      }`}
                    >
                      <div className="flex items-center gap-2.5">
                        <button
                          onClick={() => toggleCardVisibility(title)}
                          className={`p-1.5 rounded-lg border transition ${
                            isHidden
                              ? 'bg-slate-950 border-slate-900 hover:text-slate-300'
                              : 'bg-amber-500/10 border-amber-500/20 text-amber-400 hover:bg-amber-500/20'
                          }`}
                          title={isHidden ? 'Show Card' : 'Hide Card'}
                        >
                          {isHidden ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                        </button>
                        <span className={isHidden ? 'line-through' : ''}>{title}</span>
                      </div>

                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => moveCard(index, 'up')}
                          disabled={index === 0}
                          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white disabled:opacity-20 disabled:pointer-events-none transition"
                          title="Move Up"
                        >
                          <ArrowUp className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => moveCard(index, 'down')}
                          disabled={index === cardOrder.length - 1}
                          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-white disabled:opacity-20 disabled:pointer-events-none transition"
                          title="Move Down"
                        >
                          <ArrowDown className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="p-6 border-t border-slate-800/80 bg-slate-900/10 flex items-center justify-between">
              <button
                onClick={resetDashboardSettings}
                className="text-xs font-mono font-bold text-slate-400 hover:text-white transition"
              >
                Reset to Default
              </button>
              <button
                onClick={() => setIsSettingsOpen(false)}
                className="px-4 py-2 bg-amber-500 hover:bg-amber-400 text-slate-950 font-bold text-xs uppercase tracking-wider rounded-xl transition shadow-lg shadow-amber-500/10"
              >
                Apply Changes
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
