import { useState } from 'react';
import { RefreshCw, AlertTriangle, HardDrive, Camera } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { useEBS } from '../hooks/useEBS';
import SummaryCards from '../components/ebs/SummaryCards';
import VolumeTable from '../components/ebs/VolumeTable';
import SnapshotTable from '../components/ebs/SnapshotTable';

export default function EBSMonitoringPage() {
  const { data, loading, error, refetch } = useEBS();
  const [activeTab, setActiveTab] = useState<'volumes' | 'snapshots'>('volumes');

  const summary = data?.summary || {
    volumes: 0,
    available: 0,
    in_use: 0,
    snapshots: 0,
    encrypted: 0
  };

  const volumesList = data?.volumes || [];
  const snapshotsList = data?.snapshots || [];

  return (
    <div className="space-y-6">
      
      {/* Page Header with Manual Sync Trigger */}
      <PageHeader
        title="Amazon EBS"
        description="Monitor virtual Elastic Block Store storage volumes, check allocation attachments to EC2 virtual machine instances, and review user-owned point-in-time snapshots."
      >
        <button
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 border border-slate-800 text-slate-200 hover:text-white rounded-xl text-xs font-mono font-bold transition-all duration-200 shadow-md active:scale-[0.98]"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Page</span>
        </button>
      </PageHeader>

      {/* Warning Alert Banner for partial telemetry blocks */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase text-rose-400 tracking-wider">
              EBS Monitoring Notice
            </h4>
            <p className="text-xs text-slate-300 font-medium">
              {error}
            </p>
          </div>
        </div>
      )}

      {/* Aggregate metrics panels */}
      <SummaryCards summary={summary} loading={loading} />

      {/* Tab Switchers */}
      <div className="flex border-b border-slate-800/80 gap-6 font-mono text-xs font-bold uppercase tracking-wider">
        <button
          onClick={() => setActiveTab('volumes')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-all ${
            activeTab === 'volumes'
              ? 'border-blue-500 text-blue-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <HardDrive className="w-4 h-4" />
          <span>Volumes ({volumesList.length})</span>
        </button>
        <button
          onClick={() => setActiveTab('snapshots')}
          className={`pb-3 flex items-center gap-2 border-b-2 transition-all ${
            activeTab === 'snapshots'
              ? 'border-purple-500 text-purple-400'
              : 'border-transparent text-slate-400 hover:text-slate-200'
          }`}
        >
          <Camera className="w-4 h-4" />
          <span>Snapshots ({snapshotsList.length})</span>
        </button>
      </div>

      {/* Content based on Active Tab */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            {activeTab === 'volumes' ? 'Volumes Inventory' : 'Snapshots Registry'}
          </h3>
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono text-slate-500">
              {loading ? 'Retrieving inventory...' : `Showing ${activeTab === 'volumes' ? volumesList.length : snapshotsList.length} items`}
            </span>
            <ExportMenu 
              data={(activeTab === 'volumes' ? volumesList : snapshotsList) as any[]} 
              filenamePrefix={`AWS_EBS_${activeTab}`} 
            />
          </div>
        </div>

        {activeTab === 'volumes' ? (
          <VolumeTable volumes={volumesList} loading={loading} />
        ) : (
          <SnapshotTable snapshots={snapshotsList} loading={loading} />
        )}
      </div>

    </div>
  );
}
