import { useState } from 'react';
import { useEC2 } from '../hooks/useEC2';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { 
  Cpu, 
  RefreshCw, 
  Search, 
  Filter, 
  Server, 
  Activity, 
  AlertTriangle, 
  Copy, 
  Check, 
  Clock, 
  Network, 
  Globe, 
  Layers 
} from 'lucide-react';

/**
 * EC2Page component
 * Admin-level viewport offering comprehensive monitoring, filtering, and inspection
 * of EC2 virtual machine workloads within the secure sandbox environment.
 */
export default function EC2Page() {
  const { data, loading, error, refetch } = useEC2();
  
  // Filtering and Searching states
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(id);
    setTimeout(() => setCopiedField(null), 1500);
  };

  // Safe accessor fallbacks
  const instances = data?.instances || [];
  const summary = data?.summary || { total: 0, running: 0, stopped: 0 };

  // Apply filters
  const filteredInstances = instances.filter(inst => {
    const matchesSearch = 
      inst.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inst.instance_id.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = 
      statusFilter === 'all' || 
      inst.state.toLowerCase() === statusFilter.toLowerCase();

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="EC2 Instances Monitor" 
        description="Real-time monitoring console mapping virtual compute state, geographical layouts, VPC associations, and active IPs."
      >
        <button 
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Compute</span>
        </button>
      </PageHeader>

      {/* Error / Alert notification banner */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
              AWS Service Warning
            </h4>
            <p className="text-xs text-rose-200/80 leading-relaxed">
              {error}. Please check that your AWS profile has proper IAM permissions (`ec2:DescribeInstances`).
            </p>
          </div>
        </div>
      )}

      {/* Top Summary Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-6">
        
        {/* Total Instances */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl relative overflow-hidden group">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Total compute instances
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.total}
              </span>
              <span className="text-xs text-slate-400 font-medium">allocated</span>
            </div>
          </div>
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-400">
            <Server className="w-5 h-5 text-amber-500" />
          </div>
        </div>

        {/* Running Instances */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl relative overflow-hidden group">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Active running state
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-emerald-400 font-mono leading-none">
                {loading ? '...' : summary.running}
              </span>
              <span className="text-xs text-slate-400 font-medium">online</span>
            </div>
          </div>
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-400">
            <Activity className="w-5 h-5 text-emerald-500 animate-pulse" />
          </div>
        </div>

        {/* Stopped Instances */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl relative overflow-hidden group">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Suspended stopped state
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-rose-400 font-mono leading-none">
                {loading ? '...' : summary.stopped}
              </span>
              <span className="text-xs text-slate-400 font-medium">offline</span>
            </div>
          </div>
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-400">
            <AlertTriangle className="w-5 h-5 text-rose-500" />
          </div>
        </div>

      </div>

      {/* Control Filters Toolbar */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between shadow-lg">
        
        {/* Search Input */}
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search by instance Name or ID..."
            className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-amber-500/40 focus:ring-1 focus:ring-amber-500/20 placeholder-slate-600 transition"
          />
        </div>

        {/* Filter Badges */}
        <div className="flex items-center gap-2 self-start md:self-auto shrink-0 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          <div className="flex items-center gap-1.5 text-slate-500 text-xs font-mono uppercase font-bold mr-2 shrink-0">
            <Filter className="w-3.5 h-3.5" />
            <span>State:</span>
          </div>

          {[
            { id: 'all', label: 'All Instances' },
            { id: 'running', label: 'Running' },
            { id: 'stopped', label: 'Stopped' }
          ].map(opt => (
            <button
              key={opt.id}
              onClick={() => setStatusFilter(opt.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-semibold tracking-wide border transition-all shrink-0 ${
                statusFilter === opt.id
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                  : 'bg-slate-950/60 border-slate-900 text-slate-400 hover:text-slate-200'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <div className="shrink-0">
          <ExportMenu data={filteredInstances} filenamePrefix="AWS_EC2_Instances" />
        </div>

      </div>

      {/* Main Content Area - Table or Skeleton Loader */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
        
        {loading ? (
          <div className="p-8 space-y-4">
            <div className="h-8 bg-slate-900 rounded-xl animate-pulse"></div>
            <div className="h-40 bg-slate-900 rounded-xl animate-pulse"></div>
          </div>
        ) : filteredInstances.length === 0 ? (
          <div className="p-16 text-center space-y-4">
            <div className="w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500 mx-auto">
              <Cpu className="w-6 h-6 text-slate-600" />
            </div>
            <div className="space-y-1.5 max-w-md mx-auto">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                No compute records found
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed">
                {searchTerm || statusFilter !== 'all'
                  ? 'No EC2 instances matched your current search and active state filter parameters.'
                  : 'No EC2 instances found in this AWS account.'}
              </p>
            </div>
            {(searchTerm || statusFilter !== 'all') && (
              <button
                onClick={() => { setSearchTerm(''); setStatusFilter('all'); }}
                className="text-xs font-mono font-bold text-amber-500 hover:text-amber-400 underline decoration-dotted"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                  <th className="px-6 py-4">Instance Identity</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Instance Type</th>
                  <th className="px-6 py-4">Network Addressing</th>
                  <th className="px-6 py-4">Subnets & VPC</th>
                  <th className="px-6 py-4">Launch Context</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredInstances.map((inst) => {
                  const stateLower = inst.state.toLowerCase();
                  
                  // Color codes for different states
                  const stateColor = 
                    stateLower === 'running' 
                      ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400' 
                      : stateLower === 'stopped' 
                        ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                        : stateLower === 'pending' || stateLower === 'stopping'
                          ? 'bg-amber-500/10 border-amber-500/20 text-amber-400'
                          : 'bg-slate-900 border-slate-800 text-slate-400';

                  return (
                    <tr key={inst.instance_id} className="hover:bg-slate-900/20 transition-colors">
                      
                      {/* Name & ID Column */}
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <span className="font-bold text-xs text-white block truncate max-w-[180px]" title={inst.name}>
                            {inst.name}
                          </span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-mono text-slate-500 select-all font-semibold">
                              {inst.instance_id}
                            </span>
                            <button
                              onClick={() => handleCopy(inst.instance_id, `id-${inst.instance_id}`)}
                              className="text-slate-600 hover:text-slate-400 transition"
                              title="Copy Instance ID"
                            >
                              {copiedField === `id-${inst.instance_id}` ? (
                                <Check className="w-3 h-3 text-emerald-500" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </div>
                      </td>

                      {/* Status Column */}
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 border rounded-xl text-[10px] font-mono uppercase font-extrabold ${stateColor}`}>
                          <span className={`w-1.5 h-1.5 rounded-full ${
                            stateLower === 'running' ? 'bg-emerald-400 animate-pulse' : 'bg-current'
                          }`}></span>
                          {inst.state}
                        </span>
                      </td>

                      {/* Type Column */}
                      <td className="px-6 py-4">
                        <div className="space-y-0.5">
                          <code className="text-xs font-mono text-slate-300 font-bold bg-slate-950 px-2 py-0.5 rounded-lg border border-slate-900">
                            {inst.instance_type}
                          </code>
                          <span className="text-[9px] font-mono text-slate-500 block uppercase mt-1">
                            Platform: {inst.platform}
                          </span>
                        </div>
                      </td>

                      {/* IP Addressing Column */}
                      <td className="px-6 py-4 text-xs font-mono text-slate-300">
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-1.5 justify-between max-w-[180px] bg-slate-950/50 px-2 py-1 rounded-lg border border-slate-900/60">
                            <span className="text-slate-500 font-bold text-[9px] uppercase tracking-wide flex items-center gap-1">
                              <Globe className="w-3 h-3 text-sky-400" /> Pub:
                            </span>
                            <span className={`truncate text-[11px] ${inst.public_ip === 'N/A' ? 'text-slate-600 italic font-normal' : 'text-slate-300 font-semibold'}`}>
                              {inst.public_ip}
                            </span>
                            {inst.public_ip !== 'N/A' && (
                              <button
                                onClick={() => handleCopy(inst.public_ip, `pub-${inst.instance_id}`)}
                                className="text-slate-600 hover:text-slate-400 shrink-0"
                                title="Copy Public IP"
                              >
                                {copiedField === `pub-${inst.instance_id}` ? (
                                  <Check className="w-2.5 h-2.5 text-emerald-500" />
                                ) : (
                                  <Copy className="w-2.5 h-2.5" />
                                )}
                              </button>
                            )}
                          </div>

                          <div className="flex items-center gap-1.5 justify-between max-w-[180px] bg-slate-950/50 px-2 py-1 rounded-lg border border-slate-900/60">
                            <span className="text-slate-500 font-bold text-[9px] uppercase tracking-wide flex items-center gap-1">
                              <Network className="w-3 h-3 text-indigo-400" /> Priv:
                            </span>
                            <span className={`truncate text-[11px] ${inst.private_ip === 'N/A' ? 'text-slate-600 italic font-normal' : 'text-slate-300 font-semibold'}`}>
                              {inst.private_ip}
                            </span>
                            {inst.private_ip !== 'N/A' && (
                              <button
                                onClick={() => handleCopy(inst.private_ip, `priv-${inst.instance_id}`)}
                                className="text-slate-600 hover:text-slate-400 shrink-0"
                                title="Copy Private IP"
                              >
                                {copiedField === `priv-${inst.instance_id}` ? (
                                  <Check className="w-2.5 h-2.5 text-emerald-500" />
                                ) : (
                                  <Copy className="w-2.5 h-2.5" />
                                )}
                              </button>
                            )}
                          </div>
                        </div>
                      </td>

                      {/* VPC / Subnet Column */}
                      <td className="px-6 py-4">
                        <div className="space-y-1 text-xs font-mono">
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-slate-500 uppercase font-semibold">VPC:</span>
                            <span className="text-slate-300 font-semibold truncate max-w-[110px]" title={inst.vpc_id}>
                              {inst.vpc_id}
                            </span>
                          </div>
                          <div className="flex items-center gap-1">
                            <span className="text-[10px] text-slate-500 uppercase font-semibold">Subnet:</span>
                            <span className="text-slate-300 font-semibold truncate max-w-[110px]" title={inst.subnet_id}>
                              {inst.subnet_id}
                            </span>
                          </div>
                        </div>
                      </td>

                      {/* Launch Time Column */}
                      <td className="px-6 py-4">
                        <div className="space-y-1.5">
                          <div className="flex items-center gap-1.5 text-xs text-slate-300">
                            <Clock className="w-3.5 h-3.5 text-slate-500" />
                            <span className="text-[10px] font-mono font-bold tracking-tight">
                              {inst.launch_time !== 'N/A' 
                                ? new Date(inst.launch_time).toLocaleDateString('en-US', {
                                    month: 'short',
                                    day: 'numeric',
                                    year: 'numeric'
                                  })
                                : 'N/A'}
                            </span>
                          </div>
                          <span className="inline-flex items-center gap-1 text-[10px] font-mono font-bold text-slate-500 uppercase">
                            <Layers className="w-3 h-3" />
                            {inst.availability_zone}
                          </span>
                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
}
