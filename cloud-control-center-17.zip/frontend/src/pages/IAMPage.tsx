import { useState } from 'react';
import { useIAM } from '../hooks/useIAM';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { 
  Shield, 
  Users, 
  UserCheck, 
  Briefcase, 
  FileText, 
  RefreshCw, 
  Search, 
  Copy, 
  Check, 
  Clock, 
  AlertTriangle, 
  Key, 
  Lock, 
  Unlock 
} from 'lucide-react';

type TabId = 'users' | 'groups' | 'roles' | 'policies';

/**
 * IAMPage Component
 * Real-time monitoring and security compliance auditing dashboard mapping active AWS
 * IAM identities, access controls, multi-factor setups, and API key metrics.
 */
export default function IAMPage() {
  const { data, loading, error, refetch } = useIAM();
  const [activeTab, setActiveTab] = useState<TabId>('users');
  const [searchTerm, setSearchTerm] = useState('');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  // Safe accessor fallbacks
  const users = data?.users || [];
  const groups = data?.groups || [];
  const roles = data?.roles || [];
  const policies = data?.policies || [];
  const summary = data?.summary || { users: 0, groups: 0, roles: 0, policies: 0 };
  const partialErrors = data?.errors || {};

  // Copy handler
  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(id);
    setTimeout(() => setCopiedField(null), 1500);
  };

  // Filter content based on active tab and search term
  const getFilteredData = () => {
    const term = searchTerm.toLowerCase();
    switch (activeTab) {
      case 'users':
        return users.filter(u => 
          u.user_name.toLowerCase().includes(term) || 
          u.arn.toLowerCase().includes(term)
        );
      case 'groups':
        return groups.filter(g => 
          g.group_name.toLowerCase().includes(term) || 
          g.arn.toLowerCase().includes(term)
        );
      case 'roles':
        return roles.filter(r => 
          r.role_name.toLowerCase().includes(term) || 
          r.arn.toLowerCase().includes(term)
        );
      case 'policies':
        return policies.filter(p => 
          p.policy_name.toLowerCase().includes(term) || 
          p.arn.toLowerCase().includes(term)
        );
      default:
        return [];
    }
  };

  const filteredItems = getFilteredData();

  // Determine if active tab has a partial permission error
  const activeTabError = partialErrors[activeTab];

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="IAM Security Monitor" 
        description="Audit directory credentials, identify missing MFA configurations, inspect active API keys, and track role structures."
      >
        <button 
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh IAM</span>
        </button>
      </PageHeader>

      {/* Global connection error warning banner */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
              AWS Service Credentials Warning
            </h4>
            <p className="text-xs text-rose-200/80 leading-relaxed">
              {error}. Please check that your AWS profile has proper IAM permissions (`iam:ListUsers`, `iam:ListRoles`, etc.).
            </p>
          </div>
        </div>
      )}

      {/* KPI Stats Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        
        {/* Total Users */}
        <div 
          onClick={() => { setActiveTab('users'); setSearchTerm(''); }}
          className={`bg-[#0f1422] border rounded-2xl p-6 flex items-center justify-between shadow-xl cursor-pointer transition-all ${
            activeTab === 'users' ? 'border-amber-500/50 bg-amber-500/[0.02]' : 'border-slate-800/80 hover:border-slate-700/80'
          }`}
        >
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Total IAM Users
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.users}
              </span>
              <span className="text-xs text-slate-400 font-medium">identities</span>
            </div>
          </div>
          <div className={`p-3 rounded-xl border transition-colors ${
            activeTab === 'users' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}>
            <Users className="w-5 h-5" />
          </div>
        </div>

        {/* Total Groups */}
        <div 
          onClick={() => { setActiveTab('groups'); setSearchTerm(''); }}
          className={`bg-[#0f1422] border rounded-2xl p-6 flex items-center justify-between shadow-xl cursor-pointer transition-all ${
            activeTab === 'groups' ? 'border-amber-500/50 bg-amber-500/[0.02]' : 'border-slate-800/80 hover:border-slate-700/80'
          }`}
        >
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Total User Groups
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.groups}
              </span>
              <span className="text-xs text-slate-400 font-medium">structures</span>
            </div>
          </div>
          <div className={`p-3 rounded-xl border transition-colors ${
            activeTab === 'groups' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}>
            <UserCheck className="w-5 h-5" />
          </div>
        </div>

        {/* Total Roles */}
        <div 
          onClick={() => { setActiveTab('roles'); setSearchTerm(''); }}
          className={`bg-[#0f1422] border rounded-2xl p-6 flex items-center justify-between shadow-xl cursor-pointer transition-all ${
            activeTab === 'roles' ? 'border-amber-500/50 bg-amber-500/[0.02]' : 'border-slate-800/80 hover:border-slate-700/80'
          }`}
        >
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Total IAM Roles
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.roles}
              </span>
              <span className="text-xs text-slate-400 font-medium">profiles</span>
            </div>
          </div>
          <div className={`p-3 rounded-xl border transition-colors ${
            activeTab === 'roles' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}>
            <Briefcase className="w-5 h-5" />
          </div>
        </div>

        {/* Managed Policies */}
        <div 
          onClick={() => { setActiveTab('policies'); setSearchTerm(''); }}
          className={`bg-[#0f1422] border rounded-2xl p-6 flex items-center justify-between shadow-xl cursor-pointer transition-all ${
            activeTab === 'policies' ? 'border-amber-500/50 bg-amber-500/[0.02]' : 'border-slate-800/80 hover:border-slate-700/80'
          }`}
        >
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Managed Policies
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.policies}
              </span>
              <span className="text-xs text-slate-400 font-medium">custom rules</span>
            </div>
          </div>
          <div className={`p-3 rounded-xl border transition-colors ${
            activeTab === 'policies' ? 'bg-amber-500/10 border-amber-500/20 text-amber-400' : 'bg-slate-900 border-slate-800 text-slate-400'
          }`}>
            <FileText className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Tab Controls and Local Search Bar */}
      <div className="flex flex-col lg:flex-row gap-4 justify-between items-center bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4 shadow-lg">
        
        {/* Navigation Tabs */}
        <div className="flex items-center gap-1 bg-slate-950/80 border border-slate-900 p-1 rounded-xl w-full lg:w-auto overflow-x-auto">
          {[
            { id: 'users', label: 'Users', count: summary.users },
            { id: 'groups', label: 'Groups', count: summary.groups },
            { id: 'roles', label: 'Roles', count: summary.roles },
            { id: 'policies', label: 'Policies', count: summary.policies }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => { setActiveTab(tab.id as TabId); setSearchTerm(''); }}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-xs font-mono font-bold tracking-wide transition-all shrink-0 ${
                activeTab === tab.id
                  ? 'bg-amber-500/15 text-amber-400 border border-amber-500/10'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900 border border-transparent'
              }`}
            >
              <span>{tab.label}</span>
              <span className={`px-1.5 py-0.5 rounded-md text-[9px] font-extrabold ${
                activeTab === tab.id ? 'bg-amber-500/25 text-amber-300' : 'bg-slate-900 text-slate-500'
              }`}>
                {loading ? '..' : tab.count}
              </span>
            </button>
          ))}
        </div>

        {/* Dynamic Search Box & Export Menu */}
        <div className="flex items-center gap-3 w-full lg:w-auto shrink-0 justify-between lg:justify-end">
          <div className="relative w-full lg:max-w-xs shrink-0">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
            <input
              type="text"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              placeholder={`Filter ${activeTab}...`}
              className="w-full pl-9 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-amber-500/40 focus:ring-1 focus:ring-amber-500/20 placeholder-slate-600 transition"
            />
          </div>
          <ExportMenu data={filteredItems as any[]} filenamePrefix={`AWS_IAM_${activeTab}`} />
        </div>

      </div>

      {/* Main Table / Audit Board */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
        
        {/* Localized permission denied error for this active resource tab */}
        {activeTabError && (
          <div className="p-4 bg-amber-500/5 border-b border-amber-500/10 text-amber-400 flex items-start gap-3">
            <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h5 className="text-[11px] font-bold font-mono uppercase tracking-wider text-amber-200">
                Auditing Limit Reached ({activeTab})
              </h5>
              <p className="text-xs text-amber-300/80 leading-normal">
                {activeTabError}. The system is displaying cached or partial indicators.
              </p>
            </div>
          </div>
        )}

        {loading ? (
          <div className="p-8 space-y-4">
            <div className="h-8 bg-slate-900 rounded-xl animate-pulse"></div>
            <div className="h-40 bg-slate-900 rounded-xl animate-pulse"></div>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="p-16 text-center space-y-4">
            <div className="w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500 mx-auto">
              <Shield className="w-6 h-6 text-slate-600" />
            </div>
            <div className="space-y-1.5 max-w-md mx-auto">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                No IAM resources found
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed font-sans">
                {searchTerm
                  ? `No audited ${activeTab} matched your filter parameters.`
                  : `Your AWS account has no active ${activeTab} registered.`}
              </p>
            </div>
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="text-xs font-mono font-bold text-amber-500 hover:text-amber-400 underline decoration-dotted"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            
            {/* 1. USERS TAB TABLE */}
            {activeTab === 'users' && (
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                    <th className="px-6 py-4">User Identity</th>
                    <th className="px-6 py-4">MFA Status</th>
                    <th className="px-6 py-4">Console Access</th>
                    <th className="px-6 py-4">API Access Keys</th>
                    <th className="px-6 py-4">Created</th>
                    <th className="px-6 py-4">ARN (Resource Identity)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                  {filteredItems.map((item: any) => (
                    <tr key={item.user_id} className="hover:bg-slate-900/20 transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-bold text-white block truncate max-w-[180px]" title={item.user_name}>
                          {item.user_name}
                        </span>
                        <span className="text-[10px] font-mono text-slate-500 block font-semibold mt-0.5 select-all">
                          ID: {item.user_id}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        {item.mfa_enabled ? (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 border border-emerald-500/20 bg-emerald-500/10 text-emerald-400 rounded-xl text-[10px] font-mono uppercase font-bold">
                            <Lock className="w-3 h-3" /> MFA Enabled
                          </span>
                        ) : (
                          <span className="inline-flex items-center gap-1 px-2.5 py-1 border border-rose-500/20 bg-rose-500/10 text-rose-400 rounded-xl text-[10px] font-mono uppercase font-bold">
                            <Unlock className="w-3 h-3 animate-pulse" /> MFA Disabled
                          </span>
                        )}
                      </td>
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-lg text-[10px] font-mono font-bold ${
                          item.password_enabled === 'Enabled'
                            ? 'bg-slate-900 text-slate-300 border border-slate-800'
                            : 'bg-slate-950 text-slate-600'
                        }`}>
                          {item.password_enabled}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-mono">
                        <div className="flex items-center gap-2">
                          <Key className={`w-3.5 h-3.5 ${item.access_key_count > 0 ? 'text-amber-500' : 'text-slate-600'}`} />
                          <span className="font-bold text-white">{item.access_key_count}</span>
                          <span className="text-[9px] text-slate-500 font-semibold uppercase">allocated</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          <span className="text-[10px] font-mono font-semibold">
                            {item.create_date !== 'N/A'
                              ? new Date(item.create_date).toLocaleDateString('en-US', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric'
                                })
                              : 'N/A'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 max-w-[200px]">
                          <span className="font-mono text-[10px] text-slate-500 truncate select-all font-semibold" title={item.arn}>
                            {item.arn}
                          </span>
                          <button
                            onClick={() => handleCopy(item.arn, `user-${item.user_name}`)}
                            className="text-slate-600 hover:text-slate-400 shrink-0 transition"
                            title="Copy ARN"
                          >
                            {copiedField === `user-${item.user_name}` ? (
                              <Check className="w-3 h-3 text-emerald-500" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {/* 2. GROUPS TAB TABLE */}
            {activeTab === 'groups' && (
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                    <th className="px-6 py-4">Group Name</th>
                    <th className="px-6 py-4">Active Members</th>
                    <th className="px-6 py-4">ARN (Resource Identity)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                  {filteredItems.map((item: any) => (
                    <tr key={item.group_name} className="hover:bg-slate-900/20 transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-bold text-white block truncate max-w-[200px]" title={item.group_name}>
                          {item.group_name}
                        </span>
                      </td>
                      <td className="px-6 py-4 font-mono">
                        <div className="flex items-center gap-2">
                          <Users className="w-3.5 h-3.5 text-slate-500" />
                          <span className="font-bold text-white">{item.user_count}</span>
                          <span className="text-[10px] text-slate-500 font-bold uppercase">Users linked</span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 max-w-[300px]">
                          <span className="font-mono text-[10px] text-slate-500 truncate select-all font-semibold" title={item.arn}>
                            {item.arn}
                          </span>
                          <button
                            onClick={() => handleCopy(item.arn, `group-${item.group_name}`)}
                            className="text-slate-600 hover:text-slate-400 shrink-0 transition"
                            title="Copy ARN"
                          >
                            {copiedField === `group-${item.group_name}` ? (
                              <Check className="w-3 h-3 text-emerald-500" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {/* 3. ROLES TAB TABLE */}
            {activeTab === 'roles' && (
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                    <th className="px-6 py-4">Role Name</th>
                    <th className="px-6 py-4">Created</th>
                    <th className="px-6 py-4">ARN (Resource Identity)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                  {filteredItems.map((item: any) => (
                    <tr key={item.role_name} className="hover:bg-slate-900/20 transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-bold text-white block truncate max-w-[220px]" title={item.role_name}>
                          {item.role_name}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          <span className="text-[10px] font-mono font-semibold">
                            {item.create_date !== 'N/A'
                              ? new Date(item.create_date).toLocaleDateString('en-US', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric'
                                })
                              : 'N/A'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 max-w-[320px]">
                          <span className="font-mono text-[10px] text-slate-500 truncate select-all font-semibold" title={item.arn}>
                            {item.arn}
                          </span>
                          <button
                            onClick={() => handleCopy(item.arn, `role-${item.role_name}`)}
                            className="text-slate-600 hover:text-slate-400 shrink-0 transition"
                            title="Copy ARN"
                          >
                            {copiedField === `role-${item.role_name}` ? (
                              <Check className="w-3 h-3 text-emerald-500" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

            {/* 4. POLICIES TAB TABLE */}
            {activeTab === 'policies' && (
              <table className="w-full border-collapse text-left">
                <thead>
                  <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                    <th className="px-6 py-4">Policy Name</th>
                    <th className="px-6 py-4">Created Date</th>
                    <th className="px-6 py-4">ARN (Resource Identity)</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800/60 text-xs text-slate-300">
                  {filteredItems.map((item: any) => (
                    <tr key={item.policy_name} className="hover:bg-slate-900/20 transition-colors">
                      <td className="px-6 py-4">
                        <span className="font-bold text-white block truncate max-w-[240px]" title={item.policy_name}>
                          {item.policy_name}
                        </span>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          <span className="text-[10px] font-mono font-semibold">
                            {item.create_date !== 'N/A'
                              ? new Date(item.create_date).toLocaleDateString('en-US', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric'
                                })
                              : 'N/A'}
                          </span>
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 max-w-[340px]">
                          <span className="font-mono text-[10px] text-slate-500 truncate select-all font-semibold" title={item.arn}>
                            {item.arn}
                          </span>
                          <button
                            onClick={() => handleCopy(item.arn, `policy-${item.policy_name}`)}
                            className="text-slate-600 hover:text-slate-400 shrink-0 transition"
                            title="Copy ARN"
                          >
                            {copiedField === `policy-${item.policy_name}` ? (
                              <Check className="w-3 h-3 text-emerald-500" />
                            ) : (
                              <Copy className="w-3 h-3" />
                            )}
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}

          </div>
        )}

      </div>

    </div>
  );
}
