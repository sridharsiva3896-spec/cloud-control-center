import { RefreshCw, AlertTriangle } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { useLambda } from '../hooks/useLambda';
import SummaryCards from '../components/lambda/SummaryCards';
import FunctionTable from '../components/lambda/FunctionTable';

/**
 * LambdaMonitoringPage Component
 * Provides executive-level monitoring, resource metrics, runtime environments,
 * and concurrency metrics for AWS Lambda serverless execution units.
 */
export default function LambdaMonitoringPage() {
  const { data, loading, error, refetch } = useLambda();

  const summary = data?.summary || {
    functions: 0,
    active: 0,
    failed: 0
  };

  const functionsList = data?.functions || [];

  return (
    <div className="space-y-6">
      
      {/* Page Header with Side Action Button */}
      <PageHeader
        title="AWS Lambda"
        description="Monitor serverless function configurations, active execution units, runtime stats, and reserved concurrency rules."
      >
        <button
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 border border-slate-800 text-slate-200 hover:text-white rounded-xl text-xs font-mono font-bold transition-all duration-200 shadow-md active:scale-[0.98]"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Page</span>
        </button>
      </PageHeader>

      {/* Handshake warning or partial restriction alert */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase text-rose-400 tracking-wider">
              Lambda Monitoring Notice
            </h4>
            <p className="text-xs text-slate-300 font-medium">
              {error}
            </p>
          </div>
        </div>
      )}

      {/* Summary Stats Panels */}
      <SummaryCards summary={summary} loading={loading} />

      {/* Function Catalog Table View */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            Functions Catalog
          </h3>
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono text-slate-500">
              {loading ? 'Retrieving inventory...' : `Showing ${functionsList.length} function definitions`}
            </span>
            <ExportMenu data={functionsList} filenamePrefix="AWS_Lambda_Functions" />
          </div>
        </div>
        
        <FunctionTable functions={functionsList} loading={loading} />
      </div>

    </div>
  );
}
