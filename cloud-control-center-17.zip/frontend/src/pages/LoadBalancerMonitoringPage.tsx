import { useState, useMemo } from 'react';
import PageHeader from '../components/common/PageHeader';
import { useLoadBalancers } from '../hooks/useLoadBalancers';
import ExportMenu from '../components/common/ExportMenu';
import SummaryCards from '../components/loadbalancer/SummaryCards';
import LoadBalancerTable from '../components/loadbalancer/LoadBalancerTable';
import TargetGroupTable from '../components/loadbalancer/TargetGroupTable';
import ListenerTable from '../components/loadbalancer/ListenerTable';
import TargetHealthTable from '../components/loadbalancer/TargetHealthTable';
import {
  Search,
  X,
  AlertTriangle,
  RefreshCw,
  SlidersHorizontal,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';

type TabType = 'load_balancers' | 'target_groups' | 'listeners' | 'target_health';

/**
 * LoadBalancerMonitoringPage Component
 * Provides complete AWS Elastic Load Balancing (ELB v2) telemetry, metrics, client-side searching,
 * filter options, and tables for Load Balancers, Target Groups, Listeners, and Target Health.
 */
export default function LoadBalancerMonitoringPage() {
  const { data, loading, error, refetch } = useLoadBalancers();
  const [activeTab, setActiveTab] = useState<TabType>('load_balancers');

  // Search & Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedScheme, setSelectedScheme] = useState('');
  const [selectedHealthStatus, setSelectedHealthStatus] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const summary = data?.summary || {
    load_balancers: 0,
    application_load_balancers: 0,
    network_load_balancers: 0,
    gateway_load_balancers: 0,
    target_groups: 0,
    healthy_targets: 0,
    unhealthy_targets: 0
  };

  // 1. Filter logic for Load Balancers
  const filteredLoadBalancers = useMemo(() => {
    if (!data?.load_balancers) return [];
    return data.load_balancers.filter((lb) => {
      // Search matches Load Balancer Name or DNS Name
      const matchesSearch =
        searchQuery === '' ||
        lb.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lb.dns_name.toLowerCase().includes(searchQuery.toLowerCase());

      // Type filter
      const matchesType = selectedType === '' || lb.type === selectedType;

      // State filter
      const matchesState = selectedState === '' || lb.state === selectedState;

      // Scheme filter
      const matchesScheme = selectedScheme === '' || lb.scheme === selectedScheme;

      return matchesSearch && matchesType && matchesState && matchesScheme;
    });
  }, [data?.load_balancers, searchQuery, selectedType, selectedState, selectedScheme]);

  // 2. Filter logic for Target Groups
  const filteredTargetGroups = useMemo(() => {
    if (!data?.target_groups) return [];
    return data.target_groups.filter((tg) => {
      // Search matches Target Group Name
      const matchesSearch =
        searchQuery === '' ||
        tg.name.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesSearch;
    });
  }, [data?.target_groups, searchQuery]);

  // 3. Filter logic for Listeners
  const filteredListeners = useMemo(() => {
    if (!data?.listeners) return [];
    return data.listeners.filter((lis) => {
      // Search matches Load Balancer ARN or Protocol or Port
      const matchesSearch =
        searchQuery === '' ||
        lis.load_balancer_arn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        lis.protocol.toLowerCase().includes(searchQuery.toLowerCase()) ||
        String(lis.port).includes(searchQuery);

      return matchesSearch;
    });
  }, [data?.listeners, searchQuery]);

  // 4. Filter logic for Target Health
  const filteredTargetHealth = useMemo(() => {
    if (!data?.target_health) return [];
    return data.target_health.filter((th) => {
      // Search matches Target ID or Target Group ARN
      const matchesSearch =
        searchQuery === '' ||
        th.target_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        th.target_group_arn.toLowerCase().includes(searchQuery.toLowerCase());

      // Health status filter
      const matchesHealth =
        selectedHealthStatus === '' || th.health_state === selectedHealthStatus;

      return matchesSearch && matchesHealth;
    });
  }, [data?.target_health, searchQuery, selectedHealthStatus]);

  // Reset all filters
  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedType('');
    setSelectedState('');
    setSelectedScheme('');
    setSelectedHealthStatus('');
  };

  const getActiveTabExportData = () => {
    switch (activeTab) {
      case 'load_balancers': return filteredLoadBalancers;
      case 'target_groups': return filteredTargetGroups;
      case 'listeners': return filteredListeners;
      case 'target_health': return filteredTargetHealth;
      default: return [];
    }
  };

  const hasActiveFilters =
    searchQuery !== '' ||
    selectedType !== '' ||
    selectedState !== '' ||
    selectedScheme !== '' ||
    selectedHealthStatus !== '';

  return (
    <div id="load-balancer-monitoring-page" className="space-y-6">
      <PageHeader
        title="Load Balancer Monitoring"
        description="Monitor AWS Application, Network, and Gateway Load Balancers, inspect listeners, target groups, and track real-time resource endpoint health."
      >
        <button
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Telemetry</span>
        </button>
      </PageHeader>

      {/* Access Denied / Connection Warning Alert Banner */}
      {error && (
        <div className="bg-amber-500/10 border border-amber-500/20 text-amber-200/90 p-4 rounded-2xl flex items-start gap-3.5 shadow-sm">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono tracking-wide uppercase text-amber-400">
              AWS Connection Warning
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {error} Please verify that your programmatic AWS credential profile contains necessary read permissions for ELB load balancers (`elasticloadbalancing:DescribeLoadBalancers`, `elasticloadbalancing:DescribeTargetGroups`, `elasticloadbalancing:DescribeListeners`, `elasticloadbalancing:DescribeTargetHealth`).
            </p>
          </div>
        </div>
      )}

      {/* Summary Cards */}
      <SummaryCards summary={summary} loading={loading && !data} />

      {/* Quick Search & Filter Drawer Toggle */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex w-full md:w-auto items-center gap-2">
          {/* Quick Search */}
          <div className="relative flex-1 md:w-80">
            <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search Name, DNS, Target Group, Target ID..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800/85 focus:border-sky-500/40 rounded-xl pl-9 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-500 focus:outline-none"
            />
          </div>

          {/* Toggle Filter Panel & Export Menu */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
              showFilters
                ? 'bg-sky-500/15 text-sky-400 border-sky-500/30'
                : 'bg-slate-900/60 text-slate-400 border-slate-800/80 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>
          
          <ExportMenu data={getActiveTabExportData() as any[]} filenamePrefix={`AWS_LoadBalancer_${activeTab}`} />
        </div>

        {/* Read-only status indicator */}
        <div className="flex items-center gap-3 text-[10px] font-mono text-slate-500">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Read-only active
          </span>
        </div>
      </div>

      {/* Filters Panel Drawer */}
      {showFilters && (
        <div className="p-5 bg-[#0f1422] border border-slate-800/80 rounded-2xl grid grid-cols-1 md:grid-cols-4 gap-4 animate-in slide-in-from-top-4 duration-150">
          {/* Filter Type */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
              Balancer Type
            </label>
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500/40 cursor-pointer"
            >
              <option value="">All Types</option>
              <option value="application">Application (ALB)</option>
              <option value="network">Network (NLB)</option>
              <option value="gateway">Gateway (GLB)</option>
            </select>
          </div>

          {/* Filter State */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
              State / Status
            </label>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500/40 cursor-pointer"
            >
              <option value="">All States</option>
              <option value="active">Active</option>
              <option value="provisioning">Provisioning</option>
              <option value="failed">Failed</option>
            </select>
          </div>

          {/* Filter Scheme */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
              Scheme
            </label>
            <select
              value={selectedScheme}
              onChange={(e) => setSelectedScheme(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500/40 cursor-pointer"
            >
              <option value="">All Schemes</option>
              <option value="internet-facing">Internet-facing</option>
              <option value="internal">Internal</option>
            </select>
          </div>

          {/* Filter Target Health */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
              Target Health Status
            </label>
            <select
              value={selectedHealthStatus}
              onChange={(e) => setSelectedHealthStatus(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-sky-500/40 cursor-pointer"
            >
              <option value="">All Health Statuses</option>
              <option value="healthy">Healthy</option>
              <option value="unhealthy">Unhealthy</option>
              <option value="unused">Unused</option>
              <option value="draining">Draining</option>
              <option value="initial">Initial</option>
            </select>
          </div>

          {hasActiveFilters && (
            <div className="col-span-1 md:col-span-4 flex justify-end pt-2">
              <button
                onClick={handleClearFilters}
                className="flex items-center gap-1 px-3 py-1 bg-slate-800/40 hover:bg-slate-800 text-slate-400 hover:text-slate-300 border border-slate-800 hover:border-slate-700/80 rounded-xl text-xs font-mono font-bold uppercase"
              >
                <X className="w-3.5 h-3.5" />
                Clear Active Filters
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tabs navigation */}
      <div className="flex border-b border-slate-800 overflow-x-auto gap-2">
        {(['load_balancers', 'target_groups', 'listeners', 'target_health'] as TabType[]).map((tab) => {
          let label = tab.toUpperCase().replace('_', ' ');
          if (tab === 'load_balancers') label = 'LOAD BALANCERS';
          if (tab === 'target_groups') label = 'TARGET GROUPS';
          if (tab === 'listeners') label = 'LISTENERS';
          if (tab === 'target_health') label = 'TARGET HEALTH';

          const isActive = activeTab === tab;

          return (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={`pb-3 px-4 font-mono text-xs font-bold uppercase border-b-2 tracking-wider transition-all whitespace-nowrap ${
                isActive
                  ? 'border-sky-500 text-sky-400'
                  : 'border-transparent text-slate-500 hover:text-slate-300'
              }`}
            >
              {label}
            </button>
          );
        })}
      </div>

      {/* Render Selected Tab content */}
      <div className="space-y-4">
        {activeTab === 'load_balancers' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-sky-400" />
              <span>Elastic Load Balancers (showing {filteredLoadBalancers.length} of {summary.load_balancers})</span>
            </div>
            <LoadBalancerTable loadBalancers={filteredLoadBalancers} loading={loading} />
          </div>
        )}

        {activeTab === 'target_groups' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-amber-500" />
              <span>Target Groups (showing {filteredTargetGroups.length} of {summary.target_groups})</span>
            </div>
            <TargetGroupTable targetGroups={filteredTargetGroups} loading={loading} />
          </div>
        )}

        {activeTab === 'listeners' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-indigo-400" />
              <span>Listener Profiles (showing {filteredListeners.length} of {data?.listeners?.length || 0})</span>
            </div>
            <ListenerTable listeners={filteredListeners} loading={loading} />
          </div>
        )}

        {activeTab === 'target_health' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-teal-400" />
              <span>Target Health Index (showing {filteredTargetHealth.length} of {data?.target_health?.length || 0})</span>
            </div>
            <TargetHealthTable targetHealths={filteredTargetHealth} loading={loading} />
          </div>
        )}
      </div>

      {/* Compliance Warning Footer */}
      <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/50 flex gap-3 items-start">
        <ShieldAlert className="w-4.5 h-4.5 text-slate-500 shrink-0 mt-0.5" />
        <div className="text-[11px] text-slate-500 font-mono leading-relaxed">
          <span className="text-slate-400 font-bold uppercase tracking-wider block mb-1">
            AWS Load Balancer Compliance Guard
          </span>
          This Load Balancer monitoring module operates strictly under secure read-only conditions. Creation, modification, scaling, or termination of load balancers, listener routes, health thresholds, target groups, or registered targets is prohibited.
        </div>
      </div>
    </div>
  );
}
