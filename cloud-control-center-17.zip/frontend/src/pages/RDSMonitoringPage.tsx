import { RefreshCw, AlertTriangle } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { useRDS } from '../hooks/useRDS';
import SummaryCards from '../components/rds/SummaryCards';
import RDSInstanceTable from '../components/rds/RDSInstanceTable';
import ClusterTable from '../components/rds/ClusterTable';

/**
 * RDSMonitoringPage Component
 * Provides executive-level monitoring, engine environments, storage sizes, and high availability
 * status configurations for AWS RDS serverless and traditional database instances and clusters.
 */
export default function RDSMonitoringPage() {
  const { data, loading, error, refetch } = useRDS();

  const summary = data?.summary || {
    instances: 0,
    clusters: 0,
    available: 0,
    stopped: 0
  };

  const instancesList = data?.instances || [];
  const clustersList = data?.clusters || [];

  return (
    <div className="space-y-6">
      
      {/* Page Header with Side Action Button */}
      <PageHeader
        title="Amazon RDS"
        description="Monitor relational database engine types, active running hosts, multi-AZ high availability deployments, and connection endpoints."
      >
        <button
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 border border-slate-800 text-slate-200 hover:text-white rounded-xl text-xs font-mono font-bold transition-all duration-200 shadow-md active:scale-[0.98]"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Page</span>
        </button>
      </PageHeader>

      {/* Handshake warning or partial restriction alert */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-4 flex items-start gap-3">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase text-rose-400 tracking-wider">
              RDS Monitoring Notice
            </h4>
            <p className="text-xs text-slate-300 font-medium">
              {error}
            </p>
          </div>
        </div>
      )}

      {/* Summary Stats Panels */}
      <SummaryCards summary={summary} loading={loading} />

      {/* Clusters Table (Only visible if clusters are detected) */}
      <ClusterTable clusters={clustersList} loading={loading} />

      {/* Database Instance Catalog Table View */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400">
            Instances Catalog
          </h3>
          <div className="flex items-center gap-3">
            <span className="text-[10px] font-mono text-slate-500">
              {loading ? 'Retrieving inventory...' : `Showing ${instancesList.length} database instance definitions`}
            </span>
            <ExportMenu data={instancesList} filenamePrefix="AWS_RDS_Instances" />
          </div>
        </div>
        
        <RDSInstanceTable instances={instancesList} loading={loading} />
      </div>

    </div>
  );
}
