import { useState } from 'react';
import { useS3 } from '../hooks/useS3';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { 
  Database, 
  RefreshCw, 
  Search, 
  Filter, 
  ShieldCheck, 
  ShieldAlert, 
  Clock, 
  Globe, 
  Copy, 
  Check, 
  Lock, 
  Unlock, 
  AlertCircle 
} from 'lucide-react';

/**
 * S3Page Component
 * Admin-level viewport presenting real-time monitoring of S3 Object Storage resources
 * and public exposure block parameters.
 */
export default function S3Page() {
  const { data, loading, error, refetch } = useS3();
  
  // Local UI filters
  const [searchTerm, setSearchTerm] = useState('');
  const [accessFilter, setAccessFilter] = useState('all');
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const handleCopy = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(id);
    setTimeout(() => setCopiedField(null), 1500);
  };

  const buckets = data?.buckets || [];
  const summary = data?.summary || { total_buckets: 0 };

  // Filter logic
  const filteredBuckets = buckets.filter(bucket => {
    const matchesSearch = 
      bucket.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      bucket.arn.toLowerCase().includes(searchTerm.toLowerCase());
    
    let matchesAccess = true;
    if (accessFilter !== 'all') {
      matchesAccess = bucket.public_access.toLowerCase() === accessFilter.toLowerCase();
    }

    return matchesSearch && matchesAccess;
  });

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="S3 Buckets Monitor" 
        description="Comprehensive security posture audit of Amazon S3 storage structures, mapping public block status, encryption, and geographic locations."
      >
        <button 
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Storage</span>
        </button>
      </PageHeader>

      {/* Error Warnings */}
      {error && (
        <div className="p-4 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
              AWS Service Warning
            </h4>
            <p className="text-xs text-rose-200/80 leading-relaxed">
              {error}. Please check that your IAM user credentials contain read permissions for `s3:ListAllMyBuckets`.
            </p>
          </div>
        </div>
      )}

      {/* Stats KPI Board */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        
        {/* Total Buckets Card */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl relative overflow-hidden group">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Total Storage Buckets
            </span>
            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-extrabold text-white font-mono leading-none">
                {loading ? '...' : summary.total_buckets}
              </span>
              <span className="text-xs text-slate-400 font-medium">allocated</span>
            </div>
          </div>
          <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-400">
            <Database className="w-5 h-5 text-amber-500 animate-pulse" />
          </div>
        </div>

        {/* Securely Blocked buckets count */}
        {!loading && (
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl relative overflow-hidden group">
            <div className="space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                Securely Blocked
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold text-emerald-400 font-mono leading-none">
                  {buckets.filter(b => b.public_access === 'Blocked').length}
                </span>
                <span className="text-xs text-slate-400 font-medium">isolated</span>
              </div>
            </div>
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-400">
              <Lock className="w-5 h-5 text-emerald-500" />
            </div>
          </div>
        )}

        {/* Public or Exposed warning buckets */}
        {!loading && (
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl relative overflow-hidden group sm:col-span-2 lg:col-span-1">
            <div className="space-y-2">
              <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
                Public / Partially Exposed
              </span>
              <div className="flex items-baseline gap-2">
                <span className={`text-3xl font-extrabold font-mono leading-none ${
                  buckets.some(b => b.public_access === 'Public') ? 'text-rose-400' : 'text-slate-400'
                }`}>
                  {buckets.filter(b => b.public_access === 'Public' || b.public_access === 'Partially Blocked').length}
                </span>
                <span className="text-xs text-slate-400 font-medium">exposed</span>
              </div>
            </div>
            <div className="p-3 bg-slate-900 border border-slate-800 rounded-xl text-slate-400">
              <Unlock className="w-5 h-5 text-rose-500" />
            </div>
          </div>
        )}

      </div>

      {/* Control Filters Toolbar */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between shadow-lg">
        
        {/* Search Input */}
        <div className="relative w-full md:max-w-md">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search S3 Buckets by Name or ARN..."
            className="w-full pl-10 pr-4 py-2 bg-slate-950 border border-slate-800 rounded-xl text-xs font-mono text-slate-300 focus:outline-none focus:border-amber-500/40 focus:ring-1 focus:ring-amber-500/20 placeholder-slate-600 transition"
          />
        </div>

        {/* Filter Badges */}
        <div className="flex items-center gap-2 self-start md:self-auto shrink-0 overflow-x-auto w-full md:w-auto pb-2 md:pb-0">
          <div className="flex items-center gap-1.5 text-slate-500 text-xs font-mono uppercase font-bold mr-2 shrink-0">
            <Filter className="w-3.5 h-3.5" />
            <span>Exposure:</span>
          </div>

          {[
            { id: 'all', label: 'All Buckets' },
            { id: 'blocked', label: 'Blocked' },
            { id: 'public', label: 'Public' }
          ].map(opt => (
            <button
              key={opt.id}
              onClick={() => setAccessFilter(opt.id)}
              className={`px-3 py-1.5 rounded-xl text-xs font-mono font-semibold tracking-wide border transition-all shrink-0 ${
                accessFilter === opt.id
                  ? 'bg-amber-500/10 border-amber-500/30 text-amber-400'
                  : 'bg-slate-950/60 border-slate-900 text-slate-400 hover:text-slate-200'
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <div className="shrink-0">
          <ExportMenu data={filteredBuckets} filenamePrefix="AWS_S3_Buckets" />
        </div>

      </div>

      {/* Main Table View */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
        
        {loading ? (
          <div className="p-8 space-y-4">
            <div className="h-8 bg-slate-900 rounded-xl animate-pulse"></div>
            <div className="h-40 bg-slate-900 rounded-xl animate-pulse"></div>
          </div>
        ) : filteredBuckets.length === 0 ? (
          <div className="p-16 text-center space-y-4">
            <div className="w-14 h-14 bg-slate-950 border border-slate-800 rounded-2xl flex items-center justify-center text-slate-500 mx-auto">
              <Database className="w-6 h-6 text-slate-600" />
            </div>
            <div className="space-y-1.5 max-w-md mx-auto">
              <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono">
                No storage resources found
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed font-sans">
                {searchTerm || accessFilter !== 'all'
                  ? 'No S3 buckets matched your current search and active exposure filters.'
                  : 'No S3 buckets found.'}
              </p>
            </div>
            {(searchTerm || accessFilter !== 'all') && (
              <button
                onClick={() => { setSearchTerm(''); setAccessFilter('all'); }}
                className="text-xs font-mono font-bold text-amber-500 hover:text-amber-400 underline decoration-dotted"
              >
                Clear Filters
              </button>
            )}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/40 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                  <th className="px-6 py-4">Bucket Name / Identifier</th>
                  <th className="px-6 py-4">S3 Region</th>
                  <th className="px-6 py-4">Versioning</th>
                  <th className="px-6 py-4">SSE Encryption</th>
                  <th className="px-6 py-4">Public Access Status</th>
                  <th className="px-6 py-4">Created Date</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {filteredBuckets.map((bucket) => {
                  const versionLower = bucket.versioning.toLowerCase();
                  const encLower = bucket.encryption.toLowerCase();
                  const accessLower = bucket.public_access.toLowerCase();

                  // Versioning badge styling
                  const versionBadge = 
                    versionLower === 'enabled'
                      ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                      : 'bg-slate-900 border-slate-800 text-slate-400';

                  // Encryption badge styling
                  const encryptionBadge = 
                    encLower === 'enabled'
                      ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                      : encLower === 'disabled'
                        ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                        : 'bg-amber-500/10 border-amber-500/20 text-amber-400';

                  // Public access block status badge styling
                  const publicAccessBadge = 
                    accessLower === 'blocked'
                      ? 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'
                      : accessLower === 'public'
                        ? 'bg-rose-500/10 border-rose-500/20 text-rose-400'
                        : 'bg-amber-500/10 border-amber-500/20 text-amber-400';

                  return (
                    <tr key={bucket.name} className="hover:bg-slate-900/20 transition-colors">
                      
                      {/* Name & ARN Column */}
                      <td className="px-6 py-4">
                        <div className="space-y-1">
                          <span className="font-bold text-xs text-white block truncate max-w-[220px]" title={bucket.name}>
                            {bucket.name}
                          </span>
                          <div className="flex items-center gap-1.5">
                            <span className="text-[10px] font-mono text-slate-500 select-all font-semibold max-w-[200px] truncate" title={bucket.arn}>
                              {bucket.arn}
                            </span>
                            <button
                              onClick={() => handleCopy(bucket.arn, `arn-${bucket.name}`)}
                              className="text-slate-600 hover:text-slate-400 transition"
                              title="Copy Bucket ARN"
                            >
                              {copiedField === `arn-${bucket.name}` ? (
                                <Check className="w-3 h-3 text-emerald-500" />
                              ) : (
                                <Copy className="w-3 h-3" />
                              )}
                            </button>
                          </div>
                        </div>
                      </td>

                      {/* Region Constraint */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 text-xs text-slate-300 font-mono">
                          <Globe className="w-3.5 h-3.5 text-slate-500" />
                          <span>{bucket.region}</span>
                        </div>
                      </td>

                      {/* Versioning Badges */}
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 border rounded-xl text-[10px] font-mono uppercase font-bold ${versionBadge}`}>
                          {bucket.versioning}
                        </span>
                      </td>

                      {/* Encryption Badges */}
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1 px-2.5 py-1 border rounded-xl text-[10px] font-mono uppercase font-bold ${encryptionBadge}`}>
                          {bucket.encryption}
                        </span>
                      </td>

                      {/* Public Access Badges */}
                      <td className="px-6 py-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 border rounded-xl text-[10px] font-mono uppercase font-extrabold ${publicAccessBadge}`}>
                          {accessLower === 'blocked' ? (
                            <ShieldCheck className="w-3 h-3" />
                          ) : (
                            <ShieldAlert className="w-3 h-3" />
                          )}
                          {bucket.public_access}
                        </span>
                      </td>

                      {/* Creation Date */}
                      <td className="px-6 py-4">
                        <div className="flex items-center gap-1.5 text-xs text-slate-300">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          <span className="text-[10px] font-mono font-semibold">
                            {bucket.creation_date !== 'N/A'
                              ? new Date(bucket.creation_date).toLocaleDateString('en-US', {
                                  month: 'short',
                                  day: 'numeric',
                                  year: 'numeric'
                                })
                              : 'N/A'}
                          </span>
                        </div>
                      </td>

                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}

      </div>

    </div>
  );
}
