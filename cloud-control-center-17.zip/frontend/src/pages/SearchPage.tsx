import { useEffect, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { useSearch } from '../hooks/useSearch';
import PageHeader from '../components/common/PageHeader';
import SearchResultCard from '../components/search/SearchResultCard';
import SearchResultsTable from '../components/search/SearchResultsTable';
import { 
  Search, 
  Layers, 
  Server, 
  Database, 
  ShieldAlert, 
  AlertTriangle, 
  Clock, 
  Trash2, 
  FolderOpen,
  ArrowRight
} from 'lucide-react';

export default function SearchPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const queryParam = searchParams.get('q') || '';
  
  const { 
    results, 
    loading, 
    error, 
    recentSearches, 
    addRecentSearch, 
    clearRecentSearches
  } = useSearch(queryParam);

  const [filterService, setFilterService] = useState<'ALL' | 'EC2' | 'S3' | 'IAM'>('ALL');
  const [viewStyle, setViewStyle] = useState<'grid' | 'table'>('table');
  const [localInput, setLocalInput] = useState(queryParam);

  // Perform search when queryParam changes
  useEffect(() => {
    setLocalInput(queryParam);
    if (queryParam) {
      addRecentSearch(queryParam);
    }
  }, [queryParam, addRecentSearch]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = localInput.trim();
    if (trimmed) {
      setSearchParams({ q: trimmed });
    }
  };

  const handleRecentClick = (recent: string) => {
    setSearchParams({ q: recent });
  };

  // Filtered results based on selected service tab
  const filteredResults = useMemo(() => {
    if (!results?.results) return [];
    if (filterService === 'ALL') return results.results;
    return results.results.filter(r => r.service === filterService);
  }, [results, filterService]);

  // Compute metrics
  const serviceCounts = useMemo(() => {
    const counts = { ALL: 0, EC2: 0, S3: 0, IAM: 0 };
    if (!results?.results) return counts;
    results.results.forEach(r => {
      counts.ALL++;
      if (r.service === 'EC2' || r.service === 'S3' || r.service === 'IAM') {
        counts[r.service]++;
      }
    });
    return counts;
  }, [results]);

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="Global AWS Search" 
        description="Unified index of all running resources, static object containers, and security credentials registered across AWS accounts."
      />

      {/* Main Grid: Search Content & Recent Searches Side Column */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        
        {/* Left Search Engine Controls & Results (3 cols) */}
        <div className="lg:col-span-3 space-y-6">
          
          {/* Custom Search Box Form */}
          <form onSubmit={handleSearchSubmit} className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            <h3 className="text-xs font-bold font-mono uppercase text-slate-400 tracking-wider">
              Search Console Engine
            </h3>
            <div className="flex gap-3">
              <div className="relative flex-1">
                <Search className="absolute left-3.5 top-3 w-4 h-4 text-slate-500" />
                <input 
                  type="text"
                  value={localInput}
                  onChange={(e) => setLocalInput(e.target.value)}
                  placeholder="Enter Resource ID, tag name, S3 bucket descriptor, or IAM identity username..."
                  className="w-full pl-11 pr-4 py-2.5 bg-slate-950 border border-slate-800/80 rounded-xl text-xs text-slate-300 placeholder-slate-500 focus:outline-none focus:border-amber-500/50 font-mono transition-colors"
                />
              </div>
              <button 
                type="submit"
                disabled={loading}
                className="px-5 py-2.5 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-950 text-xs uppercase font-bold tracking-wider rounded-xl font-mono shadow-md transition disabled:opacity-50 shrink-0"
              >
                {loading ? 'Searching...' : 'Search'}
              </button>
            </div>
          </form>

          {/* Service Filters & Tab controls */}
          {results && results.total_results > 0 && (
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800/60 pb-2">
              <div className="flex bg-slate-950 p-1 border border-slate-800/80 rounded-xl font-mono text-[11px] font-bold">
                <button
                  onClick={() => setFilterService('ALL')}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    filterService === 'ALL' 
                      ? 'bg-slate-900 text-white shadow' 
                      : 'text-slate-500 hover:text-slate-300'
                  }`}
                >
                  <Layers className="w-3.5 h-3.5" />
                  All ({serviceCounts.ALL})
                </button>
                <button
                  onClick={() => setFilterService('EC2')}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    filterService === 'EC2' 
                      ? 'bg-slate-900 text-orange-400 shadow' 
                      : 'text-slate-500 hover:text-orange-400'
                  }`}
                >
                  <Server className="w-3.5 h-3.5" />
                  EC2 ({serviceCounts.EC2})
                </button>
                <button
                  onClick={() => setFilterService('S3')}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    filterService === 'S3' 
                      ? 'bg-slate-900 text-emerald-400 shadow' 
                      : 'text-slate-500 hover:text-emerald-400'
                  }`}
                >
                  <Database className="w-3.5 h-3.5" />
                  S3 ({serviceCounts.S3})
                </button>
                <button
                  onClick={() => setFilterService('IAM')}
                  className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
                    filterService === 'IAM' 
                      ? 'bg-slate-900 text-purple-400 shadow' 
                      : 'text-slate-500 hover:text-purple-400'
                  }`}
                >
                  <FolderOpen className="w-3.5 h-3.5" />
                  IAM ({serviceCounts.IAM})
                </button>
              </div>

              {/* View Layout Switcher */}
              <div className="flex bg-slate-950 p-1 border border-slate-800/80 rounded-xl font-mono text-[10px] font-bold self-end sm:self-auto">
                <button
                  onClick={() => setViewStyle('table')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    viewStyle === 'table' ? 'bg-slate-900 text-white shadow' : 'text-slate-500'
                  }`}
                >
                  Table
                </button>
                <button
                  onClick={() => setViewStyle('grid')}
                  className={`px-2.5 py-1 rounded-lg transition-all ${
                    viewStyle === 'grid' ? 'bg-slate-900 text-white shadow' : 'text-slate-500'
                  }`}
                >
                  Bento Grid
                </button>
              </div>
            </div>
          )}

          {/* Results Visualizer Canvas */}
          {loading ? (
            <div className="space-y-4">
              <div className="h-10 bg-slate-900 rounded-xl animate-pulse"></div>
              <div className="h-44 bg-slate-900 rounded-xl animate-pulse"></div>
            </div>
          ) : error ? (
            <div className="p-5 rounded-2xl bg-rose-500/10 border border-rose-500/20 text-rose-300 flex items-start gap-3.5">
              <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
              <div className="space-y-1">
                <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
                  Search Scan Interrupted
                </h4>
                <p className="text-xs text-rose-200/80 leading-relaxed font-mono">
                  {error}
                </p>
              </div>
            </div>
          ) : !queryParam ? (
            <div className="bg-[#0f1422]/30 border border-slate-800/40 rounded-2xl p-12 text-center space-y-4 max-w-xl mx-auto">
              <div className="w-12 h-12 rounded-2xl bg-amber-500/5 border border-amber-500/10 flex items-center justify-center text-amber-500 mx-auto">
                <Search className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
                  Global Search Portal Ready
                </h4>
                <p className="text-xs text-slate-500 font-mono leading-relaxed">
                  Type an identifier in the query engine above to index running EC2 nodes, storage buckets, or identities instantly.
                </p>
              </div>
            </div>
          ) : filteredResults.length === 0 ? (
            <div className="bg-[#0f1422]/30 border border-slate-800/40 rounded-2xl p-16 text-center space-y-4 max-w-xl mx-auto">
              <div className="w-12 h-12 rounded-2xl bg-slate-900/50 border border-slate-800/50 flex items-center justify-center text-slate-500 mx-auto">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <div className="space-y-1">
                <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
                  No matching AWS resources found.
                </h4>
                <p className="text-xs text-slate-500 font-mono leading-relaxed">
                  We scanned EC2 instances, S3 buckets, and IAM structures with index key "{queryParam}" but found zero matching definitions.
                </p>
              </div>
            </div>
          ) : viewStyle === 'table' ? (
            <div className="space-y-2">
              <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wide px-1">
                Showing {filteredResults.length} matching resource(s)
              </div>
              <SearchResultsTable results={filteredResults} />
            </div>
          ) : (
            <div className="space-y-4">
              <div className="text-[10px] text-slate-500 font-mono uppercase tracking-wide px-1">
                Showing {filteredResults.length} matching resource(s)
              </div>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                {filteredResults.map((item, idx) => (
                  <SearchResultCard key={`${item.resource_id}-${idx}`} result={item} />
                ))}
              </div>
            </div>
          )}

        </div>

        {/* Right Recent Searches Sidebar (1 col) */}
        <div className="space-y-6">
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-5 shadow-xl space-y-4">
            
            <div className="flex items-center justify-between pb-2 border-b border-slate-800/60">
              <span className="text-xs font-bold font-mono uppercase text-slate-300 tracking-wider flex items-center gap-1.5">
                <Clock className="w-4 h-4 text-amber-500" />
                Recent Queries
              </span>
              
              {recentSearches.length > 0 && (
                <button 
                  onClick={clearRecentSearches}
                  className="text-slate-500 hover:text-rose-400 p-1 rounded hover:bg-slate-900 font-mono text-[10px] uppercase font-bold transition flex items-center gap-1"
                  title="Clear history log"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  Clear
                </button>
              )}
            </div>

            {recentSearches.length === 0 ? (
              <p className="text-xs text-slate-500 font-mono py-4">
                No recent searches in local storage history.
              </p>
            ) : (
              <div className="space-y-1.5">
                {recentSearches.map((term, index) => (
                  <button
                    key={`${term}-${index}`}
                    onClick={() => handleRecentClick(term)}
                    className="w-full text-left px-3 py-2 bg-slate-950/40 hover:bg-slate-950 border border-slate-900 hover:border-slate-800 rounded-xl font-mono text-xs text-slate-400 hover:text-white flex items-center justify-between transition group"
                  >
                    <span className="truncate max-w-[150px]">{term}</span>
                    <ArrowRight className="w-3.5 h-3.5 opacity-0 group-hover:opacity-100 text-amber-500 transition-opacity" />
                  </button>
                ))}
              </div>
            )}

            {/* Quick Helper guidelines */}
            <div className="p-3 bg-amber-500/5 border border-amber-500/10 rounded-xl space-y-1.5 text-[10.5px] text-slate-500 leading-relaxed font-mono">
              <span className="text-white font-bold block uppercase text-[9.5px]">Search guidelines</span>
              <p>Case-insensitive scanning looks up Name tags or IDs on servers, Bucket descriptors, and user identifiers safely.</p>
            </div>

          </div>
        </div>

      </div>

    </div>
  );
}
