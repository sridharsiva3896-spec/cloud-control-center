import { useState, useMemo } from 'react';
import { useSecurity } from '../hooks/useSecurity';
import { useBackendStatus } from '../api/BackendStatusContext';
import PageHeader from '../components/common/PageHeader';
import ExportMenu from '../components/common/ExportMenu';
import { 
  ShieldAlert, 
  ShieldCheck, 
  Shield, 
  RefreshCw, 
  AlertTriangle, 
  CheckCircle2, 
  Key, 
  Lock, 
  Users, 
  FolderOpen, 
  AlertCircle,
  Clock
} from 'lucide-react';

/**
 * AWS Security Compliance Audit Console
 */
export default function SecurityPage() {
  const { awsState, triggerConnectAWS } = useBackendStatus();
  const { data, loading, error, refetch } = useSecurity();
  const [activeTab, setActiveTab] = useState<'all' | 'failed'>('all');

  const summary = data?.summary || { security_score: 100, critical: 0, warning: 0, passed: 0 };
  const checks = data?.checks;
  const isEnabled = data?.enabled ?? true;

  const isPermissionDenied = error?.toLowerCase().includes("permission") || 
                             error?.toLowerCase().includes("accessdenied") || 
                             error?.toLowerCase().includes("access denied") ||
                             data?.message?.toLowerCase().includes("permission") ||
                             data?.message?.toLowerCase().includes("accessdenied") ||
                             data?.message?.toLowerCase().includes("access denied");

  if (!awsState.connected) {
    return (
      <div className="space-y-8 animate-fade-in max-w-4xl mx-auto py-12 px-4">
        <PageHeader 
          title="AWS Security Compliance" 
          description="Assess structural vulnerabilities, posture configurations, IAM identities, and S3 block protections." 
        />
        <div className="p-16 text-center space-y-5 bg-[#0f1422] border border-slate-800 rounded-2xl shadow-xl max-w-md mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-slate-900 border border-slate-800 flex items-center justify-center text-slate-400 mx-auto">
            <Shield className="w-5 h-5" />
          </div>
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              AWS Account Disconnected
            </h4>
            <p className="text-xs text-slate-400 font-mono leading-relaxed">
              Connect AWS to run security checks
            </p>
          </div>
          <button
            onClick={() => triggerConnectAWS()}
            className="px-4 py-2 bg-amber-500 hover:bg-amber-600 text-slate-950 font-bold rounded-xl text-xs font-mono transition shadow-sm"
          >
            Connect AWS
          </button>
        </div>
      </div>
    );
  }

  if (isPermissionDenied && !loading) {
    return (
      <div className="space-y-8 animate-fade-in max-w-4xl mx-auto py-12 px-4">
        <PageHeader 
          title="AWS Security Compliance" 
          description="Assess structural vulnerabilities, posture configurations, IAM identities, and S3 block protections." 
        />
        <div className="p-16 text-center space-y-5 bg-[#0f1422] border border-rose-500/20 rounded-2xl shadow-xl max-w-md mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mx-auto">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              Permission Denied
            </h4>
            <p className="text-xs text-rose-300/70 font-mono leading-relaxed">
              Security audit requires additional AWS permissions
            </p>
          </div>
          <button
            onClick={() => refetch(true)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold border border-slate-700 rounded-xl text-xs font-mono transition"
          >
            Retry Scan
          </button>
        </div>
      </div>
    );
  }

  if ((error || !isEnabled) && !loading) {
    return (
      <div className="space-y-8 animate-fade-in max-w-4xl mx-auto py-12 px-4">
        <PageHeader 
          title="AWS Security Compliance" 
          description="Assess structural vulnerabilities, posture configurations, IAM identities, and S3 block protections." 
        />
        <div className="p-16 text-center space-y-5 bg-[#0f1422] border border-rose-500/20 rounded-2xl shadow-xl max-w-md mx-auto">
          <div className="w-12 h-12 rounded-2xl bg-rose-500/10 border border-rose-500/20 flex items-center justify-center text-rose-400 mx-auto">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
              Service Unavailable
            </h4>
            <p className="text-xs text-rose-300/70 font-mono leading-relaxed">
              Security data currently unavailable
            </p>
          </div>
          <button
            onClick={() => refetch(true)}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold border border-slate-700 rounded-xl text-xs font-mono transition"
          >
            Retry
          </button>
        </div>
      </div>
    );
  }

  // Compile checks into a list for the Findings Table
  const compiledFindingsList = useMemo(() => {
    if (!checks) return [];

    return [
      {
        id: 'root_account',
        name: 'Root Account Usage Status',
        status: checks.root_account.status,
        severity: checks.root_account.status === 'PASSED' ? 'LOW' : 'HIGH',
        details: checks.root_account.details,
        recommendation: 'Use AWS Organizations and IAM Identity Center for daily operations; store root credentials securely and delete root access keys.'
      },
      {
        id: 'mfa',
        name: 'IAM Multi-Factor Authentication',
        status: checks.mfa.status,
        severity: checks.mfa.status === 'CRITICAL' ? 'CRITICAL' : (checks.mfa.status === 'WARNING' ? 'MEDIUM' : 'LOW'),
        details: checks.mfa.error || `${checks.mfa.users_without_mfa.length} out of ${checks.mfa.total_users} users lack active hardware or virtual MFA device keys.`,
        recommendation: 'Enforce MFA policies for all IAM console access, especially administrative roles.'
      },
      {
        id: 'access_keys',
        name: 'Access Key Rotation Policy',
        status: checks.access_keys.status,
        severity: checks.access_keys.status === 'PASSED' ? 'LOW' : 'MEDIUM',
        details: checks.access_keys.error || `${checks.access_keys.old_keys.length} active key(s) are older than the 90-day threshold.`,
        recommendation: 'Periodically rotate long-lived programmatic Access Keys; transition to short-lived IAM session roles where possible.'
      },
      {
        id: 'public_buckets',
        name: 'S3 Public Isolation Access Block',
        status: checks.public_buckets.status,
        severity: checks.public_buckets.status === 'CRITICAL' ? 'CRITICAL' : (checks.public_buckets.status === 'WARNING' ? 'MEDIUM' : 'LOW'),
        details: checks.public_buckets.error || `${checks.public_buckets.public_buckets.length} bucket(s) do not have active complete public access blocks.`,
        recommendation: 'Enable Amazon S3 Block Public Access at the account or bucket level unless assets are explicitly static public web hosting.'
      },
      {
        id: 'password_policy',
        name: 'IAM Password Complexity Policy',
        status: checks.password_policy.status,
        severity: checks.password_policy.status === 'PASSED' ? 'LOW' : 'MEDIUM',
        details: checks.password_policy.error || (checks.password_policy.configured 
          ? `Password policy is active (minimum length ${checks.password_policy.minimum_length}).` 
          : 'No custom password policy configured; default parameters apply.'),
        recommendation: 'Update the Account Password Policy to mandate at least 12 characters, including upper, lower, digits, and symbols.'
      }
    ];
  }, [checks]);

  // Filter list based on active view tab
  const visibleFindings = useMemo(() => {
    if (activeTab === 'all') return compiledFindingsList;
    return compiledFindingsList.filter(f => f.status !== 'PASSED');
  }, [compiledFindingsList, activeTab]);

  // Helper to resolve severity status text colors and badges
  const getStatusBadge = (status: 'PASSED' | 'WARNING' | 'CRITICAL') => {
    switch (status) {
      case 'PASSED':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[10.5px] font-bold font-mono uppercase text-emerald-400 bg-emerald-500/10 border border-emerald-500/15 rounded-lg">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
            Passed
          </span>
        );
      case 'WARNING':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[10.5px] font-bold font-mono uppercase text-amber-400 bg-amber-500/10 border border-amber-500/15 rounded-lg">
            <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
            Warning
          </span>
        );
      case 'CRITICAL':
        return (
          <span className="inline-flex items-center gap-1.5 px-2.5 py-1 text-[10.5px] font-bold font-mono uppercase text-rose-400 bg-rose-500/10 border border-rose-500/15 rounded-lg animate-pulse">
            <AlertCircle className="w-3.5 h-3.5 text-rose-400" />
            Critical
          </span>
        );
      default:
        return null;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'CRITICAL':
        return 'text-rose-400 font-extrabold';
      case 'HIGH':
        return 'text-orange-400 font-bold';
      case 'MEDIUM':
        return 'text-amber-400 font-medium';
      default:
        return 'text-slate-400';
    }
  };

  // Check if everything passes to show elegant message
  const isEverythingSecure = !loading && isEnabled && summary.critical === 0 && summary.warning === 0;

  return (
    <div className="space-y-8 animate-fade-in">
      
      {/* Page Header */}
      <PageHeader 
        title="AWS Security Compliance" 
        description="Continuous, read-only credential scanning, resource exposure audit, identity MFA checks, and password integrity checks."
      >
        <button 
          onClick={() => refetch(true)}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-800/60 hover:bg-slate-800 text-slate-300 hover:text-white border border-slate-800 rounded-xl text-xs font-mono font-bold transition-all disabled:opacity-50 shadow-sm"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Trigger Scan</span>
        </button>
      </PageHeader>

      {/* Warning Alert */}
      {(!isEnabled || error) && (
        <div className="p-4.5 rounded-2xl bg-amber-500/10 border border-amber-500/20 text-amber-300 flex items-start gap-3.5">
          <AlertTriangle className="w-5 h-5 text-amber-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono uppercase tracking-wider text-white">
              Compliance Scanning Impeded
            </h4>
            <p className="text-xs text-amber-200/80 leading-relaxed font-mono">
              {error || 'The background scan completed with limitations. Ensure your AWS IAM policies contain complete authorization flags for iam:GetAccountPasswordPolicy, iam:GenerateCredentialReport, and s3:GetPublicAccessBlock.'}
            </p>
          </div>
        </div>
      )}

      {/* Security KPI Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-6">
        
        {/* Security Score */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              AWS Security Score
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className={`text-3xl font-extrabold font-mono leading-none ${
                summary.security_score >= 90 ? 'text-emerald-400' : (summary.security_score >= 70 ? 'text-amber-400' : 'text-rose-400')
              }`}>
                {loading ? '...' : `${summary.security_score}%`}
              </span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              <span>Weighted configuration score</span>
            </div>
          </div>
          <div className={`p-3 rounded-xl border bg-slate-900 border-slate-800 ${
            summary.security_score >= 90 ? 'text-emerald-400' : 'text-amber-400'
          }`}>
            <Shield className="w-5 h-5" />
          </div>
        </div>

        {/* Critical Findings */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Critical Findings
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className={`text-3xl font-extrabold font-mono leading-none ${summary.critical > 0 ? 'text-rose-400 animate-pulse' : 'text-slate-300'}`}>
                {loading ? '...' : summary.critical}
              </span>
              <span className="text-[10.5px] text-slate-500 font-mono font-bold uppercase">Actions Required</span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              <span>High exposure vulnerability indicators</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-rose-500">
            <ShieldAlert className="w-5 h-5" />
          </div>
        </div>

        {/* Warnings */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Warning Alerts
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className={`text-3xl font-extrabold font-mono leading-none ${summary.warning > 0 ? 'text-amber-400' : 'text-slate-300'}`}>
                {loading ? '...' : summary.warning}
              </span>
              <span className="text-[10.5px] text-slate-500 font-mono font-bold uppercase">Audit warnings</span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              <span>Medium risk hardening recommendations</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-amber-400">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        {/* Passed Checks */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 flex items-center justify-between shadow-xl">
          <div className="space-y-2">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">
              Passed Checks
            </span>
            <div className="flex items-baseline gap-1.5">
              <span className="text-3xl font-extrabold text-emerald-400 font-mono leading-none">
                {loading ? '...' : summary.passed}
              </span>
              <span className="text-[10.5px] text-slate-500 font-mono font-bold uppercase">Success</span>
            </div>
            <div className="text-[11px] text-slate-500 font-mono">
              <span>Aligned security guidelines</span>
            </div>
          </div>
          <div className="p-3 rounded-xl border bg-slate-900 border-slate-800 text-emerald-400">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>

      </div>

      {/* Compliance Table Block */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl overflow-hidden shadow-xl">
        
        <div className="p-5 border-b border-slate-800/80 bg-slate-900/10 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
          <div className="space-y-1">
            <h3 className="text-sm font-bold text-white uppercase tracking-wider font-mono flex items-center gap-2">
              <Shield className="w-4 h-4 text-rose-500" />
              Compliance Findings Ledger
            </h3>
            <p className="text-xs text-slate-500 font-mono">
              Comprehensive list of assessed parameters, vulnerabilities, and hardening protocols.
            </p>
          </div>

          {/* Toggle Tab Filters & Export Menu */}
          <div className="flex flex-col sm:flex-row items-stretch sm:items-center gap-3">
            <div className="flex bg-slate-950 p-1 border border-slate-800/80 rounded-xl font-mono text-xs font-bold">
              <button
                onClick={() => setActiveTab('all')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'all' 
                    ? 'bg-slate-900 text-white shadow' 
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                All Assessed ({compiledFindingsList.length})
              </button>
              <button
                onClick={() => setActiveTab('failed')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  activeTab === 'failed' 
                    ? 'bg-slate-900 text-rose-400 shadow' 
                    : 'text-slate-500 hover:text-slate-300'
                }`}
              >
                Issues Only ({compiledFindingsList.filter(f => f.status !== 'PASSED').length})
              </button>
            </div>
            <ExportMenu data={visibleFindings} filenamePrefix={`AWS_Security_Findings_${activeTab}`} />
          </div>
        </div>

        {loading ? (
          <div className="p-8 space-y-4">
            <div className="h-8 bg-slate-900 rounded-xl animate-pulse"></div>
            <div className="h-44 bg-slate-900 rounded-xl animate-pulse"></div>
          </div>
        ) : isEverythingSecure && activeTab === 'failed' ? (
          <div className="p-16 text-center space-y-4">
            <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center text-emerald-400 mx-auto">
              <ShieldCheck className="w-5 h-5" />
            </div>
            <div className="space-y-1">
              <h4 className="text-xs font-bold text-white font-mono uppercase tracking-wider">
                No security findings detected.
              </h4>
              <p className="text-xs text-slate-500 font-mono">
                All cloud audits are entirely green and aligned to baseline security requirements.
              </p>
            </div>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full border-collapse text-left">
              <thead>
                <tr className="border-b border-slate-800 bg-slate-900/30 text-[10px] font-mono uppercase font-bold text-slate-500 tracking-wider">
                  <th className="px-6 py-4">Security Assessment Check</th>
                  <th className="px-6 py-4">Status</th>
                  <th className="px-6 py-4">Severity</th>
                  <th className="px-6 py-4">Impact / Current State</th>
                  <th className="px-6 py-4">Hardening Protocol Recommendation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50 text-xs text-slate-300">
                {visibleFindings.map((item) => (
                  <tr key={item.id} className="hover:bg-slate-900/10 transition-colors">
                    
                    {/* Assessment Name */}
                    <td className="px-6 py-4 font-mono font-bold text-white">
                      {item.name}
                    </td>

                    {/* Status badge */}
                    <td className="px-6 py-4">
                      {getStatusBadge(item.status)}
                    </td>

                    {/* Severity level */}
                    <td className="px-6 py-4 font-mono uppercase text-[11px]">
                      <span className={getSeverityColor(item.severity)}>{item.severity}</span>
                    </td>

                    {/* Details status */}
                    <td className="px-6 py-4 font-mono text-[11px] text-slate-400 leading-relaxed max-w-sm">
                      {item.details}
                    </td>

                    {/* Hardening recommendation */}
                    <td className="px-6 py-4 font-mono text-[11px] text-slate-500 leading-relaxed max-w-sm">
                      {item.recommendation}
                    </td>

                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

      </div>

      {/* Segmented Cards Section (Four details cards for Password Policy, Public Buckets, MFA, Access keys) */}
      {!loading && checks && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* 1. PASSWORD COMPLEXITY POLICY CARD */}
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-purple-400">
                  <Lock className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    IAM Password Policy Complexity Settings
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Checks current administrative configuration rules on password parameters.
                  </p>
                </div>
              </div>

              {/* Rules List */}
              <div className="grid grid-cols-2 gap-4 pt-2 text-xs font-mono">
                
                {/* Min Length */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/60 flex flex-col justify-between">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Minimum Length</span>
                  <span className="text-white font-bold text-lg mt-1">{checks.password_policy.minimum_length} characters</span>
                </div>

                {/* Symbols Requirement */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/60 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Requires Symbols</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                    checks.password_policy.require_symbols 
                      ? 'text-emerald-400 bg-emerald-500/5' 
                      : 'text-amber-500 bg-amber-500/5'
                  }`}>
                    {checks.password_policy.require_symbols ? 'Yes' : 'No'}
                  </span>
                </div>

                {/* Numbers Requirement */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/60 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Requires Numbers</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                    checks.password_policy.require_numbers 
                      ? 'text-emerald-400 bg-emerald-500/5' 
                      : 'text-amber-500 bg-amber-500/5'
                  }`}>
                    {checks.password_policy.require_numbers ? 'Yes' : 'No'}
                  </span>
                </div>

                {/* Case requirements */}
                <div className="bg-slate-950 p-3 rounded-xl border border-slate-800/60 flex items-center justify-between">
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider">Requires Case Variety</span>
                  <span className={`px-2 py-0.5 rounded text-[10px] uppercase font-bold ${
                    checks.password_policy.require_uppercase && checks.password_policy.require_lowercase 
                      ? 'text-emerald-400 bg-emerald-500/5' 
                      : 'text-amber-500 bg-amber-500/5'
                  }`}>
                    {checks.password_policy.require_uppercase && checks.password_policy.require_lowercase ? 'Both' : 'None/Single'}
                  </span>
                </div>

              </div>
            </div>

            <div className="pt-4 border-t border-slate-800/60 text-[11px] text-slate-500 font-mono">
              {checks.password_policy.configured ? (
                <span className="text-emerald-400 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  Custom password policy configured securely on this account.
                </span>
              ) : (
                <span className="text-amber-400 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                  Using default credentials policies. Setup a customized policy for robust compliance.
                </span>
              )}
            </div>
          </div>

          {/* 2. PUBLIC S3 BUCKETS EXPOSURE CARD */}
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-orange-400">
                  <FolderOpen className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    Public S3 Buckets Exposure List
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Audits active ACLs, policies, and S3 Public Access Blocks.
                  </p>
                </div>
              </div>

              {checks.public_buckets.public_buckets.length === 0 ? (
                <div className="p-6 bg-slate-950 rounded-xl border border-slate-800/60 flex flex-col items-center justify-center text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                  <p className="text-xs font-bold text-white font-mono uppercase tracking-wider">No Public Buckets</p>
                  <p className="text-[10px] text-slate-500 font-mono">All {checks.public_buckets.total_buckets} indexed S3 buckets have static block policies active.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                  {checks.public_buckets.public_buckets.map((b) => (
                    <div key={b.bucket_name} className="flex items-center justify-between p-2.5 bg-slate-950 rounded-lg border border-slate-800/60 text-xs font-mono">
                      <span className="font-bold text-white truncate max-w-[200px]">{b.bucket_name}</span>
                      <span className="px-2 py-0.5 bg-rose-500/10 border border-rose-500/20 text-rose-400 font-bold rounded text-[10px]">
                        {b.public_access}
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800/60 text-[11px] text-slate-500 font-mono flex items-center justify-between">
              <span>Total audited: {checks.public_buckets.total_buckets} buckets</span>
              <span className="text-[10px] text-slate-600">S3 Control Plane</span>
            </div>
          </div>

          {/* 3. MULTI-FACTOR AUTHENTICATION STATUS (MFA CARD) */}
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-sky-400">
                  <Users className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    MFA Unconfigured Identities
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Flags console users or program assets missing MFA devices.
                  </p>
                </div>
              </div>

              {checks.mfa.users_without_mfa.length === 0 ? (
                <div className="p-6 bg-slate-950 rounded-xl border border-slate-800/60 flex flex-col items-center justify-center text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                  <p className="text-xs font-bold text-white font-mono uppercase tracking-wider">All Users MFA Secure</p>
                  <p className="text-[10px] text-slate-500 font-mono">100% of the {checks.mfa.total_users} console identities have enabled authentication protocols.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-44 overflow-y-auto pr-1">
                  {checks.mfa.users_without_mfa.map((u) => (
                    <div key={u.username} className="flex items-center justify-between p-2.5 bg-slate-950 rounded-lg border border-slate-800/60 text-xs font-mono">
                      <span className="font-bold text-slate-300 truncate">{u.username}</span>
                      <span className="px-2 py-0.5 bg-amber-500/10 border border-amber-500/25 text-amber-400 font-bold rounded text-[10px]">
                        MFA INACTIVE
                      </span>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800/60 text-[11px] text-slate-500 font-mono flex items-center justify-between">
              <span>Total scanned: {checks.mfa.total_users} IAM users</span>
              <span className="text-[10px] text-slate-600">IAM Control Plane</span>
            </div>
          </div>

          {/* 4. KEY DURATION / ROTATION COMPLIANCE (OLD KEYS CARD) */}
          <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-6 shadow-xl space-y-6 flex flex-col justify-between">
            <div className="space-y-4">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-rose-500">
                  <Key className="w-4 h-4" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white uppercase tracking-wider font-mono">
                    Programmatic Access Keys Audit
                  </h3>
                  <p className="text-[11px] text-slate-500 font-mono">
                    Identifies permanent access keys exceeding recommended 90-day rotation age.
                  </p>
                </div>
              </div>

              {checks.access_keys.old_keys.length === 0 ? (
                <div className="p-6 bg-slate-950 rounded-xl border border-slate-800/60 flex flex-col items-center justify-center text-center space-y-2">
                  <CheckCircle2 className="w-8 h-8 text-emerald-500" />
                  <p className="text-xs font-bold text-white font-mono uppercase tracking-wider">Access Keys Aligned</p>
                  <p className="text-[10px] text-slate-500 font-mono">Zero active keys older than 90 days were discovered across accounts.</p>
                </div>
              ) : (
                <div className="space-y-2 max-h-44 overflow-y-auto pr-1 text-xs font-mono">
                  {checks.access_keys.old_keys.map((k) => (
                    <div key={k.key_id} className="p-2.5 bg-slate-950 rounded-lg border border-slate-800/60 space-y-1">
                      <div className="flex justify-between items-center">
                        <span className="font-bold text-white truncate max-w-[150px]">{k.username}</span>
                        <span className="text-slate-500 text-[10px]">{k.key_id}</span>
                      </div>
                      <div className="flex justify-between items-center text-[10.5px]">
                        <span className="text-slate-500 flex items-center gap-1">
                          <Clock className="w-3.5 h-3.5 text-slate-500" />
                          Age: {k.key_age_days} days
                        </span>
                        <span className="font-bold text-rose-400">OUT OF COMPLIANCE</span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            <div className="pt-4 border-t border-slate-800/60 text-[11px] text-slate-500 font-mono flex items-center justify-between">
              <span>Threshold parameters: &gt;90 days</span>
              <span className="text-[10px] text-slate-600">Access Keys</span>
            </div>
          </div>

        </div>
      )}

    </div>
  );
}
