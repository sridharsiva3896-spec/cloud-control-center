import { useState, useCallback } from 'react';
import { RefreshCw, AlertTriangle, Tag } from 'lucide-react';
import PageHeader from '../components/common/PageHeader';
import { useTags } from '../hooks/useTags';
import TagFilters from '../components/tag/TagFilters';
import TagTable from '../components/tag/TagTable';

export default function TagExplorerPage() {
  const { data, loading, error, refetch } = useTags();

  // Filter States
  const [selectedService, setSelectedService] = useState('All');
  const [selectedTagKey, setSelectedTagKey] = useState('All');
  const [selectedRegion, setSelectedRegion] = useState('All');

  const handleResetFilters = useCallback(() => {
    setSelectedService('All');
    setSelectedTagKey('All');
    setSelectedRegion('All');
  }, []);

  const resourcesList = data?.resources || [];

  return (
    <div className="space-y-6">
      
      {/* Header section with manual Refresh action */}
      <PageHeader
        title="AWS Tag Explorer"
        description="Audit, query, and analyze tag keys and values attached to active AWS cloud computing resources, virtual storage buckets, VPC interfaces, database engines, and access policies."
      >
        <button
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-2 px-4 py-2 bg-slate-900 hover:bg-slate-800 disabled:opacity-50 border border-slate-800 text-slate-200 hover:text-white rounded-xl text-xs font-mono font-bold transition-all duration-200 shadow-md active:scale-95 select-none"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Tags</span>
        </button>
      </PageHeader>

      {/* Warning Alert banner if IAM permission issue or error occurs */}
      {error && (
        <div className="bg-rose-500/10 border border-rose-500/20 rounded-2xl p-4 flex items-start gap-3 animate-pulse">
          <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="space-y-1 font-mono">
            <h4 className="text-xs font-bold uppercase text-rose-400 tracking-wider">
              AWS Tag Explorer warning
            </h4>
            <p className="text-xs text-slate-300 font-medium font-sans">
              {error}
            </p>
          </div>
        </div>
      )}

      {/* Dynamic filters based on currently returned resource set */}
      <TagFilters
        resources={resourcesList}
        selectedService={selectedService}
        setSelectedService={setSelectedService}
        selectedTagKey={selectedTagKey}
        setSelectedTagKey={setSelectedTagKey}
        selectedRegion={selectedRegion}
        setSelectedRegion={setSelectedRegion}
        onReset={handleResetFilters}
      />

      {/* Primary listings grid */}
      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <h3 className="text-xs font-mono font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Tag className="w-4 h-4 text-blue-400" />
            <span>Tag Mappings Registry</span>
          </h3>
          <span className="text-[10px] font-mono text-slate-500">
            {loading ? 'Consulting Resource Groups API...' : `Parsed ${resourcesList.length} total keys`}
          </span>
        </div>

        <TagTable
          resources={resourcesList}
          loading={loading}
          selectedService={selectedService}
          selectedTagKey={selectedTagKey}
          selectedRegion={selectedRegion}
        />
      </div>

    </div>
  );
}
