import { useState, useMemo } from 'react';
import PageHeader from '../components/common/PageHeader';
import { useVPC } from '../hooks/useVPC';
import ExportMenu from '../components/common/ExportMenu';
import VPCCard from '../components/vpc/VPCCard';
import SubnetTable from '../components/vpc/SubnetTable';
import RouteTableTable from '../components/vpc/RouteTableTable';
import SecurityGroupTable from '../components/vpc/SecurityGroupTable';
import NetworkACLTable from '../components/vpc/NetworkACLTable';
import InternetGatewayTable from '../components/vpc/InternetGatewayTable';
import NatGatewayTable from '../components/vpc/NatGatewayTable';
import { 
  Network, 
  Layers, 
  Shield, 
  Globe, 
  Cpu, 
  ShieldAlert,
  Search,
  X,
  AlertTriangle,
  RefreshCw,
  SlidersHorizontal,
  ChevronRight
} from 'lucide-react';

type TabType = 'vpcs' | 'subnets' | 'route_tables' | 'security_groups' | 'nacls' | 'gateways';

/**
 * VPCMonitoringPage Component - Production-grade AWS VPC Network Management Dashboard.
 * Integrates Region Switchers, high-end metric cards, client-side search, AZ and state filters,
 * and standard responsive tables.
 */
export default function VPCMonitoringPage() {
  const { data, loading, error, refetch } = useVPC();
  const [activeTab, setActiveTab] = useState<TabType>('vpcs');
  
  // Search & Filters state
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedState, setSelectedState] = useState('');
  const [selectedAZ, setSelectedAZ] = useState('');
  const [selectedDefaultVpc, setSelectedDefaultVpc] = useState('');
  const [showFilters, setShowFilters] = useState(false);

  const summary = data?.summary || {
    vpcs: 0,
    subnets: 0,
    route_tables: 0,
    internet_gateways: 0,
    nat_gateways: 0,
    security_groups: 0,
    network_acls: 0
  };

  // 1. Gather all unique Availability Zones from subnets
  const uniqueAZs = useMemo(() => {
    if (!data?.subnets) return [];
    const azs = data.subnets.map(s => s.availability_zone).filter(Boolean);
    return Array.from(new Set(azs)).sort();
  }, [data?.subnets]);

  // 2. Filter logic for VPCs
  const filteredVpcs = useMemo(() => {
    if (!data?.vpcs) return [];
    return data.vpcs.filter(vpc => {
      // Search matches VPC ID or VPC Name tag
      const vpcName = vpc.tags.find(t => t.Key === 'Name')?.Value || '';
      const matchesSearch = searchQuery === '' || 
        vpc.vpc_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        vpcName.toLowerCase().includes(searchQuery.toLowerCase());

      // State matches
      const matchesState = selectedState === '' || vpc.state === selectedState;

      // Default VPC matches
      const matchesDefault = selectedDefaultVpc === '' || 
        (selectedDefaultVpc === 'true' && vpc.is_default) ||
        (selectedDefaultVpc === 'false' && !vpc.is_default);

      return matchesSearch && matchesState && matchesDefault;
    });
  }, [data?.vpcs, searchQuery, selectedState, selectedDefaultVpc]);

  // 3. Filter logic for Subnets
  const filteredSubnets = useMemo(() => {
    if (!data?.subnets) return [];
    return data.subnets.filter(sub => {
      // Search matches Subnet ID or VPC ID
      const matchesSearch = searchQuery === '' || 
        sub.subnet_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sub.vpc_id.toLowerCase().includes(searchQuery.toLowerCase());

      // State matches
      const matchesState = selectedState === '' || sub.state === selectedState;

      // AZ matches
      const matchesAZ = selectedAZ === '' || sub.availability_zone === selectedAZ;

      return matchesSearch && matchesState && matchesAZ;
    });
  }, [data?.subnets, searchQuery, selectedState, selectedAZ]);

  // 4. Filter logic for Security Groups
  const filteredSecurityGroups = useMemo(() => {
    if (!data?.security_groups) return [];
    return data.security_groups.filter(sg => {
      // Search matches SG Name, SG ID, or VPC ID
      const matchesSearch = searchQuery === '' || 
        sg.group_name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sg.group_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        sg.vpc_id.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesSearch;
    });
  }, [data?.security_groups, searchQuery]);

  // 5. Filter logic for Route Tables
  const filteredRouteTables = useMemo(() => {
    if (!data?.route_tables) return [];
    return data.route_tables.filter(rt => {
      // Search matches RT ID or VPC ID
      const matchesSearch = searchQuery === '' || 
        rt.route_table_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        rt.vpc_id.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesSearch;
    });
  }, [data?.route_tables, searchQuery]);

  // 6. Filter logic for Network ACLs
  const filteredNetworkAcls = useMemo(() => {
    if (!data?.network_acls) return [];
    return data.network_acls.filter(nacl => {
      const matchesSearch = searchQuery === '' || 
        nacl.network_acl_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        nacl.vpc_id.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesSearch;
    });
  }, [data?.network_acls, searchQuery]);

  // 7. Gateways filters
  const filteredInternetGateways = useMemo(() => {
    if (!data?.internet_gateways) return [];
    return data.internet_gateways.filter(igw => {
      const matchesSearch = searchQuery === '' || 
        igw.internet_gateway_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        igw.attached_vpc.toLowerCase().includes(searchQuery.toLowerCase());
      return matchesSearch;
    });
  }, [data?.internet_gateways, searchQuery]);

  const filteredNatGateways = useMemo(() => {
    if (!data?.nat_gateways) return [];
    return data.nat_gateways.filter(nat => {
      const matchesSearch = searchQuery === '' || 
        nat.nat_gateway_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
        nat.vpc_id.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesState = selectedState === '' || nat.state === selectedState;
      return matchesSearch && matchesState;
    });
  }, [data?.nat_gateways, searchQuery, selectedState]);

  // Reset all filters
  const handleClearFilters = () => {
    setSearchQuery('');
    setSelectedState('');
    setSelectedAZ('');
    setSelectedDefaultVpc('');
  };

  const getActiveTabExportData = () => {
    switch (activeTab) {
      case 'vpcs': return filteredVpcs;
      case 'subnets': return filteredSubnets;
      case 'security_groups': return filteredSecurityGroups;
      case 'route_tables': return filteredRouteTables;
      case 'nacls': return filteredNetworkAcls;
      case 'gateways': return [...filteredInternetGateways, ...filteredNatGateways];
      default: return [];
    }
  };

  const hasActiveFilters = searchQuery !== '' || selectedState !== '' || selectedAZ !== '' || selectedDefaultVpc !== '';

  return (
    <div id="vpc-monitoring-page" className="space-y-6">
      <PageHeader 
        title="VPC Network Monitoring" 
        description="Inspect secure Virtual Private Clouds, Subnets, Internet and NAT Gateways, Route Tables, and firewalls."
      >
        <button
          onClick={refetch}
          disabled={loading}
          className="flex items-center gap-1.5 px-3.5 py-2 bg-slate-900/60 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-white rounded-xl text-xs font-mono font-bold uppercase tracking-wider transition-all"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
          <span>Refresh Telemetry</span>
        </button>
      </PageHeader>

      {/* Access Denied / Warning Alert Banner */}
      {error && (
        <div className="bg-amber-500/10 border border-amber-500/20 text-amber-200/90 p-4 rounded-2xl flex items-start gap-3.5 shadow-sm">
          <AlertTriangle className="w-5 h-5 text-amber-500 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h4 className="text-xs font-bold font-mono tracking-wide uppercase text-amber-400">
              AWS Connection Warning
            </h4>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              {error} Please confirm that your AWS programmatic credentials have the necessary permissions to read EC2 VPC configurations (`ec2:DescribeVpcs`, `ec2:DescribeSubnets`, etc).
            </p>
          </div>
        </div>
      )}

      {/* Executive Metric Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-5">
        {/* Total VPCs */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4.5 flex items-center justify-between hover:border-slate-700/60 transition-all">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">VPCs</span>
            <h3 className="text-xl font-black text-white font-mono leading-none">
              {loading && !data ? '...' : summary.vpcs}
            </h3>
          </div>
          <div className="p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-amber-500">
            <Network className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Subnets */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4.5 flex items-center justify-between hover:border-slate-700/60 transition-all">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">Subnets</span>
            <h3 className="text-xl font-black text-white font-mono leading-none">
              {loading && !data ? '...' : summary.subnets}
            </h3>
          </div>
          <div className="p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-sky-400">
            <Layers className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Security Groups */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4.5 flex items-center justify-between hover:border-slate-700/60 transition-all">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">Security Groups</span>
            <h3 className="text-xl font-black text-white font-mono leading-none">
              {loading && !data ? '...' : summary.security_groups}
            </h3>
          </div>
          <div className="p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-purple-400">
            <Shield className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Internet Gateways */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4.5 flex items-center justify-between hover:border-slate-700/60 transition-all">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">Internet GWs</span>
            <h3 className="text-xl font-black text-white font-mono leading-none">
              {loading && !data ? '...' : summary.internet_gateways}
            </h3>
          </div>
          <div className="p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-emerald-400">
            <Globe className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* NAT Gateways */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4.5 flex items-center justify-between hover:border-slate-700/60 transition-all">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">NAT GWs</span>
            <h3 className="text-xl font-black text-white font-mono leading-none">
              {loading && !data ? '...' : summary.nat_gateways}
            </h3>
          </div>
          <div className="p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-pink-400">
            <Cpu className="w-4.5 h-4.5" />
          </div>
        </div>

        {/* Network ACLs */}
        <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4.5 flex items-center justify-between hover:border-slate-700/60 transition-all">
          <div className="space-y-1">
            <span className="text-[10px] uppercase font-bold text-slate-500 tracking-wider font-mono">Network ACLs</span>
            <h3 className="text-xl font-black text-white font-mono leading-none">
              {loading && !data ? '...' : summary.network_acls}
            </h3>
          </div>
          <div className="p-2.5 rounded-lg border bg-slate-900 border-slate-800 text-amber-500">
            <ShieldAlert className="w-4.5 h-4.5" />
          </div>
        </div>
      </div>

      {/* Control panel: Quick Search & Filter Panel Toggle */}
      <div className="bg-[#0f1422] border border-slate-800/80 rounded-2xl p-4 flex flex-col md:flex-row gap-4 items-center justify-between">
        <div className="flex w-full md:w-auto items-center gap-2">
          {/* Quick Search */}
          <div className="relative flex-1 md:w-80">
            <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-slate-500" />
            <input
              type="text"
              placeholder="Search VPC ID, Subnet ID, SG Name..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800/85 focus:border-amber-500/40 rounded-xl pl-9 pr-4 py-2 text-xs font-mono text-slate-200 placeholder-slate-500 focus:outline-none"
            />
          </div>

          {/* Toggle advance filters */}
          <button
            onClick={() => setShowFilters(!showFilters)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-mono font-bold transition-all border ${
              showFilters 
                ? 'bg-amber-500/15 text-amber-400 border-amber-500/30' 
                : 'bg-slate-900/60 text-slate-400 border-slate-800/80 hover:bg-slate-800 hover:text-slate-200'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>
        </div>

        {/* Info indicators */}
        <div className="flex items-center gap-3 text-[10px] font-mono text-slate-500">
          <span className="flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
            Read-only mode active
          </span>
        </div>
      </div>

      {/* Expanded Filters Drawer panel */}
      {showFilters && (
        <div className="p-5 bg-[#0f1422] border border-slate-800/80 rounded-2xl grid grid-cols-1 md:grid-cols-3 gap-4 animate-in slide-in-from-top-4 duration-150">
          {/* Filter AZ */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
              Availability Zone
            </label>
            <select
              value={selectedAZ}
              onChange={(e) => setSelectedAZ(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-500/40 cursor-pointer"
            >
              <option value="">All Zones</option>
              {uniqueAZs.map(az => (
                <option key={az} value={az}>{az}</option>
              ))}
            </select>
          </div>

          {/* Filter State */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
              State / Status
            </label>
            <select
              value={selectedState}
              onChange={(e) => setSelectedState(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-500/40 cursor-pointer"
            >
              <option value="">All States</option>
              <option value="available">Available</option>
              <option value="pending">Pending</option>
            </select>
          </div>

          {/* Filter Default VPC */}
          <div className="flex flex-col gap-1.5">
            <label className="text-[10px] text-slate-400 font-mono font-bold uppercase tracking-wider">
              VPC Scope (Default flag)
            </label>
            <select
              value={selectedDefaultVpc}
              onChange={(e) => setSelectedDefaultVpc(e.target.value)}
              className="w-full bg-slate-950 border border-slate-800 rounded-xl px-3 py-2 text-xs font-mono text-slate-200 focus:outline-none focus:border-amber-500/40 cursor-pointer"
            >
              <option value="">All VPCs</option>
              <option value="true">Default VPC only</option>
              <option value="false">Custom VPC only</option>
            </select>
          </div>

          {hasActiveFilters && (
            <div className="col-span-1 md:col-span-3 flex justify-end pt-2">
              <button
                onClick={handleClearFilters}
                className="flex items-center gap-1 px-3 py-1 bg-slate-800/40 hover:bg-slate-800 text-slate-400 hover:text-slate-300 border border-slate-800 hover:border-slate-700/80 rounded-xl text-xs font-mono font-bold uppercase"
              >
                <X className="w-3.5 h-3.5" />
                Clear Active Filters
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tabs navigation */}
      <div className="flex flex-col sm:flex-row justify-between items-stretch sm:items-center border-b border-slate-800 gap-4">
        <div className="flex overflow-x-auto gap-2 pb-px">
          {(['vpcs', 'subnets', 'security_groups', 'route_tables', 'gateways', 'nacls'] as TabType[]).map((tab) => {
            let label = tab.toUpperCase().replace('_', ' ');
            if (tab === 'nacls') label = 'NETWORK ACLs';
            
            const isActive = activeTab === tab;
            
            return (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`pb-3 px-4 font-mono text-xs font-bold uppercase border-b-2 tracking-wider transition-all whitespace-nowrap ${
                  isActive
                    ? 'border-amber-500 text-amber-400'
                    : 'border-transparent text-slate-500 hover:text-slate-300'
                }`}
              >
                {label}
              </button>
            );
          })}
        </div>
        <div className="pb-2 sm:pb-0 shrink-0 self-end sm:self-auto">
          <ExportMenu data={getActiveTabExportData() as any[]} filenamePrefix={`AWS_VPC_${activeTab}`} />
        </div>
      </div>

      {/* Render Selected Tab content */}
      <div className="space-y-4">
        {activeTab === 'vpcs' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-amber-500" />
              <span>Virtual Private Clouds (showing {filteredVpcs.length} of {summary.vpcs})</span>
            </div>
            <VPCCard vpcs={filteredVpcs} loading={loading} />
          </div>
        )}

        {activeTab === 'subnets' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-sky-400" />
              <span>Subnet Allocations (showing {filteredSubnets.length} of {summary.subnets})</span>
            </div>
            <SubnetTable subnets={filteredSubnets} loading={loading} />
          </div>
        )}

        {activeTab === 'security_groups' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-purple-400" />
              <span>Security Group Rules (showing {filteredSecurityGroups.length} of {summary.security_groups})</span>
            </div>
            <SecurityGroupTable securityGroups={filteredSecurityGroups} loading={loading} />
          </div>
        )}

        {activeTab === 'route_tables' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-indigo-400" />
              <span>Route Tables (showing {filteredRouteTables.length} of {summary.route_tables})</span>
            </div>
            <RouteTableTable routeTables={filteredRouteTables} loading={loading} />
          </div>
        )}

        {activeTab === 'nacls' && (
          <div className="space-y-3">
            <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
              <ChevronRight className="w-3 h-3 text-amber-500" />
              <span>Network Access Control Lists (showing {filteredNetworkAcls.length} of {summary.network_acls})</span>
            </div>
            <NetworkACLTable networkAcls={filteredNetworkAcls} loading={loading} />
          </div>
        )}

        {activeTab === 'gateways' && (
          <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
            {/* Internet Gateways Section */}
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
                <ChevronRight className="w-3 h-3 text-emerald-400" />
                <span>Internet Gateways (showing {filteredInternetGateways.length} of {summary.internet_gateways})</span>
              </div>
              <InternetGatewayTable gateways={filteredInternetGateways} loading={loading} />
            </div>

            {/* NAT Gateways Section */}
            <div className="space-y-3">
              <div className="flex items-center gap-1.5 text-xs font-mono text-slate-400">
                <ChevronRight className="w-3 h-3 text-pink-400" />
                <span>NAT Gateways (showing {filteredNatGateways.length} of {summary.nat_gateways})</span>
              </div>
              <NatGatewayTable gateways={filteredNatGateways} loading={loading} />
            </div>
          </div>
        )}
      </div>

      {/* Compliance / Security Warning Panel */}
      <div className="bg-slate-950/40 p-4 rounded-2xl border border-slate-800/50 flex gap-3 items-start">
        <ShieldAlert className="w-4.5 h-4.5 text-slate-500 shrink-0 mt-0.5" />
        <div className="text-[11px] text-slate-500 font-mono leading-relaxed">
          <span className="text-slate-400 font-bold uppercase tracking-wider block mb-1">AWS Networking Compliance Guard</span>
          This VPC Networking Monitoring interface operations are read-only. Creating/deleting VPCs, modifying route tables, altering subnet CIDRs, changing firewall ingress/egress permissions, or attaching/detaching gateways is strictly restricted.
        </div>
      </div>
    </div>
  );
}
