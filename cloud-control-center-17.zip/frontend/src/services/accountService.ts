import apiClient from '../api/apiClient';
import { AWSAccount } from '../types/account';

/**
 * Service handler to retrieve comprehensive AWS Account Overview parameters from the backend secure proxy.
 */
export async function getAWSAccountOverview(): Promise<AWSAccount> {
  const response = await apiClient.get<AWSAccount>('/api/aws/account');
  return response.data;
}
