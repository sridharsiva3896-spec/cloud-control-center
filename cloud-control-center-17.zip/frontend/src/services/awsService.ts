import apiClient from '../api/apiClient';

export interface AWSConnectionResponse {
  connected: boolean;
  account_id?: string;
  arn?: string;
  user_id?: string;
  region?: string;
  message: string;
  error_type?: string;
  code?: string;
}

export interface AWSConnectCredentials {
  aws_access_key_id: string;
  aws_secret_access_key: string;
  aws_session_token?: string;
  region_name?: string;
}

/**
 * Service handler for verifying AWS account STS connection details via secure POST.
 */
export async function connectAWS(credentials: AWSConnectCredentials): Promise<AWSConnectionResponse> {
  const response = await apiClient.post<AWSConnectionResponse>('/api/aws/connect', credentials);
  return response.data;
}
