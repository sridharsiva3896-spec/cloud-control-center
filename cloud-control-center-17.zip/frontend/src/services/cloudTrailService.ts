import apiClient from '../api/apiClient';
import { CloudTrailResponse } from '../types/cloudtrail';

/**
 * Service handler to retrieve AWS CloudTrail audit logs.
 */
export async function getCloudTrailEvents(region?: string): Promise<CloudTrailResponse> {
  const response = await apiClient.get<CloudTrailResponse>('/api/aws/cloudtrail', {
    params: region ? { region } : {}
  });
  return response.data;
}
