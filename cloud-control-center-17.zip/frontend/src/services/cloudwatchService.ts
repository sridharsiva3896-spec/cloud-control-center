import apiClient from '../api/apiClient';
import { CloudWatchResponse } from '../types/cloudwatch';

/**
 * Service handler to retrieve AWS CloudWatch telemetry and EC2 metrics summaries.
 */
export async function getCloudWatchMetrics(region?: string): Promise<CloudWatchResponse> {
  const response = await apiClient.get<CloudWatchResponse>('/api/aws/cloudwatch', {
    params: region ? { region } : {}
  });
  return response.data;
}
