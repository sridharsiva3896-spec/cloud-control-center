import apiClient from '../api/apiClient';
import { CostExplorerResponse } from '../types/cost';

/**
 * Service handler to retrieve AWS Cost Explorer analytics.
 */
export async function getCostExplorerData(): Promise<CostExplorerResponse> {
  const response = await apiClient.get<CostExplorerResponse>('/api/aws/cost');
  return response.data;
}
