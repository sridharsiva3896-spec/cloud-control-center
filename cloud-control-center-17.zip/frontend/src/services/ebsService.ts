import apiClient from '../api/apiClient';
import { EBSResponse } from '../types/ebs';

/**
 * Service to fetch AWS EBS monitoring metrics, volumes, and snapshots from the backend.
 */
export async function getEBSMonitoring(region?: string): Promise<EBSResponse> {
  const response = await apiClient.get<EBSResponse>('/api/aws/ebs', {
    params: region ? { region } : {}
  });
  return response.data;
}
