import apiClient from '../api/apiClient';
import { EC2Response } from '../types/ec2';

/**
 * Service handler to retrieve comprehensive EC2 virtual machine instances and summary state metrics.
 */
export async function getEC2Instances(region?: string): Promise<EC2Response> {
  const response = await apiClient.get<EC2Response>('/api/aws/ec2', {
    params: region ? { region } : {}
  });
  return response.data;
}
