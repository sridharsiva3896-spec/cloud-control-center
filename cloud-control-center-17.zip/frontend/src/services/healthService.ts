import apiClient from '../api/apiClient';

export interface HealthResponse {
  status: string;
  service: string;
  version: string;
}

/**
 * Service handler for querying the backend REST API health indicator.
 */
export async function getHealth(): Promise<HealthResponse> {
  const response = await apiClient.get<HealthResponse>('/api/health');
  return response.data;
}
