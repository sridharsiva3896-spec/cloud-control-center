import apiClient from '../api/apiClient';
import { IAMResponse } from '../types/iam';

/**
 * Service handler to retrieve comprehensive IAM entity overview and security audits.
 */
export async function getIAMOverview(): Promise<IAMResponse> {
  const response = await apiClient.get<IAMResponse>('/api/aws/iam');
  return response.data;
}
