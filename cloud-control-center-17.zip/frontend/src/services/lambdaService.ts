import apiClient from '../api/apiClient';
import { LambdaResponse } from '../types/lambda';

/**
 * Service to fetch AWS Lambda monitoring metrics and configurations from the backend.
 */
export async function getLambdaMonitoring(region?: string): Promise<LambdaResponse> {
  const response = await apiClient.get<LambdaResponse>('/api/aws/lambda', {
    params: region ? { region } : {}
  });
  return response.data;
}
