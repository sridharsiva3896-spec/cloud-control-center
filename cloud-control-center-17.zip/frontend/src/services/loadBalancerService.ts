import apiClient from '../api/apiClient';
import { LoadBalancerResponse } from '../types/loadBalancer';

/**
 * Service to fetch AWS ELBv2 Load Balancers monitoring details from backend.
 */
export async function getLoadBalancersMonitoring(region?: string): Promise<LoadBalancerResponse> {
  const response = await apiClient.get<LoadBalancerResponse>('/api/aws/load-balancers', {
    params: region ? { region } : {}
  });
  return response.data;
}
