import { Notification } from '../context/NotificationContext';

const LOCAL_STORAGE_KEY = 'cloud_control_center_notifications';
const MAX_NOTIFICATIONS = 100;

/**
 * Service to manage local storage persistence of AWS Cloud Control Center notifications.
 */
export function getStoredNotifications(): Notification[] {
  try {
    const data = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (!data) return [];
    return JSON.parse(data);
  } catch (error) {
    console.error('Failed to parse notifications from local storage:', error);
    return [];
  }
}

export function saveNotifications(notifications: Notification[]): void {
  try {
    const trimmed = notifications.slice(0, MAX_NOTIFICATIONS);
    localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify(trimmed));
  } catch (error) {
    console.error('Failed to save notifications to local storage:', error);
  }
}
