import apiClient from '../api/apiClient';
import { RDSResponse } from '../types/rds';

/**
 * Service to fetch AWS RDS monitoring metrics, instances, and clusters from the backend.
 */
export async function getRDSMonitoring(region?: string): Promise<RDSResponse> {
  const response = await apiClient.get<RDSResponse>('/api/aws/rds', {
    params: region ? { region } : {}
  });
  return response.data;
}
