import apiClient from '../api/apiClient';

export interface RegionItem {
  code: string;
  name: string;
}

export interface RegionCatalog {
  regions: RegionItem[];
  defaultRegion: string;
}

/**
 * Service handler to retrieve the complete public AWS regions catalog.
 */
export async function getRegionsCatalog(): Promise<RegionCatalog> {
  const response = await apiClient.get<RegionCatalog>('/api/regions');
  return response.data;
}

/**
 * Service handler to update the session's active region context on the backend.
 */
export async function updateAWSSessionRegion(regionName: string): Promise<{ message: string }> {
  const response = await apiClient.post<{ message: string }>('/api/aws/region', {
    region_name: regionName
  });
  return response.data;
}

/**
 * Service handler to retrieve the list of available AWS regions.
 */
export async function getAWSRegions(): Promise<string[]> {
  try {
    const catalog = await getRegionsCatalog();
    return catalog.regions.map(r => r.code);
  } catch (err) {
    const response = await apiClient.get<string[]>('/api/aws/regions');
    return response.data;
  }
}

/**
 * Service handler to retrieve the backend-configured default AWS region.
 */
export async function getDefaultAWSRegion(): Promise<string> {
  try {
    const catalog = await getRegionsCatalog();
    return catalog.defaultRegion;
  } catch (err) {
    const response = await apiClient.get<string>('/api/aws/regions/default');
    return response.data;
  }
}
