import apiClient from '../api/apiClient';
import { S3Response } from '../types/s3';

/**
 * Service handler to retrieve comprehensive S3 bucket metrics and audit states.
 */
export async function getS3Buckets(): Promise<S3Response> {
  const response = await apiClient.get<S3Response>('/api/aws/s3');
  return response.data;
}
