import apiClient from '../api/apiClient';
import { SearchResponse } from '../types/search';

/**
 * Service handler to retrieve AWS search results from the API.
 */
export async function searchAWS(query: string): Promise<SearchResponse> {
  const response = await apiClient.get<SearchResponse>('/api/aws/search', {
    params: { q: query }
  });
  return response.data;
}
