import apiClient from '../api/apiClient';
import { SecurityReportResponse } from '../types/security';

/**
 * Service handler to retrieve the real AWS security and configuration report.
 */
export async function getSecurityReport(): Promise<SecurityReportResponse> {
  const response = await apiClient.get<SecurityReportResponse>('/api/aws/security');
  return response.data;
}
