import apiClient from '../api/apiClient';
import { AWSSession } from '../types/aws';

/**
 * Service layer handler to request current AWS session context from the FastAPI server.
 * Returns information retrieved via STS (Security Token Service).
 */
export async function getAWSSession(): Promise<AWSSession> {
  const response = await apiClient.get<AWSSession>('/api/aws/session');
  return response.data;
}

/**
 * Service layer handler to destroy the AWS session on the FastAPI server.
 */
export async function logoutAWS(): Promise<{ message: string }> {
  const response = await apiClient.post<{ message: string }>('/api/aws/logout');
  return response.data;
}
