import apiClient from '../api/apiClient';
import { TagResponse } from '../types/tag';

/**
 * Service to retrieve AWS Resource Tags from the backend.
 */
export async function getTagExplorer(params: {
  region?: string;
  service?: string;
  tag_key?: string;
  tag_value?: string;
}): Promise<TagResponse> {
  const response = await apiClient.get<TagResponse>('/api/aws/tags', {
    params
  });
  return response.data;
}
