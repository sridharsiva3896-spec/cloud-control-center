import apiClient from '../api/apiClient';
import { VpcResponse } from '../types/vpc';

/**
 * Service to fetch AWS VPC networking monitoring details from backend.
 */
export async function getVpcMonitoring(region?: string): Promise<VpcResponse> {
  const response = await apiClient.get<VpcResponse>('/api/aws/vpc', {
    params: region ? { region } : {}
  });
  return response.data;
}
