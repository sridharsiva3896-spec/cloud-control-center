/**
 * Defines the standard shape of AWS Account Overview context.
 * Encompasses connected identities, structural billing/account aliases, and available geographic region lists.
 */
export interface AWSAccount {
  connected: boolean;
  account_id?: string;
  account_alias?: string;
  arn?: string;
  user_name?: string;
  region?: string;
  available_regions?: string[];
  message?: string;
}
