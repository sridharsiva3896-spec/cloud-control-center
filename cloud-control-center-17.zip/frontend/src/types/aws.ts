/**
 * Defines the standard shape of an AWS Session validation state.
 * Integrated with STS caller identity details and regional context configurations.
 */
export interface AWSSession {
  connected: boolean;
  account_id?: string;
  arn?: string;
  user_id?: string;
  region?: string;
  message: string;
  error_type?: string;
  code?: string;
}
