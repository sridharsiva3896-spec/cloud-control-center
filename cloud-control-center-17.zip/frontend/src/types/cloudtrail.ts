/**
 * Represents a single CloudTrail audit event.
 */
export interface CloudTrailEvent {
  event_id: string;
  event_name: string;
  event_source: string;
  username: string;
  event_time: string;
  aws_region: string;
  resource_name: string;
  resource_type: string;
  read_only: boolean;
}

/**
 * Summary counters for the audit dashboard.
 */
export interface CloudTrailSummary {
  total_events: number;
  unique_users: number;
  event_sources: number;
}

/**
 * API Response returned by GET /api/aws/cloudtrail.
 */
export interface CloudTrailResponse {
  summary: CloudTrailSummary;
  events: CloudTrailEvent[];
  enabled: boolean;
  message?: string;
  error?: string;
}
