/**
 * Defines the metrics retrieved from AWS CloudWatch for an EC2 instance.
 */
export interface CloudWatchMetrics {
  cpu_utilization: number | null;
  network_in: number | null;
  network_out: number | null;
  disk_read_bytes: number | null;
  disk_write_bytes: number | null;
}

/**
 * Defines the audited performance state for an EC2 instance target.
 */
export interface CloudWatchInstance {
  instance_id: string;
  metrics: CloudWatchMetrics;
  last_updated: string;
}

/**
 * Represents aggregation counters for the CloudWatch monitor.
 */
export interface CloudWatchSummary {
  monitored_instances: number;
  metrics_collected: number;
}

/**
 * API response structure returned from GET /api/aws/cloudwatch.
 */
export interface CloudWatchResponse {
  summary: CloudWatchSummary;
  instances: CloudWatchInstance[];
  errors?: Record<string, string>;
  error?: string;
}
