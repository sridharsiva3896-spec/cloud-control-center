/**
 * Represents a summary of monthly costs.
 */
export interface CostSummary {
  current_month_cost: number;
  previous_month_cost: number;
  currency: string;
}

/**
 * Represents cost grouped by an AWS service.
 */
export interface ServiceCost {
  service: string;
  cost: number;
}

/**
 * Represents the daily cost trend for the current month.
 */
export interface DailyCostTrend {
  date: string;
  cost: number;
}

/**
 * Represents the full response of the AWS Cost Explorer API.
 */
export interface CostExplorerResponse {
  summary: CostSummary;
  services: ServiceCost[];
  daily_trend: DailyCostTrend[];
  enabled: boolean;
  message?: string;
  error?: string;
}
