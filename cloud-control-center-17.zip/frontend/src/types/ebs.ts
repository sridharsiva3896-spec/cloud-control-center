/**
 * AWS EBS Interface definitions for Cloud Control Center.
 */

export interface EBSVolume {
  volume_id: string;
  size: number;
  volume_type: string;
  state: string;
  iops: number;
  throughput: number;
  encrypted: boolean;
  az: string;
  attached_instance_id: string;
  device_name: string;
  create_time: string;
}

export interface EBSSnapshot {
  snapshot_id: string;
  volume_id: string;
  state: string;
  progress: string;
  start_time: string;
  storage_tier: string;
}

export interface EBSSummary {
  volumes: number;
  available: number;
  in_use: number;
  snapshots: number;
  encrypted: number;
}

export interface EBSResponse {
  summary: EBSSummary;
  volumes: EBSVolume[];
  snapshots: EBSSnapshot[];
  error?: string | null;
  errors?: Record<string, string>;
}
