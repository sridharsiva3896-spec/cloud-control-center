/**
 * Defines the standard shape of an individual EC2 Instance.
 */
export interface EC2Instance {
  instance_id: string;
  name: string;
  state: string;
  instance_type: string;
  public_ip: string;
  private_ip: string;
  availability_zone: string;
  launch_time: string;
  platform: string;
  vpc_id: string;
  subnet_id: string;
}

/**
 * Defines the standard shape of EC2 Overview/Summary data.
 */
export interface EC2Summary {
  total: number;
  running: number;
  stopped: number;
}

/**
 * Defines the response shape from the backend `/api/aws/ec2` endpoint.
 */
export interface EC2Response {
  summary: EC2Summary;
  instances: EC2Instance[];
  error?: string;
}
