/**
 * Defines the shape of an audited IAM User.
 */
export interface IAMUser {
  user_name: string;
  user_id: string;
  arn: string;
  create_date: string;
  password_enabled: string;
  mfa_enabled: boolean;
  access_key_count: number;
}

/**
 * Defines the shape of an audited IAM Role.
 */
export interface IAMRole {
  role_name: string;
  arn: string;
  create_date: string;
}

/**
 * Defines the shape of an audited IAM Group.
 */
export interface IAMGroup {
  group_name: string;
  arn: string;
  user_count: number;
}

/**
 * Defines the shape of an audited Customer Managed Policy.
 */
export interface IAMPolicy {
  policy_name: string;
  arn: string;
  create_date: string;
}

/**
 * Defines the collection of resource summary metrics.
 */
export interface IAMSummary {
  users: number;
  groups: number;
  roles: number;
  policies: number;
}

/**
 * Represents the structured server response payload from the API.
 */
export interface IAMResponse {
  summary: IAMSummary;
  users: IAMUser[];
  groups: IAMGroup[];
  roles: IAMRole[];
  policies: IAMPolicy[];
  errors?: Record<string, string>;
  error?: string;
}
