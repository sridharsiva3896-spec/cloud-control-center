/**
 * AWS Lambda Interface definitions for Cloud Control Center.
 */

export interface LambdaFunction {
  name: string;
  runtime: string;
  handler: string;
  memory_size: number;
  timeout: number;
  last_modified: string;
  state: string;
  package_type: string;
  architecture: string;
  concurrency?: number | null;
}

export interface LambdaSummary {
  functions: number;
  active: number;
  failed: number;
}

export interface LambdaResponse {
  summary: LambdaSummary;
  functions: LambdaFunction[];
  error?: string | null;
  errors?: Record<string, string>;
}
