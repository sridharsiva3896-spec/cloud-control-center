export interface LoadBalancerInfo {
  name: string;
  arn: string;
  type: string; // 'application', 'network', 'gateway'
  scheme: string; // 'internet-facing', 'internal'
  state: string; // 'active', 'provisioning', 'failed'
  dns_name: string;
  vpc_id: string;
  availability_zones: string[];
}

export interface TargetGroupInfo {
  name: string;
  arn: string;
  protocol: string;
  port: number | string;
  target_type: string; // 'instance', 'ip', 'lambda', 'alb'
  health_check_path: string;
  vpc_id: string;
}

export interface ListenerInfo {
  arn: string;
  load_balancer_arn: string;
  protocol: string;
  port: number | string;
  default_actions: string[];
}

export interface TargetHealthInfo {
  target_group_arn: string;
  target_id: string;
  port: number | string;
  health_state: string; // 'healthy', 'unhealthy', 'unused', 'draining', 'initial'
  health_reason?: string;
  description?: string;
}

export interface LoadBalancerSummary {
  load_balancers: number;
  application_load_balancers: number;
  network_load_balancers: number;
  gateway_load_balancers: number;
  target_groups: number;
  healthy_targets: number;
  unhealthy_targets: number;
}

export interface LoadBalancerResponse {
  summary: LoadBalancerSummary;
  load_balancers: LoadBalancerInfo[];
  target_groups: TargetGroupInfo[];
  listeners: ListenerInfo[];
  target_health: TargetHealthInfo[];
  errors?: Record<string, string>;
  error?: string;
}
