/**
 * AWS RDS Interface definitions for Cloud Control Center.
 */

export interface RDSInstance {
  identifier: string;
  engine: string;
  version: string;
  class: string;
  status: string;
  storage: number;
  multi_az: boolean;
  endpoint: string;
  az: string;
}

export interface RDSCluster {
  identifier: string;
  engine: string;
  version: string;
  status: string;
  multi_az: boolean;
  members: string[];
}

export interface RDSSummary {
  instances: number;
  clusters: number;
  available: number;
  stopped: number;
}

export interface RDSResponse {
  summary: RDSSummary;
  instances: RDSInstance[];
  clusters: RDSCluster[];
  error?: string | null;
  errors?: Record<string, string>;
}
