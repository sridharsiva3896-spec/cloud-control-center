/**
 * Defines the standard shape of an individual S3 Bucket metadata.
 */
export interface S3Bucket {
  name: string;
  region: string;
  creation_date: string;
  versioning: string;
  encryption: string;
  public_access: string;
  arn: string;
}

/**
 * Defines the S3 Overview / Summary count data.
 */
export interface S3Summary {
  total_buckets: number;
}

/**
 * Defines the server response shape from `/api/aws/s3`.
 */
export interface S3Response {
  summary: S3Summary;
  buckets: S3Bucket[];
  error?: string;
}
