export interface SearchResult {
  service: 'EC2' | 'S3' | 'IAM';
  resource_type: 'Instance' | 'Bucket' | 'User' | 'Role' | 'Group';
  name: string;
  resource_id: string;
  region: string;
}

export interface SearchResponse {
  query: string;
  total_results: number;
  results: SearchResult[];
}
