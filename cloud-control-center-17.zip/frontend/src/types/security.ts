/**
 * Summary metrics of the security compliance audit run.
 */
export interface SecuritySummary {
  security_score: number;
  critical: number;
  warning: number;
  passed: number;
}

/**
 * Root account security status details.
 */
export interface RootAccountCheck {
  status: 'PASSED' | 'WARNING' | 'CRITICAL';
  root_account_used: boolean;
  details: string;
}

/**
 * User without MFA details.
 */
export interface UserWithoutMfa {
  username: string;
  mfa_enabled: boolean;
}

/**
 * MFA configuration check status details.
 */
export interface MfaCheck {
  status: 'PASSED' | 'WARNING' | 'CRITICAL';
  users_without_mfa: UserWithoutMfa[];
  total_users: number;
  error?: string;
}

/**
 * Access Key details that are flagged.
 */
export interface OldAccessKey {
  username: string;
  key_id: string;
  key_age_days: number;
  status: string;
}

/**
 * Access Key duration and rotation status details.
 */
export interface AccessKeysCheck {
  status: 'PASSED' | 'WARNING' | 'CRITICAL';
  old_keys: OldAccessKey[];
  error?: string;
}

/**
 * Public S3 Bucket details.
 */
export interface PublicBucket {
  bucket_name: string;
  public_access: string;
}

/**
 * S3 isolation compliance status details.
 */
export interface PublicBucketsCheck {
  status: 'PASSED' | 'WARNING' | 'CRITICAL';
  public_buckets: PublicBucket[];
  total_buckets: number;
  error?: string;
}

/**
 * AWS account password policy complexity details.
 */
export interface PasswordPolicyCheck {
  status: 'PASSED' | 'WARNING' | 'CRITICAL';
  configured: boolean;
  minimum_length: number;
  require_symbols: boolean;
  require_numbers: boolean;
  require_uppercase: boolean;
  require_lowercase: boolean;
  max_password_age: number;
  details?: string;
  error?: string;
}

/**
 * Groups all security audit categories together.
 */
export interface SecurityChecks {
  root_account: RootAccountCheck;
  mfa: MfaCheck;
  access_keys: AccessKeysCheck;
  public_buckets: PublicBucketsCheck;
  password_policy: PasswordPolicyCheck;
}

/**
 * Root response structure from the AWS Security Audit endpoint.
 */
export interface SecurityReportResponse {
  summary: SecuritySummary;
  checks: SecurityChecks;
  enabled: boolean;
  message?: string;
  error?: string;
}
