/**
 * AWS Tag Explorer Interface definitions for Cloud Control Center.
 */

export interface TaggedResource {
  arn: string;
  service: string;
  region: string;
  resource_type: string;
  resource_name: string;
  tag_key: string;
  tag_value: string;
}

export interface TagResponse {
  resources: TaggedResource[];
  error?: string | null;
}
