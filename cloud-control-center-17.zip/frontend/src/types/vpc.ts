export interface VpcTag {
  Key: string;
  Value: string;
}

export interface VpcInfo {
  vpc_id: string;
  cidr_block: string;
  state: string;
  is_default: boolean;
  owner_id: string;
  tags: VpcTag[];
}

export interface SubnetInfo {
  subnet_id: string;
  vpc_id: string;
  cidr_block: string;
  availability_zone: string;
  available_ip_count: number;
  state: string;
}

export interface RouteTableInfo {
  route_table_id: string;
  vpc_id: string;
  routes_count: number;
  associations_count: number;
}

export interface InternetGatewayInfo {
  internet_gateway_id: string;
  attached_vpc: string;
}

export interface NatGatewayInfo {
  nat_gateway_id: string;
  state: string;
  public_ip: string;
  subnet_id: string;
  vpc_id: string;
}

export interface SecurityGroupInfo {
  group_id: string;
  group_name: string;
  description: string;
  vpc_id: string;
  ingress_rule_count: number;
  egress_rule_count: number;
}

export interface NetworkACLInfo {
  network_acl_id: string;
  vpc_id: string;
  rule_count: number;
  is_default: boolean;
}

export interface VpcSummary {
  vpcs: number;
  subnets: number;
  route_tables: number;
  internet_gateways: number;
  nat_gateways: number;
  security_groups: number;
  network_acls: number;
}

export interface VpcResponse {
  summary: VpcSummary;
  vpcs: VpcInfo[];
  subnets: SubnetInfo[];
  route_tables: RouteTableInfo[];
  internet_gateways: InternetGatewayInfo[];
  nat_gateways: NatGatewayInfo[];
  security_groups: SecurityGroupInfo[];
  network_acls: NetworkACLInfo[];
  error?: string;
  errors?: Record<string, string>;
}
