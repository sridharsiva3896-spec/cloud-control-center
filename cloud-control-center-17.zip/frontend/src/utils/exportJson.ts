/**
 * Export utility to compile and download JSON representation of raw AWS metadata models.
 */
export function exportToJSON<T>(
  data: T,
  filename: string = 'export.json'
): boolean {
  try {
    if (!data) {
      throw new Error('No dataset provided to export.');
    }

    const jsonString = JSON.stringify(data, null, 2);
    const blob = new Blob([jsonString], { type: 'application/json;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', filename);
    link.style.visibility = 'hidden';
    
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    return true;
  } catch (error) {
    console.error('JSON stringification failed:', error);
    return false;
  }
}
