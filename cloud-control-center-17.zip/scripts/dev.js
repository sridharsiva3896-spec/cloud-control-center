import { spawn, spawnSync } from 'child_process';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..');

console.log('================================================================');
console.log('   Cloud Control Center - Full-Stack Developer Suite Launcher');
console.log('================================================================');

// Resolve the correct python/uvicorn command
const backendCwd = path.join(projectRoot, 'backend');
console.log(`[Suite] Launching Python FastAPI Backend inside: ${backendCwd}`);

// OS Detection & Python resolver
const isWindows = process.platform === 'win32';
let pythonCmd = null;

function checkCommand(cmd) {
  try {
    const res = spawnSync(cmd, ['--version'], { shell: true, timeout: 2000 });
    if (res.error) {
      return false;
    }
    if (res.status === 9009 || res.status === 127 || res.status === null) {
      return false;
    }
    return true;
  } catch (err) {
    return false;
  }
}

const attempted = [];
if (isWindows) {
  attempted.push('py', 'python');
  console.log('[Suite] Detecting Python: checking for "py" executable on Windows...');
  if (checkCommand('py')) {
    pythonCmd = 'py';
  } else {
    console.log('[Suite] "py" not found. Checking for "python" executable...');
    if (checkCommand('python')) {
      pythonCmd = 'python';
    }
  }
} else {
  attempted.push('python3', 'python');
  console.log('[Suite] Detecting Python: checking for "python3" executable...');
  if (checkCommand('python3')) {
    pythonCmd = 'python3';
  } else {
    console.log('[Suite] "python3" not found. Checking for "python" executable...');
    if (checkCommand('python')) {
      pythonCmd = 'python';
    }
  }
}

if (!pythonCmd) {
  console.error('\x1b[31m[Suite-Error] Python was not found on this system!\x1b[0m');
  console.error(`\x1b[31m[Suite-Error] Attempted executables: ${attempted.join(', ')}\x1b[0m`);
  console.error('\x1b[31m[Suite-Error] Please ensure Python is installed and added to your system PATH.\x1b[0m');
  process.exit(1);
}

console.log(`[Suite] Selected Python executable: "${pythonCmd}"`);

// Spawn backend uvicorn process
// Using selected python command -m uvicorn as it is cross-platform and ensures we run inside the correct Python env
const backendProcess = spawn(pythonCmd, ['-m', 'uvicorn', 'main:app', '--host', '127.0.0.1', '--port', '8000', '--reload'], {
  cwd: backendCwd,
  env: { ...process.env, PYTHONUNBUFFERED: '1' },
  shell: true
});

backendProcess.stdout.on('data', (data) => {
  const lines = data.toString().trim().split('\n');
  lines.forEach(line => {
    if (line) {
      console.log(`\x1b[35m[Backend]\x1b[0m ${line}`);
    }
  });
});

backendProcess.stderr.on('data', (data) => {
  const lines = data.toString().trim().split('\n');
  lines.forEach(line => {
    if (line) {
      console.error(`\x1b[35m[Backend-Log]\x1b[0m ${line}`);
    }
  });
});

backendProcess.on('error', (err) => {
  console.error(`\x1b[31m[Backend-Error]\x1b[0m Failed to start backend process: ${err.message}`);
});

backendProcess.on('exit', (code) => {
  console.log(`\x1b[31m[Backend-Exit]\x1b[0m Backend process exited with code ${code}`);
  cleanupAndExit();
});

// Spawn frontend Vite process
console.log('[Suite] Launching React Vite Frontend...');
const frontendProcess = spawn('npx', ['vite', '--config', 'frontend/vite.config.ts', '--port', '3000', '--host', '0.0.0.0'], {
  cwd: projectRoot,
  shell: true
});

frontendProcess.stdout.on('data', (data) => {
  const lines = data.toString().trim().split('\n');
  lines.forEach(line => {
    if (line) {
      console.log(`\x1b[36m[Frontend]\x1b[0m ${line}`);
    }
  });
});

frontendProcess.stderr.on('data', (data) => {
  const lines = data.toString().trim().split('\n');
  lines.forEach(line => {
    if (line) {
      console.error(`\x1b[31m[Frontend-Err]\x1b[0m ${line}`);
    }
  });
});

frontendProcess.on('exit', (code) => {
  console.log(`\x1b[31m[Frontend-Exit]\x1b[0m Frontend process exited with code ${code}`);
  cleanupAndExit();
});

let isCleaningUp = false;
function cleanupAndExit() {
  if (isCleaningUp) return;
  isCleaningUp = true;
  console.log('[Suite] Shutting down all processes gracefully...');
  
  if (backendProcess) {
    try {
      backendProcess.kill('SIGINT');
    } catch (e) {}
  }
  
  if (frontendProcess) {
    try {
      frontendProcess.kill('SIGINT');
    } catch (e) {}
  }
  
  setTimeout(() => {
    process.exit(0);
  }, 1000);
}

process.on('SIGINT', cleanupAndExit);
process.on('SIGTERM', cleanupAndExit);
